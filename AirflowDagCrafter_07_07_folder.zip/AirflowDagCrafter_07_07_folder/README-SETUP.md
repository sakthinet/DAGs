# Airflow DAG Generator - Local Development Setup

## Directory Structure

This application uses the following local directories for development:

### Local Directories:
- `./uploads/` - Temporary file uploads from the web interface
- `./input-files/` - Processed CSV files ready for use
- `./dags/` - Generated DAG Python scripts
- `./data/` - CSV input files and XML output files
- `./temp/` - Temporary files for testing and validation

### Production Airflow Directories (Windows):
- `C:\Docker\airflow3x2\dags\` - Copy generated DAG scripts here
- `C:\Docker\airflow3x2\data\` - Copy CSV files here for processing

## Usage Instructions:

1. **Upload CSV**: Use the web interface to upload your CSV file
2. **Configure DAG**: Set up your DAG parameters and file paths
3. **Generate Script**: The DAG script is automatically generated and saved to `./dags/`
4. **Deploy**: Copy the generated script to your Airflow DAGs directory
5. **Process Data**: Copy your CSV files to the Airflow data directory

## File Workflow:

1. CSV uploaded → `./uploads/` → `./input-files/` → `./data/` → `C:\Docker\airflow3x2\data\`
2. DAG generated → `./dags/` → `C:\Docker\airflow3x2\dags\`
3. XML output ← `C:\Docker\airflow3x2\data\`

## Notes:

- In development, Windows paths are automatically converted to local paths
- Files are saved locally and need to be manually copied to production Airflow directories
- The application handles both Linux and Windows path formats
