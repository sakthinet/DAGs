// performance-monitor.ts - Utility for monitoring React app performance

interface PerformanceMetric {
  name: string;
  duration: number;
  timestamp: number;
  type: 'api' | 'render' | 'user-action';
  metadata?: Record<string, any>;
}

interface CacheStats {
  hits: number;
  misses: number;
  hitRate: number;
  totalEntries: number;
  totalSize: number;
}

class PerformanceMonitor {
  private metrics: PerformanceMetric[] = [];
  private observers: PerformanceObserver[] = [];
  private isEnabled: boolean = false;
  
  constructor() {
    this.initObservers();
  }

  // Initialize performance observers
  private initObservers() {
    if (typeof window === 'undefined') return;

    try {
      // Monitor navigation timing
      const navObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'navigation') {
            const navEntry = entry as PerformanceNavigationTiming;
            this.recordMetric({
              name: 'page-load',
              duration: navEntry.loadEventEnd - navEntry.fetchStart,
              timestamp: Date.now(),
              type: 'render',
              metadata: {
                domContentLoaded: navEntry.domContentLoadedEventEnd - navEntry.fetchStart,
                firstByte: navEntry.responseStart - navEntry.fetchStart,
                dns: navEntry.domainLookupEnd - navEntry.domainLookupStart,
                tcp: navEntry.connectEnd - navEntry.connectStart
              }
            });
          }
        }
      });

      // Monitor resource timing
      const resourceObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'resource') {
            const resourceEntry = entry as PerformanceResourceTiming;
            
            // Only track API calls
            if (resourceEntry.name.includes('/api/')) {
              this.recordMetric({
                name: `api-${resourceEntry.name.split('/api/')[1]}`,
                duration: resourceEntry.responseEnd - resourceEntry.startTime,
                timestamp: Date.now(),
                type: 'api',
                metadata: {
                  url: resourceEntry.name,
                  size: resourceEntry.transferSize,
                  cached: resourceEntry.transferSize === 0 && resourceEntry.decodedBodySize > 0
                }
              });
            }
          }
        }
      });

      // Monitor paint timing
      const paintObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          this.recordMetric({
            name: entry.name,
            duration: entry.startTime,
            timestamp: Date.now(),
            type: 'render'
          });
        }
      });

      navObserver.observe({ entryTypes: ['navigation'] });
      resourceObserver.observe({ entryTypes: ['resource'] });
      paintObserver.observe({ entryTypes: ['paint'] });

      this.observers = [navObserver, resourceObserver, paintObserver];
    } catch (error) {
      console.warn('Performance Observer not supported:', error);
    }
  }

  // Enable/disable monitoring
  enable() {
    this.isEnabled = true;
    console.log('🔍 Performance monitoring enabled');
  }

  disable() {
    this.isEnabled = false;
    console.log('🔍 Performance monitoring disabled');
  }

  // Record a custom metric
  recordMetric(metric: PerformanceMetric) {
    if (!this.isEnabled) return;
    
    this.metrics.push(metric);
    
    // Keep only last 100 metrics to prevent memory issues
    if (this.metrics.length > 100) {
      this.metrics = this.metrics.slice(-100);
    }

    // Log slow operations
    if (metric.duration > 1000) {
      console.warn(`🐌 Slow ${metric.type}: ${metric.name} took ${metric.duration.toFixed(2)}ms`);
    }
  }

  // Time an operation
  async timeOperation<T>(
    name: string, 
    operation: () => Promise<T> | T,
    type: PerformanceMetric['type'] = 'user-action',
    metadata?: Record<string, any>
  ): Promise<T> {
    const startTime = performance.now();
    
    try {
      const result = await operation();
      const duration = performance.now() - startTime;
      
      this.recordMetric({
        name,
        duration,
        timestamp: Date.now(),
        type,
        metadata
      });
      
      return result;
    } catch (error) {
      const duration = performance.now() - startTime;
      
      this.recordMetric({
        name: `${name}-error`,
        duration,
        timestamp: Date.now(),
        type,
        metadata: { ...metadata, error: error instanceof Error ? error.message : String(error) }
      });
      
      throw error;
    }
  }

  // Get performance statistics
  getStats(): {
    totalMetrics: number;
    averageApiTime: number;
    averageRenderTime: number;
    slowestOperations: PerformanceMetric[];
    apiCacheHitRate: number;
    recentMetrics: PerformanceMetric[];
  } {
    const apiMetrics = this.metrics.filter(m => m.type === 'api');
    const renderMetrics = this.metrics.filter(m => m.type === 'render');
    
    const averageApiTime = apiMetrics.length > 0 
      ? apiMetrics.reduce((sum, m) => sum + m.duration, 0) / apiMetrics.length 
      : 0;
      
    const averageRenderTime = renderMetrics.length > 0 
      ? renderMetrics.reduce((sum, m) => sum + m.duration, 0) / renderMetrics.length 
      : 0;

    const slowestOperations = [...this.metrics]
      .sort((a, b) => b.duration - a.duration)
      .slice(0, 5);

    const cachedApiCalls = apiMetrics.filter(m => m.metadata?.cached).length;
    const apiCacheHitRate = apiMetrics.length > 0 ? (cachedApiCalls / apiMetrics.length) * 100 : 0;

    return {
      totalMetrics: this.metrics.length,
      averageApiTime: Math.round(averageApiTime),
      averageRenderTime: Math.round(averageRenderTime),
      slowestOperations,
      apiCacheHitRate: Math.round(apiCacheHitRate),
      recentMetrics: this.metrics.slice(-10)
    };
  }

  // Get Core Web Vitals
  getCoreWebVitals(): Promise<{
    lcp?: number;
    fid?: number;
    cls?: number;
  }> {
    return new Promise((resolve) => {
      const vitals: any = {};

      // Largest Contentful Paint
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        vitals.lcp = lastEntry.startTime;
      }).observe({ entryTypes: ['largest-contentful-paint'] });

      // First Input Delay
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        vitals.fid = entries[0].processingStart - entries[0].startTime;
      }).observe({ entryTypes: ['first-input'] });

      // Cumulative Layout Shift
      let clsValue = 0;
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (!(entry as any).hadRecentInput) {
            clsValue += (entry as any).value;
          }
        }
        vitals.cls = clsValue;
      }).observe({ entryTypes: ['layout-shift'] });

      // Resolve after 5 seconds or when all metrics are available
      setTimeout(() => resolve(vitals), 5000);
    });
  }

  // Generate performance report
  generateReport(): string {
    const stats = this.getStats();
    
    return `
# Performance Report

## Summary
- Total Metrics: ${stats.totalMetrics}
- Average API Time: ${stats.averageApiTime}ms
- Average Render Time: ${stats.averageRenderTime}ms
- API Cache Hit Rate: ${stats.apiCacheHitRate}%

## Slowest Operations
${stats.slowestOperations.map((metric, index) => 
  `${index + 1}. ${metric.name}: ${metric.duration.toFixed(2)}ms (${metric.type})`
).join('\n')}

## Recent Metrics
${stats.recentMetrics.map(metric => 
  `- ${metric.name}: ${metric.duration.toFixed(2)}ms (${new Date(metric.timestamp).toLocaleTimeString()})`
).join('\n')}

## Recommendations
${this.generateRecommendations(stats)}
    `.trim();
  }

  // Generate performance recommendations
  private generateRecommendations(stats: ReturnType<typeof this.getStats>): string {
    const recommendations: string[] = [];

    if (stats.averageApiTime > 1000) {
      recommendations.push('- API calls are slow (>1s). Consider caching, optimizing queries, or using a CDN.');
    }

    if (stats.apiCacheHitRate < 50) {
      recommendations.push('- Low cache hit rate. Review caching strategy and TTL values.');
    }

    if (stats.averageRenderTime > 500) {
      recommendations.push('- Slow render times. Consider memoization, virtualization, or code splitting.');
    }

    const slowApiCalls = stats.slowestOperations.filter(op => op.type === 'api' && op.duration > 2000);
    if (slowApiCalls.length > 0) {
      recommendations.push(`- Very slow API calls detected: ${slowApiCalls.map(op => op.name).join(', ')}`);
    }

    return recommendations.length > 0 ? recommendations.join('\n') : '- No performance issues detected!';
  }

  // Clear all metrics
  clearMetrics() {
    this.metrics = [];
    console.log('🧹 Performance metrics cleared');
  }

  // Cleanup observers
  cleanup() {
    this.observers.forEach(observer => observer.disconnect());
    this.observers = [];
    this.metrics = [];
  }
}

// React hook for using performance monitor
import { useEffect, useRef } from 'react';

export function usePerformanceMonitor() {
  const monitor = useRef<PerformanceMonitor>();

  useEffect(() => {
    monitor.current = new PerformanceMonitor();
    monitor.current.enable();

    return () => {
      monitor.current?.cleanup();
    };
  }, []);

  return {
    timeOperation: monitor.current?.timeOperation.bind(monitor.current),
    recordMetric: monitor.current?.recordMetric.bind(monitor.current),
    getStats: () => monitor.current?.getStats(),
    generateReport: () => monitor.current?.generateReport(),
    getCoreWebVitals: () => monitor.current?.getCoreWebVitals(),
    clearMetrics: () => monitor.current?.clearMetrics()
  };
}

// Performance monitoring wrapper for components
export function withPerformanceMonitoring<P extends object>(
  Component: React.ComponentType<P>,
  componentName: string
) {
  return function PerformanceMonitoredComponent(props: P) {
    const monitor = usePerformanceMonitor();
    
    useEffect(() => {
      const startTime = performance.now();
      
      return () => {
        const duration = performance.now() - startTime;
        monitor.recordMetric?.({
          name: `${componentName}-mount`,
          duration,
          timestamp: Date.now(),
          type: 'render'
        });
      };
    }, [monitor]);

    return <Component {...props} />;
  };
}

// Singleton instance for global use
export const performanceMonitor = new PerformanceMonitor();

// Enable in development mode
if (process.env.NODE_ENV === 'development') {
  performanceMonitor.enable();
  
  // Add to window for debugging
  (window as any).performanceMonitor = performanceMonitor;
}

export default PerformanceMonitor;