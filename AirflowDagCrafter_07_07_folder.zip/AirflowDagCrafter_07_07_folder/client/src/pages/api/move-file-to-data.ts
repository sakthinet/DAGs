// pages/api/move-file-to-data.ts
import { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ 
      success: false, 
      message: 'Method not allowed' 
    });
  }

  try {
    const { fileName, targetPath } = req.body;

    if (!fileName || !targetPath) {
      return res.status(400).json({
        success: false,
        message: 'fileName and targetPath are required'
      });
    }

    // Assume uploaded files are temporarily stored in uploads folder
    const tempDir = path.join(process.cwd(), 'uploads');
    const sourcePath = path.join(tempDir, fileName);
    
    // Ensure target directory exists
    const targetDir = path.dirname(targetPath);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    // Check if source file exists
    if (!fs.existsSync(sourcePath)) {
      return res.status(404).json({
        success: false,
        message: `Source file not found: ${fileName}`
      });
    }

    // Check if target file already exists
    if (fs.existsSync(targetPath)) {
      // Backup existing file
      const backupPath = targetPath.replace(/(\.[^.]+)$/, `_backup_${Date.now()}$1`);
      fs.copyFileSync(targetPath, backupPath);
      console.log(`Existing file backed up to: ${backupPath}`);
    }

    // Copy file to target location
    fs.copyFileSync(sourcePath, targetPath);
    
    // Verify the file was copied successfully
    if (!fs.existsSync(targetPath)) {
      throw new Error('File copy verification failed');
    }

    // Optional: Remove the temporary file
    // fs.unlinkSync(sourcePath);

    return res.status(200).json({
      success: true,
      message: `File successfully moved to data directory`,
      sourcePath,
      targetPath,
      fileSize: fs.statSync(targetPath).size
    });

  } catch (error) {
    console.error('Error moving file to data directory:', error);
    
    return res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Failed to move file to data directory'
    });
  }
}