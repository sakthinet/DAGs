import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  ArrowRight, 
  Copy, 
  Download, 
  CheckCircle, 
  Rocket, 
  Play, 
  FileText, 
  Database, 
  Activity, 
  BarChart3,
  AlertCircle,
  Loader2,
  RefreshCw,
  Zap,
  XCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";

// Consolidated API request function
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: { 'Content-Type': 'application/json' },
    ...(body && { body: JSON.stringify(body) })
  };

  console.log(`Making API request: ${method} ${url}`);
  const response = await fetch(url, options);
  console.log(`API response status: ${response.status} ${response.statusText}`);
  
  return response;
};

// Consolidated response parser
const parseApiResponse = async (response: Response) => {
  const contentType = response.headers.get('content-type');
  
  if (contentType && contentType.includes('application/json')) {
    try {
      return await response.json();
    } catch (error) {
      console.error('Failed to parse JSON response:', error);
      throw new Error('Invalid JSON response from server');
    }
  } else {
    const text = await response.text();
    console.error('Received non-JSON response:', text.substring(0, 200));
    throw new Error(`Server returned ${response.status}: Expected JSON but received HTML. The API endpoint may not be available.`);
  }
};

// Types
interface DagConfig {
  dagId: string;
  inputDirectory: string;
  outputDirectory: string;
  csvFileName: string;
  description: string;
  scheduleInterval: string;
  dagsDirectory: string;
}

interface UploadedFile {
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
}

interface ScriptGeneratorProps {
  config: DagConfig;
  generatedScript: string;
  onNext: () => void;
  onPrev: () => void;
  onViewDashboard: () => void;
  uploadedFile: UploadedFile | null;
}

// Optimized polling configuration
const POLLING_CONFIG = {
  IMMEDIATE_DELAY: 500,
  ULTRA_FAST_INTERVAL: 500,
  FAST_INTERVAL: 1000,
  NORMAL_INTERVAL: 2000,
  SLOW_INTERVAL: 5000,
  ULTRA_FAST_ATTEMPTS: 6,
  FAST_ATTEMPTS: 12,
  NORMAL_ATTEMPTS: 18,
  MAX_TOTAL_ATTEMPTS: 30,
  TIMEOUT_MS: 2000
};

export function ScriptGenerator({ 
  config, 
  generatedScript, 
  onNext, 
  onPrev, 
  onViewDashboard,
  uploadedFile 
}: ScriptGeneratorProps) {
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [isTriggering, setIsTriggering] = useState(false);
  const [dagDeployed, setDagDeployed] = useState(true);
  const [dagTriggered, setDagTriggered] = useState(false);
  const [validationStatus, setValidationStatus] = useState({
    syntax: true,
    dagId: true,
    filePaths: true,
    dependencies: true,
    fileLocation: true
  });
  const [testResults, setTestResults] = useState<any>(null);
  
  // Optimized DAG status tracking
  const [dagCheckAttempts, setDagCheckAttempts] = useState(0);
  const [isCheckingDagStatus, setIsCheckingDagStatus] = useState(false);
  const [dagStatusMessage, setDagStatusMessage] = useState<string>('');
  const [lastDagCheck, setLastDagCheck] = useState<Date | null>(null);
  const [dagAvailableInAirflow, setDagAvailableInAirflow] = useState(false);
  
  const { toast } = useToast();
  const { 
    triggerDag, 
    getDag, 
    loading: airflowLoading, 
    error: airflowError 
  } = useAirflowApi();

  // Consolidated DAG availability checker
  const checkDagAvailabilitySimple = useCallback(async (dagId: string): Promise<boolean> => {
    try {
      console.log(`🔍 Quick check for DAG: ${dagId}`);
      
      const timeoutPromise = new Promise<boolean>((_, reject) => {
        setTimeout(() => reject(new Error('Request timeout')), POLLING_CONFIG.TIMEOUT_MS);
      });
      
      const requestPromise = (async () => {
        const result = await getDag(dagId, true);
        return !!(result?.dag);
      })();
      
      const isAvailable = await Promise.race([requestPromise, timeoutPromise]);
      
      if (isAvailable) {
        console.log(`✅ DAG ${dagId} found in Airflow!`);
        return true;
      }
      
      return false;
    } catch (error) {
      console.log(`❌ DAG check failed for ${dagId}:`, error);
      return false;
    }
  }, [getDag]);

  // Optimized polling with consolidated intervals
  const startFastDagPolling = useCallback(async (dagId: string) => {
    if (isCheckingDagStatus) {
      console.log('DAG polling already in progress, skipping...');
      return;
    }

    setIsCheckingDagStatus(true);
    setDagCheckAttempts(0);
    setDagStatusMessage('Starting immediate DAG scan...');
    setLastDagCheck(new Date());
    setDagAvailableInAirflow(false);

    let attempts = 0;
    let found = false;

    try {
      console.log(`🚀 Starting ultra-fast polling for DAG: ${dagId}`);
      
      while (attempts < POLLING_CONFIG.MAX_TOTAL_ATTEMPTS && !found) {
        attempts++;
        setDagCheckAttempts(attempts);
        
        let currentInterval: number;
        let currentMessage: string;
        
        if (attempts <= POLLING_CONFIG.ULTRA_FAST_ATTEMPTS) {
          currentInterval = POLLING_CONFIG.ULTRA_FAST_INTERVAL;
          currentMessage = `Immediate scan (${attempts}/${POLLING_CONFIG.ULTRA_FAST_ATTEMPTS})`;
        } else if (attempts <= POLLING_CONFIG.FAST_ATTEMPTS) {
          currentInterval = POLLING_CONFIG.FAST_INTERVAL;
          currentMessage = `Quick scan (${attempts - POLLING_CONFIG.ULTRA_FAST_ATTEMPTS}/${POLLING_CONFIG.FAST_ATTEMPTS - POLLING_CONFIG.ULTRA_FAST_ATTEMPTS})`;
        } else if (attempts <= POLLING_CONFIG.NORMAL_ATTEMPTS) {
          currentInterval = POLLING_CONFIG.NORMAL_INTERVAL;
          currentMessage = `Standard check (${attempts - POLLING_CONFIG.FAST_ATTEMPTS}/${POLLING_CONFIG.NORMAL_ATTEMPTS - POLLING_CONFIG.FAST_ATTEMPTS})`;
        } else {
          currentInterval = POLLING_CONFIG.SLOW_INTERVAL;
          currentMessage = `Deep scan (${attempts - POLLING_CONFIG.NORMAL_ATTEMPTS}/${POLLING_CONFIG.MAX_TOTAL_ATTEMPTS - POLLING_CONFIG.NORMAL_ATTEMPTS})`;
        }
        
        setDagStatusMessage(currentMessage);
        
        console.log(`Polling attempt ${attempts}/${POLLING_CONFIG.MAX_TOTAL_ATTEMPTS} for DAG: ${dagId}`);
        
        const isAvailable = await checkDagAvailabilitySimple(dagId);
        
        if (isAvailable) {
          found = true;
          setDagAvailableInAirflow(true);
          setDagDeployed(true);
          setDagStatusMessage(`✅ DAG found and ready! (${attempts} attempts, ${(attempts * currentInterval / 1000).toFixed(1)}s)`);
          
          setValidationStatus(prev => ({
            ...prev,
            dependencies: true,
            fileLocation: true,
            dagId: true
          }));

          toast({
            title: "🎉 DAG is live!",
            description: `DAG ${dagId} detected in ${attempts} attempts (${(attempts * currentInterval / 1000).toFixed(1)}s)`,
          });
          
          console.log(`✅ DAG ${dagId} found after ${attempts} attempts!`);
          break;
        }
        
        if (attempts < POLLING_CONFIG.MAX_TOTAL_ATTEMPTS) {
          await new Promise(resolve => setTimeout(resolve, currentInterval));
        }
      }
      
      if (!found) {
        setDagAvailableInAirflow(false);
        setDagDeployed(false);
        setDagStatusMessage(`⚠️ DAG not detected after ${attempts} attempts`);

        toast({
          title: "DAG Detection Failed",
          description: `DAG not found after ${attempts} attempts. Try Force Refresh or check Airflow logs.`,
          variant: "destructive",
          duration: 10000,
        });
      }
      
    } catch (error) {
      setDagAvailableInAirflow(false);
      setDagStatusMessage('❌ Polling failed - check Airflow connection');
      setDagDeployed(false);
      
      toast({
        title: "DAG status check failed",
        description: error instanceof Error ? error.message : 'Unable to check DAG status',
        variant: "destructive",
      });
      
    } finally {
      setIsCheckingDagStatus(false);
      setLastDagCheck(new Date());
    }
  }, [isCheckingDagStatus, checkDagAvailabilitySimple, toast]);

  // Start polling when component mounts and DAG is deployed
  useEffect(() => {
    if (dagDeployed && config.dagId && !isCheckingDagStatus && !dagAvailableInAirflow) {
      console.log('🚀 Auto-starting DAG availability check...');
      
      const timer = setTimeout(() => {
        startFastDagPolling(config.dagId);
      }, POLLING_CONFIG.IMMEDIATE_DELAY);
      
      return () => clearTimeout(timer);
    }
  }, [dagDeployed, config.dagId, startFastDagPolling, isCheckingDagStatus, dagAvailableInAirflow]);

  // Consolidated refresh function
  const forceRefreshAirflowDags = async () => {
    try {
      console.log('🔄 Forcing Airflow DAGs refresh...');
      const response = await fetch('/api/airflow/refresh-dags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      const result = await response.json();
      if (result.success) {
        console.log('✅ Airflow DAGs refresh triggered:', result.message);
        return true;
      } else {
        console.warn('⚠️ DAG refresh failed:', result.message);
        return false;
      }
    } catch (error) {
      console.error('❌ Failed to trigger DAG refresh:', error);
      return false;
    }
  };

  // Manual refresh handler
  const handleForceRefreshDagStatus = async () => {
    if (config.dagId) {
      console.log('🔄 Manual fast refresh triggered with Airflow refresh');
      
      setDagAvailableInAirflow(false);
      setDagDeployed(false);
      
      const refreshSuccess = await forceRefreshAirflowDags();
      
      toast({
        title: refreshSuccess ? "Airflow refreshed" : "Cache cleared",
        description: refreshSuccess ? 
          "Forced Airflow DAG refresh and starting detection..." :
          "Cleared cache and starting detection...",
      });
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      await startFastDagPolling(config.dagId);
    }
  };

  // Utility functions
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedScript);
      toast({
        title: "Code copied",
        description: "DAG script has been copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Failed to copy code to clipboard",
        variant: "destructive",
      });
    }
  };

  const downloadScript = () => {
    const blob = new Blob([generatedScript], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${config.dagId}.py`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download started",
      description: `${config.dagId}.py has been downloaded`,
    });
  };

  const validateDeployment = async () => {
    setIsValidating(true);
    try {
      const response = await apiRequest('POST', '/api/validate-deployment', {
        dagId: config.dagId,
        inputDirectory: config.inputDirectory,
        outputDirectory: config.outputDirectory,
        csvFileName: config.csvFileName,
        dagsDirectory: config.dagsDirectory
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      setValidationStatus(result.validation || validationStatus);
      
      if (result.success) {
        toast({
          title: "Validation completed",
          description: "All deployment checks passed successfully",
        });
      } else {
        toast({
          title: "Validation issues found",
          description: result.message || "Some validation checks failed",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Validation failed:', error);
      toast({
        title: "Validation failed",
        description: error instanceof Error ? error.message : "Failed to validate deployment",
        variant: "destructive",
      });
    } finally {
      setIsValidating(false);
    }
  };

  const saveToDagsDirectory = async () => {
    setIsSaving(true);
    try {
      const response = await apiRequest('POST', '/api/save-dag', {
        dagId: config.dagId,
        dagScript: generatedScript,
        dagsDirectory: config.dagsDirectory
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      if (result.success) {
        setDagDeployed(true);
        toast({
          title: "DAG saved successfully",
          description: result.note ? 
            `${result.note} File saved to: ${result.filePath}` : 
            `Saved to ${result.filePath}`,
        });
        
        // Start fast polling immediately
        setTimeout(() => startFastDagPolling(config.dagId), 1000);
      } else {
        throw new Error(result.message || 'Failed to save DAG');
      }
    } catch (error) {
      console.error('Save failed:', error);
      toast({
        title: "Save failed",
        description: error instanceof Error ? error.message : "Failed to save DAG to directory",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const testDag = async () => {
    setIsTesting(true);
    setTestResults(null);
    
    try {
      console.log(`Testing DAG: ${config.dagId}`);
      
      const response = await apiRequest('POST', '/api/test-dag', {
        dagId: config.dagId,
        dagScript: generatedScript
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      setTestResults(result);
      
      if (result.success) {
        // Update validation status with results
        if (result.validation) {
          setValidationStatus(result.validation);
        }
        
        toast({
          title: "DAG test completed",
          description: "DAG syntax and structure validation passed successfully",
        });
      } else {
        // Update validation status even on failure
        if (result.validation) {
          setValidationStatus(result.validation);
        }
        
        const errorDetails = result.errors && result.errors.length > 0 
          ? `Issues found: ${result.errors.join(', ')}` 
          : result.message || "DAG validation failed";
        
        toast({
          title: "DAG test failed",
          description: errorDetails,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Test failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to test DAG';
      
      // Set failed validation status
      setValidationStatus(prev => ({
        ...prev,
        syntax: false,
        dependencies: false
      }));
      
      setTestResults({
        success: false,
        message: errorMessage,
        errors: [errorMessage]
      });
      
      toast({
        title: "Test failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsTesting(false);
    }
  };

  // Enhanced deploy function with file scan trigger
  const deployToAirflow = async () => {
    setIsDeploying(true);
    try {
      // First save the DAG
      const response = await apiRequest('POST', '/api/save-dag', {
        dagId: config.dagId,
        dagScript: generatedScript,
        dagsDirectory: config.dagsDirectory
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      if (result.success) {
        setDagDeployed(true);
        toast({
          title: "DAG file saved",
          description: `DAG ${config.dagId} saved. Triggering Airflow scan...`,
        });

        // STEP 1: Trigger file system scan immediately
        const scanTriggered = await triggerAirflowFileScan();
        
        if (scanTriggered) {
          toast({
            title: "File scan triggered",
            description: "Airflow file scanner activated. Starting detection...",
          });
        }

        // STEP 2: Wait for Airflow to process the scan
        await new Promise(resolve => setTimeout(resolve, 3000));

        // STEP 3: Start immediate fast polling
        await startFastDagPolling(config.dagId);
        
      } else {
        throw new Error(result.message || 'Deployment failed');
      }
    } catch (error) {
      console.error('Deployment failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to deploy DAG to Airflow';
      toast({
        title: "Deployment failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsDeploying(false);
    }
  };

  // Add file scan trigger function
  const triggerAirflowFileScan = async () => {
    try {
      console.log('🔄 Triggering Airflow file system scan...');
      const response = await fetch('/api/airflow/trigger-file-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      const result = await response.json();
      if (result.success) {
        console.log('✅ File scan triggered:', result.message);
        return true;
      } else {
        console.warn('⚠️ File scan trigger failed:', result.message);
        return false;
      }
    } catch (error) {
      console.error('❌ Failed to trigger file scan:', error);
      return false;
    }
  };

  // Add a helper to check if the DAG file exists in the Airflow DAGs directory
  const checkDagFileExists = async (dagId: string, dagsDirectory: string) => {
    try {
      const filePath = `${dagsDirectory}\\${dagId}.py`;
      const response = await fetch('/api/verify-file-exists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath }),
      });
      const result = await response.json();
      return result.exists;
    } catch {
      return false;
    }
  };

  // Optimized trigger with faster checks
  const triggerDagRun = async () => {
    setIsTriggering(true);
    try {
      console.log(`🚀 Attempting to trigger DAG: ${config.dagId}`);
      
      // Quick check if DAG is available before triggering
      if (!dagAvailableInAirflow) {
        const quickCheck = await checkDagAvailabilitySimple(config.dagId);
        if (quickCheck) {
          setDagAvailableInAirflow(true);
          setDagDeployed(true);
        } else {
          throw new Error(`DAG "${config.dagId}" not found in Airflow. Please wait for it to load.`);
        }
      }
      
      // Use the enhanced trigger method
      const result = await triggerDag(config.dagId, {
        input_directory: config.inputDirectory,
        output_directory: config.outputDirectory,
        csv_file: config.csvFileName,
        description: config.description,
        generated_at: new Date().toISOString()
      });
      
      if (result && (result.dag_run || result.success)) {
        setDagTriggered(true);
        toast({
          title: "🚀 DAG Run Started!",
          description: `DAG run started successfully. Monitor progress in the dashboard.`,
        });
        
        // Auto-navigate suggestion
        setTimeout(() => {
          toast({
            title: "View Progress",
            description: "Click 'View in Dashboard' to monitor your DAG run",
          });
        }, 3000);
      } else {
        throw new Error('No DAG run information returned');
      }
    } catch (error) {
      console.error('Failed to trigger DAG:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to trigger DAG run';
      
      // Check if it's a availability issue and offer to check again
      if (errorMessage.includes('not found') || errorMessage.includes('not ready')) {
        toast({
          title: "DAG not ready",
          description: errorMessage + " Checking availability...",
          variant: "destructive",
        });
        
        // Quick recheck
        if (!isCheckingDagStatus) {
          setTimeout(() => startFastDagPolling(config.dagId), 1000);
        }
      } else {
        toast({
          title: "Failed to trigger DAG",
          description: errorMessage,
          variant: "destructive",
        });
      }
    } finally {
      setIsTriggering(false);
    }
  };

  // Enhanced validation results with real-time status
  const validationResults = [
    { label: "Syntax validation", icon: CheckCircle, status: validationStatus.syntax ? "success" : "error" },
    { label: "DAG ID is unique", icon: CheckCircle, status: validationStatus.dagId ? "success" : "error" },
    { label: "File paths validated", icon: CheckCircle, status: validationStatus.filePaths ? "success" : "error" },
    { label: "Dependencies available", icon: CheckCircle, status: validationStatus.dependencies ? "success" : "error" },
    { 
      label: "DAG loaded in Airflow", 
      icon: isCheckingDagStatus ? Loader2 : (dagAvailableInAirflow ? CheckCircle : XCircle), 
      status: isCheckingDagStatus ? "checking" : (dagAvailableInAirflow ? "success" : "error")
    }
  ];

  return (
    <div className="max-w-6xl">
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Generated Code */}
        <div className="lg:col-span-2">
          <Card className="shadow-sm border border-gray-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="text-lg font-semibold text-slate-800">
                Generated DAG Script
              </CardTitle>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  <Copy className="mr-1 h-4 w-4" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadScript}>
                  <Download className="mr-1 h-4 w-4" />
                  Download
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <pre className="text-sm bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto max-h-96 custom-scrollbar">
                  <code className="language-python">{generatedScript}</code>
                </pre>
              </div>
              
              {/* Fast DAG Detection Section */}
              {dagDeployed && (
                <Card className="shadow-sm border border-gray-200 mt-4">
                  <CardHeader>
                    <CardTitle className="text-base font-semibold text-slate-800 flex items-center">
                      <Activity className="mr-2 h-4 w-4" />
                      Fast DAG Detection
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Status Message */}
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Status:</span>
                      <span className={`text-sm ${
                        dagAvailableInAirflow ? 'text-green-600' : 
                        isCheckingDagStatus ? 'text-blue-600' : 
                        'text-orange-600'
                      }`}>
                        {dagStatusMessage || 'Ready to scan'}
                      </span>
                    </div>

                    {/* Progress Information */}
                    {isCheckingDagStatus && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Attempt {dagCheckAttempts} of {POLLING_CONFIG.MAX_TOTAL_ATTEMPTS}</span>
                          <span>{Math.round((dagCheckAttempts / POLLING_CONFIG.MAX_TOTAL_ATTEMPTS) * 100)}%</span>
                        </div>
                        
                        <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300 ease-out"
                            style={{ 
                              width: `${Math.min(100, (dagCheckAttempts / POLLING_CONFIG.MAX_TOTAL_ATTEMPTS) * 100)}%` 
                            }}
                          ></div>
                        </div>
                        
                        {lastDagCheck && (
                          <div className="text-xs text-gray-500 text-center">
                            Time elapsed: {Math.round((Date.now() - lastDagCheck.getTime()) / 1000)}s
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={handleForceRefreshDagStatus}
                        disabled={isCheckingDagStatus}
                        className="flex-1"
                      >
                        {isCheckingDagStatus ? (
                          <>
                            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                            Scanning...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="mr-1 h-3 w-3" />
                            Force Refresh
                          </>
                        )}
                      </Button>
                    </div>

                    {/* Success/Failure States */}
                    {dagAvailableInAirflow && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center text-green-800">
                          <CheckCircle className="mr-2 h-4 w-4" />
                          <span className="text-sm font-medium">DAG Successfully Detected!</span>
                        </div>
                        <div className="text-xs text-green-700 mt-1">
                          Ready to trigger or view in dashboard
                        </div>
                      </div>
                    )}

                    {!dagAvailableInAirflow && !isCheckingDagStatus && dagCheckAttempts > 0 && (
                      <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                        <div className="flex items-center text-red-800">
                          <XCircle className="mr-2 h-4 w-4" />
                          <span className="text-sm font-medium">DAG Not Detected</span>
                        </div>
                        <div className="text-xs text-red-700 mt-1">
                          Try triggering a file scan or restart Airflow container if needed
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* File Status */}
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <h4 className="text-sm font-medium text-gray-800 mb-2">File Status</h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div className="flex items-center">
                    <Database className="mr-2 h-4 w-4 text-green-600" />
                    <div>
                      <div className="font-medium">Input Directory</div>
                      <div className="text-gray-600 break-all">{config.inputDirectory}</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <FileText className="mr-2 h-4 w-4 text-blue-600" />
                    <div>
                      <div className="font-medium">Output Directory</div>
                      <div className="text-gray-600 break-all">{config.outputDirectory}</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <FileText className="mr-2 h-4 w-4 text-orange-600" />
                    <div>
                      <div className="font-medium">CSV File Pattern</div>
                      <div className="text-gray-600 break-all">{config.csvFileName || '*.csv (all files)'}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Enhanced deployment status */}
              {dagAvailableInAirflow && !isCheckingDagStatus && (
                <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-green-700">
                      <CheckCircle className="mr-2 h-4 w-4" />
                      <div className="font-medium">DAG Successfully Detected & Ready!</div>
                    </div>
                    <div className="text-xs text-green-600">
                      {lastDagCheck && `Verified at ${lastDagCheck.toLocaleTimeString()}`}
                    </div>
                  </div>
                  <div className="text-sm text-green-600 mt-1">
                    Your DAG is live in Airflow and ready to trigger
                  </div>
                </div>
              )}

              {/* Trigger Status */}
              {dagTriggered && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center text-blue-700">
                    <Activity className="mr-2 h-4 w-4" />
                    <div className="font-medium">DAG Run Started</div>
                  </div>
                  <div className="text-sm text-blue-600 mt-1">
                    Check the dashboard to monitor progress
                  </div>
                </div>
              )}

              {/* Test Results */}
              {testResults && (
                <div className={`mt-4 p-3 rounded-lg border ${
                  testResults.success 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-red-50 border-red-200'
                }`}>
                  <div className={`flex items-center ${
                    testResults.success ? 'text-green-700' : 'text-red-700'
                  }`}>
                    {testResults.success ? (
                      <CheckCircle className="mr-2 h-4 w-4" />
                    ) : (
                      <XCircle className="mr-2 h-4 w-4" />
                    )}
                    <div className="font-medium">
                      {testResults.success ? 'Test Passed' : 'Test Failed'}
                    </div>
                  </div>
                  <div className={`text-sm mt-1 ${
                    testResults.success ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {testResults.message}
                  </div>
                  {testResults.errors && testResults.errors.length > 0 && (
                    <div className="mt-2">
                      {testResults.errors.map((error: string, index: number) => (
                        <div key={index} className="text-xs text-red-600 mt-1">
                          • {error}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Actions Panel */}
        <div className="space-y-6">
          {/* Deployment Actions */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Deployment Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-green-600 bg-green-50 p-3 rounded-lg border border-green-200">
                <div className="font-medium mb-1">✓ Auto-deployed to DAGs directory</div>
                <div className="text-xs text-green-700">
                  Script automatically saved to: {config.dagsDirectory}
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={downloadScript}
              >
                <div className="text-left">
                  <div className="font-medium">Download Copy</div>
                  <div className="text-xs text-muted-foreground">Save backup to local machine</div>
                </div>
                <Download className="h-4 w-4" />
              </Button>

              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={validateDeployment}
                disabled={isValidating}
              >
                <div className="text-left">
                  <div className="font-medium">
                    {isValidating ? 'Validating...' : 'Re-validate Deployment'}
                  </div>
                  <div className="text-xs text-muted-foreground">Check file locations & paths</div>
                </div>
                {isValidating ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle className="h-4 w-4" />
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Enhanced Airflow Integration */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Airflow Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-700">DAG Status</span>
                <div className="flex items-center">
                  {isCheckingDagStatus ? (
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                      <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                      Scanning...
                    </Badge>
                  ) : dagAvailableInAirflow ? (
                    <Badge variant="default" className="bg-green-600">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      Ready
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-orange-600 border-orange-600">
                      <AlertCircle className="mr-1 h-3 w-3" />
                      Scanning
                    </Badge>
                  )}
                </div>
              </div>
              
              {/* Status message */}
              {dagStatusMessage && (
                <div className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                  {dagStatusMessage}
                </div>
              )}
              
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                onClick={deployToAirflow}
                disabled={isDeploying || isCheckingDagStatus}
              >
                {isDeploying ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deploying...
                  </>
                ) : (
                  <>
                    <Rocket className="mr-2 h-4 w-4" />
                    Re-deploy to Airflow
                  </>
                )}
              </Button>

              {/* Fast refresh button */}
              <Button 
                variant="outline" 
                className="w-full"
                onClick={handleForceRefreshDagStatus}
                disabled={isCheckingDagStatus}
              >
                {isCheckingDagStatus ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Fast Scanning...
                  </>
                ) : (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Quick Status Check
                  </>
                )}
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full"
                onClick={testDag}
                disabled={isTesting}
              >
                {isTesting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Test DAG Syntax
                  </>
                )}
              </Button>

              {/* Enhanced Trigger Button - Enables faster detection */}
              <Button 
                className={`w-full text-white ${
                  dagAvailableInAirflow && !isCheckingDagStatus 
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-gray-400 cursor-not-allowed'
                }`}
                onClick={triggerDagRun}
                disabled={isTriggering || airflowLoading || (!dagAvailableInAirflow && !isCheckingDagStatus)}
              >
                {isTriggering ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Triggering...
                  </>
                ) : !dagAvailableInAirflow && isCheckingDagStatus ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4" />
                    Scanning for DAG...
                  </>
                ) : !dagAvailableInAirflow ? (
                  <>
                    <AlertCircle className="mr-2 h-4 w-4" />
                    DAG Not Ready
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-4 w-4" />
                    Trigger DAG Run
                  </>
                )}
              </Button>

              {/* View in Dashboard */}
              <Button 
                variant="outline"
                className="w-full"
                onClick={onViewDashboard}
              >
                <BarChart3 className="mr-2 h-4 w-4" />
                View in Dashboard
              </Button>
            </CardContent>
          </Card>

          {/* Enhanced Validation Results */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Validation Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Enhanced validation results with real-time status */}
              <div className="grid grid-cols-1 gap-3">
                {validationResults.map((result, index) => (
                  <div key={index} className={`flex items-center justify-between p-3 rounded-lg ${
                    result.status === 'success' ? 'bg-green-50 border border-green-200' :
                    result.status === 'checking' ? 'bg-blue-50 border border-blue-200' :
                    'bg-red-50 border border-red-200'
                  }`}>
                    <div className="flex items-center">
                      <result.icon className={`mr-2 h-4 w-4 ${
                        result.status === 'success' ? 'text-green-600' :
                        result.status === 'checking' ? 'text-blue-600 animate-spin' :
                        'text-red-600'
                      }`} />
                      <span className="text-sm font-medium">{result.label}</span>
                    </div>
                    
                    {result.label === "DAG loaded in Airflow" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleForceRefreshDagStatus}
                        disabled={isCheckingDagStatus}
                        className="ml-2"
                      >
                        {isCheckingDagStatus ? (
                          <>
                            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                            Checking...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="mr-1 h-3 w-3" />
                            Force Refresh
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              
              {/* Additional timing info */}
              {lastDagCheck && (
                <div className="pt-2 border-t border-gray-200">
                  <div className="text-xs text-gray-500">
                    Last checked: {lastDagCheck.toLocaleTimeString()}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Optimized DAG Scanner Info */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Fast DAG Detection</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-xs text-gray-600 space-y-1">
                <div>• Fast interval: 1s (first 8 attempts)</div>
                <div>• Normal interval: 2s (next 10 attempts)</div>
                <div>• Slow interval: 5s (final attempts)</div>
                <div>• Max detection time: ~60s</div>
                <div>• Location: {config.dagsDirectory}</div>
                <div>• Status: {isCheckingDagStatus ? 'Active Scanning' : 'Idle'}</div>
              </div>
            </CardContent>
          </Card>

          {/* File Locations */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">File Locations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-xs space-y-2">
                <div>
                  <div className="font-medium text-gray-700">DAG Script:</div>
                  <div className="text-gray-600 break-all font-mono">
                    {config.dagsDirectory}\{config.dagId}.py
                  </div>
                </div>
                <div>
                  <div className="font-medium text-gray-700">Data Directory:</div>
                  <div className="text-gray-600 break-all font-mono">
                    \\10.73.88.101\data
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Configuration
        </Button>
        <Button onClick={onNext}>
          View XML Output
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}