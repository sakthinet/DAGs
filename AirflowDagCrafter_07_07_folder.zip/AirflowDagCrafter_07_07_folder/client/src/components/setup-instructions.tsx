import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { FileText, FolderOpen, ArrowRight, CheckCircle, AlertCircle } from "lucide-react";

export function SetupInstructions() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5" />
            File Workflow Setup
          </CardTitle>
          <CardDescription>
            Understanding how your CSV files move through the system
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4">
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">1</Badge>
              <div className="space-y-1">
                <p className="font-medium">Upload CSV File</p>
                <p className="text-sm text-muted-foreground">
                  When you upload a CSV file, it's saved locally for you to copy to your Input CSV Path
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-center py-2">
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </div>
            
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">2</Badge>
              <div className="space-y-1">
                <p className="font-medium">Copy to Input Directory</p>
                <p className="text-sm text-muted-foreground">
                  Manually copy the CSV file from the local directory to your configured Input CSV Path
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-center py-2">
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </div>
            
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">3</Badge>
              <div className="space-y-1">
                <p className="font-medium">Airflow DAG Execution</p>
                <p className="text-sm text-muted-foreground">
                  The generated DAG will process all CSV files in your Input CSV Path and create XML files in your Output XML Path
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>Important:</strong> This application runs in a containerized environment and cannot directly access your Windows file system. 
          Files are saved locally with instructions for manual copying to your Airflow directories.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Path Configuration Guide
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <p className="font-medium">Input CSV Path</p>
            <p className="text-sm text-muted-foreground">
              Directory where your Airflow will look for CSV files to process (e.g., C:\Docker\airflow3x2\data)
            </p>
          </div>
          
          <div className="space-y-2">
            <p className="font-medium">Output XML Path</p>
            <p className="text-sm text-muted-foreground">
              Directory where converted XML files will be saved (e.g., C:\Docker\airflow3x2\data)
            </p>
          </div>
          
          <div className="space-y-2">
            <p className="font-medium">DAGs Directory</p>
            <p className="text-sm text-muted-foreground">
              Your Airflow DAGs folder where the generated Python script will be saved (e.g., C:\Docker\airflow3x2\dags)
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}