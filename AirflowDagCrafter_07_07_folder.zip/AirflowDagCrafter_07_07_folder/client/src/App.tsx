import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/contexts/theme-context";
import NotFound from "@/pages/not-found";
import DagGenerator from "@/pages/dag-generator";
import { useEffect } from "react";
import { initializeThemeSystem, debugThemeState } from "./utils/theme-init";

function Router() {
  return (
    <Switch>
      <Route path="/" component={DagGenerator} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Initialize theme system on app load
  useEffect(() => {
    // Initialize the theme system
    const currentTheme = initializeThemeSystem();
    
    // Debug theme state in development
    if (process.env.NODE_ENV === 'development') {
      setTimeout(() => {
        debugThemeState();
      }, 100);
    }
    
    console.log(`🎨 Theme system initialized with: ${currentTheme}`);
  }, []);

  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;