import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const dagConfigurations = pgTable("dag_configurations", {
  id: serial("id").primaryKey(),
  dagId: text("dag_id").notNull().unique(),
  inputPath: text("input_path").notNull(),
  outputPath: text("output_path").notNull(),
  description: text("description"),
  scheduleInterval: text("schedule_interval").default("None"),
  dagsDirectory: text("dags_directory").default("/opt/airflow/dags"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDagConfigurationSchema = createInsertSchema(dagConfigurations).omit({
  id: true,
  createdAt: true,
});

export const dagConfigurationSchema = z.object({
  dagId: z.string().min(1, "DAG ID is required").regex(/^[a-zA-Z][a-zA-Z0-9_]*$/, "DAG ID must start with a letter and contain only letters, numbers, and underscores"),
  inputDirectory: z.string().min(1, "Input directory is required"),
  outputDirectory: z.string().min(1, "Output directory is required"),
  csvFileName: z.string().optional(),
  description: z.string().optional(),
  scheduleInterval: z.string().optional(),
  dagsDirectory: z.string().optional(),
  chunkSize: z.coerce.number().int().min(1, "CHUNK_SIZE must be at least 1").default(5000),
  // Backward compatibility
  inputPath: z.string().optional(),
  outputPath: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDagConfiguration = z.infer<typeof insertDagConfigurationSchema>;
export type DagConfiguration = typeof dagConfigurations.$inferSelect;
export type DagConfigurationInput = z.infer<typeof dagConfigurationSchema>;
