import { useState, useCallback, useRef } from 'react';

// Enhanced API request function with retry logic
const apiRequestWithRetry = async (
  method: string, 
  url: string, 
  body?: any, 
  retries = 2,
  retryDelay = 1000
): Promise<Response> => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      console.log(`Making API request: ${method} ${url} (attempt ${attempt + 1}/${retries + 1})`);
      const response = await fetch(url, options);
      
      // Don't retry on client errors (4xx), only on server errors (5xx) or network issues
      if (response.ok || (response.status >= 400 && response.status < 500)) {
        return response;
      }
      
      if (attempt < retries) {
        console.log(`Request failed with status ${response.status}, retrying in ${retryDelay}ms...`);
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        retryDelay *= 1.5; // Exponential backoff
      } else {
        return response;
      }
    } catch (error) {
      if (attempt < retries) {
        console.log(`Network error, retrying in ${retryDelay}ms...`, error);
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        retryDelay *= 1.5;
      } else {
        throw error;
      }
    }
  }
  
  throw new Error('Max retries exceeded');
};

export interface DAG {
  dag_id: string;
  is_paused: boolean;
  is_active: boolean;
  last_parsed_time: string;
  last_pickled: string;
  last_expired: string;
  scheduler_lock: boolean;
  pickle_id: string;
  default_view: string;
  fileloc: string;
  file_token: string;
  owners: string[];
  description: string;
  schedule_interval: any;
  tags: string[];
  max_active_tasks: number;
  max_active_runs: number;
  has_task_concurrency_limits: boolean;
  has_import_errors: boolean;
  recent_runs: DAGRun[];
  run_count: number;
  tag_names?: string[];
  schedule_interval_display?: string;
}

export interface DAGRun {
  dag_run_id: string;
  dag_id: string;
  execution_date: string;
  logical_date?: string;
  start_date: string;
  end_date: string;
  state: 'success' | 'running' | 'failed' | 'queued' | 'scheduled';
  external_trigger: boolean;
  run_type: string;
  conf: any;
}

export interface TaskInstance {
  task_id: string;
  dag_id: string;
  run_id: string;
  execution_date: string;
  start_date: string;
  end_date: string;
  state: string;
  try_number: number;
  max_tries: number;
  hostname: string;
  unixname: string;
  job_id: number;
  pool: string;
  pool_slots: number;
  queue: string;
  priority_weight: number;
  operator: string;
  queued_dttm: string;
  pid: number;
  executor_config: any;
}

export interface AirflowInfo {
  version: {
    version: string;
    git_version: string;
  };
  config: {
    airflow_version: string;
    executor: string;
    api_version: string;
  };
}

// Enhanced cache with invalidation strategies
class SmartRequestCache {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number; tags: string[] }>();
  
  set(key: string, data: any, ttlSeconds = 30, tags: string[] = []): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlSeconds * 1000,
      tags
    });
  }
  
  get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    
    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return null;
    }
    
    return entry.data;
  }
  
  invalidate(pattern: string): void {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
  
  invalidateByTag(tag: string): void {
    for (const [key, entry] of this.cache.entries()) {
      if (entry.tags.includes(tag)) {
        this.cache.delete(key);
      }
    }
  }
  
  clear(): void {
    this.cache.clear();
  }
  
  // Get cache statistics for debugging
  getStats() {
    const entries = Array.from(this.cache.entries());
    return {
      totalEntries: entries.length,
      activeEntries: entries.filter(([_, entry]) => 
        Date.now() - entry.timestamp <= entry.ttl
      ).length,
      expiredEntries: entries.filter(([_, entry]) => 
        Date.now() - entry.timestamp > entry.ttl
      ).length,
      entries: entries.map(([key, value]) => ({
        key,
        age: Date.now() - value.timestamp,
        ttl: value.ttl,
        expired: Date.now() - value.timestamp > value.ttl,
        tags: value.tags
      }))
    };
  }
}

// Safe property access helper
const safeGet = (obj: any, path: string, defaultValue: any = null): any => {
  if (!obj || typeof obj !== 'object') return defaultValue;
  
  const keys = path.split('.');
  let current = obj;
  
  for (const key of keys) {
    if (current === null || current === undefined || typeof current !== 'object') {
      return defaultValue;
    }
    current = current[key];
  }
  
  return current !== undefined ? current : defaultValue;
};

// Enhanced helper function to safely process schedule interval
const getScheduleInterval = (scheduleInterval: any): string => {
  try {
    if (!scheduleInterval) return 'None';
    if (typeof scheduleInterval === 'string') return scheduleInterval;
    if (typeof scheduleInterval === 'object' && scheduleInterval !== null) {
      if (scheduleInterval.__type) return scheduleInterval.__type;
      if (scheduleInterval.value) return scheduleInterval.value;
      return 'Complex Schedule';
    }
    return 'Unknown';
  } catch (error) {
    console.warn('Error processing schedule interval:', error);
    return 'Error';
  }
};

// Enhanced helper function to safely process tags with comprehensive null checks
const getTagNames = (tags: any): string[] => {
  try {
    // Handle null, undefined, or non-array inputs
    if (!tags) return [];
    if (!Array.isArray(tags)) return [];
    
    return tags
      .filter(tag => tag !== null && tag !== undefined) // Filter out null/undefined items
      .map(tag => {
        try {
          if (typeof tag === 'string') return tag;
          if (typeof tag === 'object' && tag !== null && safeGet(tag, 'name')) {
            return safeGet(tag, 'name', 'Unknown Tag');
          }
          return 'Unknown Tag';
        } catch (error) {
          console.warn('Error processing individual tag:', tag, error);
          return 'Error Tag';
        }
      });
  } catch (error) {
    console.warn('Error processing tags array:', error);
    return [];
  }
};

// Enhanced helper function to safely process arrays
const safeArray = (arr: any, defaultValue: any[] = []): any[] => {
  try {
    if (!arr) return defaultValue;
    if (!Array.isArray(arr)) return defaultValue;
    return arr.filter(item => item !== null && item !== undefined);
  } catch (error) {
    console.warn('Error processing array:', error);
    return defaultValue;
  }
};

// Enhanced helper function to safely convert to number
const safeNumber = (value: any, defaultValue: number = 0): number => {
  try {
    if (value === null || value === undefined) return defaultValue;
    const num = Number(value);
    return isNaN(num) ? defaultValue : num;
  } catch (error) {
    console.warn('Error converting to number:', value, error);
    return defaultValue;
  }
};

// Enhanced helper function to safely convert to boolean
const safeBoolean = (value: any, defaultValue: boolean = false): boolean => {
  try {
    if (value === null || value === undefined) return defaultValue;
    return Boolean(value);
  } catch (error) {
    console.warn('Error converting to boolean:', value, error);
    return defaultValue;
  }
};

// COMPLETELY REWRITTEN processDAGData function with comprehensive null safety
const processDAGData = (dag: any): DAG | null => {
  try {
    // Primary null check
    if (!dag || typeof dag !== 'object') {
      console.warn('processDAGData received null or invalid dag:', dag);
      return null;
    }

    // Validate essential fields
    const dagId = safeGet(dag, 'dag_id', '');
    if (!dagId || typeof dagId !== 'string') {
      console.warn('processDAGData received DAG without valid dag_id:', dag);
      return null;
    }

    console.log(`Processing DAG data for: ${dagId}`);

    // Process all fields with safe accessors
    const processedDAG: DAG = {
      dag_id: dagId,
      is_paused: safeBoolean(safeGet(dag, 'is_paused'), false),
      is_active: safeBoolean(safeGet(dag, 'is_active'), true),
      last_parsed_time: safeGet(dag, 'last_parsed_time', '') || '',
      last_pickled: safeGet(dag, 'last_pickled', '') || '',
      last_expired: safeGet(dag, 'last_expired', '') || '',
      scheduler_lock: safeBoolean(safeGet(dag, 'scheduler_lock'), false),
      pickle_id: safeGet(dag, 'pickle_id', '') || '',
      default_view: safeGet(dag, 'default_view', 'graph') || 'graph',
      fileloc: safeGet(dag, 'fileloc', '') || '',
      file_token: safeGet(dag, 'file_token', '') || '',
      owners: safeArray(safeGet(dag, 'owners'), []),
      description: safeGet(dag, 'description', '') || '',
      schedule_interval: safeGet(dag, 'schedule_interval'),
      tags: safeArray(safeGet(dag, 'tags'), []),
      max_active_tasks: safeNumber(safeGet(dag, 'max_active_tasks'), 16),
      max_active_runs: safeNumber(safeGet(dag, 'max_active_runs'), 16),
      has_task_concurrency_limits: safeBoolean(safeGet(dag, 'has_task_concurrency_limits'), false),
      has_import_errors: safeBoolean(safeGet(dag, 'has_import_errors'), false),
      recent_runs: safeArray(safeGet(dag, 'recent_runs'), []),
      run_count: safeNumber(safeGet(dag, 'run_count'), 0),
      tag_names: getTagNames(safeGet(dag, 'tags')),
      schedule_interval_display: getScheduleInterval(safeGet(dag, 'schedule_interval'))
    };

    console.log(`Successfully processed DAG: ${dagId}`);
    return processedDAG;
    
  } catch (error) {
    console.error('Critical error in processDAGData:', error, 'DAG data:', dag);
    return null;
  }
};

// Enhanced DAG run processing with null safety
const processDAGRunData = (run: any): DAGRun | null => {
  try {
    if (!run || typeof run !== 'object') {
      console.warn('processDAGRunData received null or invalid run:', run);
      return null;
    }

    const runId = safeGet(run, 'dag_run_id', '') || safeGet(run, 'run_id', '');
    const dagId = safeGet(run, 'dag_id', '');
    
    if (!runId || !dagId) {
      console.warn('processDAGRunData received run without valid IDs:', run);
      return null;
    }

    return {
      dag_run_id: runId,
      dag_id: dagId,
      execution_date: safeGet(run, 'execution_date', '') || '',
      logical_date: safeGet(run, 'logical_date', '') || safeGet(run, 'execution_date', '') || '',
      start_date: safeGet(run, 'start_date', '') || '',
      end_date: safeGet(run, 'end_date', '') || '',
      state: safeGet(run, 'state', 'queued') || 'queued',
      external_trigger: safeBoolean(safeGet(run, 'external_trigger'), false),
      run_type: safeGet(run, 'run_type', 'manual') || 'manual',
      conf: safeGet(run, 'conf', {}) || {}
    };
  } catch (error) {
    console.error('Error processing DAG run data:', error);
    return null;
  }
};

export function useAirflowApi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Enhanced cache with smart invalidation
  const cache = useRef(new SmartRequestCache()).current;
  
  // Track ongoing requests to prevent duplicate calls
  const ongoingRequests = useRef(new Map<string, Promise<any>>()).current;

  const handleRequest = useCallback(async <T>(
    requestFn: () => Promise<Response>,
    cacheKey?: string,
    cacheTTL = 30,
    skipCache = false,
    tags: string[] = []
  ): Promise<T | null> => {
    // Check cache first if not skipping cache
    if (!skipCache && cacheKey) {
      const cached = cache.get(cacheKey);
      if (cached) {
        console.log(`📦 Cache hit for: ${cacheKey}`);
        return cached as T;
      }
    }

    // Check if request is already ongoing
    if (cacheKey && ongoingRequests.has(cacheKey)) {
      console.log(`⏳ Request already ongoing for: ${cacheKey}`);
      return ongoingRequests.get(cacheKey);
    }

    setLoading(true);
    setError(null);
    
    const requestPromise = (async () => {
      try {
        const startTime = performance.now();
        const response = await requestFn();
        const endTime = performance.now();
        
        console.log(`⚡ Request completed in ${(endTime - startTime).toFixed(2)}ms`);
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`HTTP ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        // Enhanced success checking
        const isSuccessful = result.success !== false && 
                           (result.success === true || 
                            result.dags || 
                            result.connected !== undefined || 
                            result.dag || 
                            result.runs || 
                            result.task_instances ||
                            result.version);
        
        if (!isSuccessful) {
          throw new Error(result.message || 'Request failed');
        }
        
        // Cache successful responses with tags
        if (!skipCache && cacheKey) {
          cache.set(cacheKey, result, cacheTTL, tags);
          console.log(`💾 Cached result for: ${cacheKey} (TTL: ${cacheTTL}s, Tags: ${tags.join(', ')})`);
        }
        
        return result as T;
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
        setError(errorMessage);
        console.error('Airflow API error:', err);
        throw err;
      } finally {
        setLoading(false);
        if (cacheKey) {
          ongoingRequests.delete(cacheKey);
        }
      }
    })();

    // Track ongoing request
    if (cacheKey) {
      ongoingRequests.set(cacheKey, requestPromise);
    }

    try {
      return await requestPromise;
    } catch (err) {
      return null;
    }
  }, [cache, ongoingRequests]);

  // Enhanced pause/unpause with immediate cache invalidation
  const pauseUnpauseDag = useCallback(async (dagId: string, isPaused: boolean) => {
    try {
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      console.log(`${isPaused ? 'Pausing' : 'Unpausing'} DAG: ${dagId}`);
      
      const result = await handleRequest<{
        success: true;
        message: string;
        dag: any;
      }>(
        () => apiRequestWithRetry(
          'PATCH', 
          `/api/airflow/dags/${encodeURIComponent(dagId)}`, 
          { is_paused: isPaused }
        ),
        undefined, // Don't cache update requests
        0,
        true // Skip cache
      );
      
      if (result) {
        // Process the returned DAG data
        let processedDag: DAG | null = null;
        if (result.dag) {
          processedDag = processDAGData(result.dag);
        }
        
        // Immediately invalidate all related caches
        cache.invalidateByTag(dagId);
        cache.invalidateByTag('all_dags');
        console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
        
        return {
          ...result,
          dag: processedDag
        };
      }
      
      return result;
    } catch (error) {
      console.error(`❌ Failed to ${isPaused ? 'pause' : 'unpause'} DAG ${dagId}:`, error);
      throw error;
    }
  }, [handleRequest, cache]);

  // Pause DAG specifically
  const pauseDag = useCallback(async (dagId: string) => {
    return pauseUnpauseDag(dagId, true);
  }, [pauseUnpauseDag]);

  // Unpause DAG specifically
  const unpauseDag = useCallback(async (dagId: string) => {
    return pauseUnpauseDag(dagId, false);
  }, [pauseUnpauseDag]);

  // Enhanced auto-unpause function
  const autoUnpauseDag = useCallback(async (dagId: string) => {
    try {
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      console.log(`🔓 Auto-unpausing DAG: ${dagId}`);
      
      const result = await handleRequest<{
        success: true;
        unpaused: boolean;
        message: string;
        dagId: string;
      }>(
        () => apiRequestWithRetry('POST', `/api/airflow/dags/${encodeURIComponent(dagId)}/auto-unpause`),
        undefined, // Don't cache unpause requests
        0,
        true // Skip cache
      );
      
      if (result) {
        // Invalidate related caches
        cache.invalidateByTag(dagId);
        cache.invalidateByTag('all_dags');
        console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
        return result;
      } else {
        throw new Error('No response received from auto-unpause API');
      }
    } catch (error) {
      console.error(`❌ Failed to auto-unpause DAG ${dagId}:`, error);
      throw error;
    }
  }, [handleRequest, cache]);

  // Enhanced getDags with better performance
  const getDags = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'all_dags_enhanced';
    const tags = ['dags', 'all_dags'];
    
    try {
      console.log(`🔍 Fetching all DAGs... ${forceRefresh ? '(force refresh)' : ''}`);
      
      const result = await handleRequest<{ dags: any[]; total: number; success: true }>(
        () => apiRequestWithRetry('GET', '/api/airflow/dags'),
        cacheKey,
        forceRefresh ? 10 : 30, // Shorter cache on force refresh
        forceRefresh,
        tags
      );
      
      if (result && result.dags) {
        console.log(`📋 Processing ${result.dags.length} DAGs...`);
        
        const processedDAGs = result.dags
          .map((dag, index) => {
            try {
              return processDAGData(dag);
            } catch (error) {
              console.error(`Error processing DAG at index ${index}:`, error);
              return null;
            }
          })
          .filter((dag): dag is DAG => dag !== null);
        
        console.log(`✅ Successfully processed ${processedDAGs.length} DAGs`);
        
        return {
          ...result,
          dags: processedDAGs,
          total: processedDAGs.length
        };
      }
      
      return null;
    } catch (error) {
      console.error('❌ Failed to get DAGs:', error);
      return null;
    }
  }, [handleRequest]);

  // Enhanced getDag with better caching strategy
  const getDag = useCallback(async (dagId: string, forceRefresh = false) => {
    const cacheKey = `dag_details_${dagId}`;
    const tags = ['dag', dagId, 'dag_details'];
    
    try {
      console.log(`🔍 Getting DAG details for: ${dagId} ${forceRefresh ? '(force refresh)' : ''}`);
      
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        console.error('Invalid dagId provided to getDag:', dagId);
        return null;
      }
      
      const result = await handleRequest<{
        dag: any;
        runs: any[];
        tasks: any[];
        success: true;
      }>(
        () => apiRequestWithRetry('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}`),
        cacheKey,
        forceRefresh ? 5 : 60, // Short cache on force refresh, longer otherwise
        forceRefresh,
        tags
      );
      
      if (!result) {
        console.warn(`No result received for DAG: ${dagId}`);
        return null;
      }
      
      // Process DAG data with enhanced null safety
      let processedDag: DAG | null = null;
      if (result.dag) {
        try {
          processedDag = processDAGData(result.dag);
          if (processedDag) {
            console.log(`✅ Successfully processed DAG: ${dagId}`);
          }
        } catch (error) {
          console.error(`Error processing DAG data for ${dagId}:`, error);
        }
      }
      
      return {
        ...result,
        dag: processedDag,
        runs: result.runs ? result.runs.map(run => processDAGRunData(run)).filter(Boolean) : [],
        tasks: result.tasks ? safeArray(result.tasks) : []
      };
      
    } catch (error) {
      console.error(`❌ Failed to get DAG ${dagId}:`, error);
      
      // Don't throw error for 404 as it means DAG doesn't exist yet
      if (error instanceof Error && error.message.includes('404')) {
        console.log(`DAG ${dagId} not found in Airflow (this is normal for new DAGs)`);
      }
      
      return null;
    }
  }, [handleRequest]);

  // Enhanced getDag with auto-unpause option
  const getDagWithAutoUnpause = useCallback(async (dagId: string, autoUnpause = false, forceRefresh = false) => {
    const cacheKey = `dag_details_auto_${dagId}_${autoUnpause}`;
    const tags = ['dag', dagId, 'dag_details'];

    try {
      console.log(`🔍 Getting DAG details for: ${dagId} ${autoUnpause ? '(with auto-unpause)' : ''} ${forceRefresh ? '(force refresh)' : ''}`);
      
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        console.error('Invalid dagId provided to getDagWithAutoUnpause:', dagId);
        return null;
      }
      
      const endpoint = autoUnpause ? 
        `/api/airflow/dags/${encodeURIComponent(dagId)}/status?auto_unpause=true` :
        `/api/airflow/dags/${encodeURIComponent(dagId)}`;
      
      const result = await handleRequest<{
        dag: any;
        runs?: any[];
        tasks?: any[];
        found?: boolean;
        is_paused?: boolean;
        unpauseResult?: { unpaused: boolean; message: string };
        success: true;
      }>(
        () => apiRequestWithRetry('GET', endpoint),
        cacheKey,
        forceRefresh ? 5 : 30, // Short cache on force refresh
        forceRefresh,
        tags
      );
      
      if (!result) {
        console.warn(`No result received for DAG: ${dagId}`);
        return null;
      }
      
      // Handle the different response formats
      let dagData = result.dag;
      let unpauseInfo = result.unpauseResult;
      
      // If this was a status check, get additional details
      if (result.found && !result.runs && !result.tasks) {
        try {
          const detailsResult = await handleRequest<{
            dag: any;
            runs: any[];
            tasks: any[];
            success: true;
          }>(
            () => apiRequestWithRetry('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}`),
            `dag_details_${dagId}`,
            30,
            forceRefresh,
            tags
          );
          
          if (detailsResult) {
            result.runs = detailsResult.runs;
            result.tasks = detailsResult.tasks;
          }
        } catch (detailsError) {
          console.warn('Could not get additional DAG details:', detailsError);
        }
      }
      
      // Process DAG data with enhanced null safety
      let processedDag: DAG | null = null;
      if (dagData) {
        try {
          processedDag = processDAGData(dagData);
          if (processedDag) {
            console.log(`✅ Successfully processed DAG: ${dagId}`);
            
            // Log unpause info if available
            if (unpauseInfo) {
              console.log(`🔓 Auto-unpause result: ${unpauseInfo.message}`);
            }
          }
        } catch (error) {
          console.error(`Error processing DAG data for ${dagId}:`, error);
        }
      }
      
      return {
        ...result,
        dag: processedDag,
        runs: result.runs ? result.runs.map(run => processDAGRunData(run)).filter(Boolean) : [],
        tasks: result.tasks ? safeArray(result.tasks) : [],
        unpauseResult: unpauseInfo
      };
      
    } catch (error) {
      console.error(`❌ Failed to get DAG ${dagId}:`, error);
      
      // Don't throw error for 404 as it means DAG doesn't exist yet
      if (error instanceof Error && error.message.includes('404')) {
        console.log(`DAG ${dagId} not found in Airflow (this is normal for new DAGs)`);
      }
      
      return null;
    }
  }, [handleRequest]);

  // Enhanced triggerDag with auto-unpause
  const enhancedTriggerDag = useCallback(async (dagId: string, conf: any = {}) => {
    try {
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      console.log(`🚀 Enhanced trigger for DAG: ${dagId} with config:`, conf);
      
      // First check DAG status with auto-unpause
      let dagResult;
      try {
        dagResult = await getDagWithAutoUnpause(dagId, true, true); // Force refresh and auto-unpause
      } catch (dagError) {
        console.error('Error checking DAG status before trigger:', dagError);
      }
      
      if (!dagResult?.dag) {
        throw new Error(`DAG "${dagId}" not found in Airflow. Please ensure the DAG is deployed and loaded.`);
      }
      
      // Check if still paused after auto-unpause attempt
      if (dagResult.dag.is_paused) {
        // Try manual unpause as fallback
        try {
          console.log(`🔓 DAG still paused, trying manual unpause...`);
          await unpauseDag(dagId);
          
          // Brief delay to ensure unpause is processed
          await new Promise(resolve => setTimeout(resolve, 1000));
        } catch (unpauseError) {
          console.error(`Failed to unpause DAG ${dagId}:`, unpauseError);
          throw new Error(`DAG "${dagId}" is paused and could not be unpaused automatically. Please unpause it manually.`);
        }
      }
      
      console.log(`✅ DAG verified and ready, triggering run for: ${dagId}`);
      
      // Enhanced configuration with more metadata
      const enhancedConf = {
        ...conf,
        triggered_by: 'dag_generator_enhanced_v3',
        timestamp: new Date().toISOString(),
        source: 'frontend_app',
        auto_unpaused: dagResult.unpauseResult?.unpaused || false,
        trigger_method: 'enhanced_auto_setup'
      };
      
      const result = await handleRequest<{
        success: true;
        message: string;
        dag_run: DAGRun;
      }>(
        () => apiRequestWithRetry(
          'POST', 
          `/api/airflow/dags/${encodeURIComponent(dagId)}/trigger`, 
          { conf: enhancedConf }
        ),
        undefined, // Don't cache trigger requests
        0,
        true // Skip cache
      );
      
      if (result) {
        // Invalidate related caches
        cache.invalidateByTag(dagId);
        cache.invalidateByTag('all_dags');
        console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
        return result;
      } else {
        throw new Error('No response received from trigger API');
      }
    } catch (error) {
      console.error(`❌ Failed to trigger DAG ${dagId}:`, error);
      
      // Enhanced error messages
      if (error instanceof Error) {
        if (error.message.includes('404')) {
          throw new Error(`DAG "${dagId}" not found in Airflow. Please ensure the DAG is deployed and loaded.`);
        } else if (error.message.includes('400')) {
          throw new Error(`Invalid request to trigger DAG "${dagId}". The DAG may have configuration issues.`);
        } else if (error.message.includes('409')) {
          throw new Error(`DAG "${dagId}" run conflict. A run may already be in progress.`);
        }
      }
      
      throw error;
    }
  }, [handleRequest, cache, getDagWithAutoUnpause, unpauseDag]);

  // Enhanced triggerDag with better error handling
  const triggerDag = useCallback(async (dagId: string, conf: any = {}) => {
    // Use the enhanced trigger function
    return enhancedTriggerDag(dagId, conf);
  }, [enhancedTriggerDag]);

  // Enhanced polling function with auto-unpause support
  const pollDagAvailabilityWithSetup = useCallback(async (
    dagId: string,
    maxAttempts = 15,
    onProgress?: (attempt: number, maxAttempts: number, message: string) => void
  ): Promise<{ 
    found: boolean; 
    dag: DAG | null; 
    attempts: number; 
    unpaused?: boolean;
    message: string;
  }> => {
    console.log(`🔄 Starting enhanced polling for DAG: ${dagId} (max ${maxAttempts} attempts with auto-setup)`);
    
    // Adaptive intervals: fast initially, then slower
    const getInterval = (attempt: number) => {
      if (attempt <= 6) return 2000;      // 2 seconds for first 6 attempts (12s)
      if (attempt <= 10) return 5000;     // 5 seconds for next 4 attempts (20s)
      return 10000;                       // 10 seconds for final attempts
    };
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const currentMessage = attempt <= 6 ? 'Fast scanning...' :
                             attempt <= 10 ? 'Medium interval check...' :
                             'Final verification...';
                             
        onProgress?.(attempt, maxAttempts, currentMessage);
        
        console.log(`Polling attempt ${attempt}/${maxAttempts} for DAG: ${dagId}`);
        
        // Use enhanced getDag with auto-unpause on successful detection
        const shouldAutoUnpause = attempt >= 3; // Only try auto-unpause after a few attempts
        const result = await getDagWithAutoUnpause(dagId, shouldAutoUnpause, true);
        
        if (result?.dag) {
          const totalTime = Array.from({length: attempt}, (_, i) => getInterval(i + 1)).reduce((a, b) => a + b, 0) / 1000;
          
          console.log(`✅ DAG ${dagId} found after ${attempt} attempts (${totalTime}s)!`);
          
          const wasUnpaused = result.unpauseResult?.unpaused || false;
          const finalMessage = wasUnpaused ? 
            `DAG found and auto-unpaused after ${totalTime}s` :
            `DAG found and ready after ${totalTime}s`;
          
          return {
            found: true,
            dag: result.dag,
            attempts: attempt,
            unpaused: wasUnpaused,
            message: finalMessage
          };
        }
        
        if (attempt < maxAttempts) {
          const interval = getInterval(attempt);
          console.log(`DAG ${dagId} not found, waiting ${interval}ms before next attempt...`);
          await new Promise(resolve => setTimeout(resolve, interval));
        }
      } catch (error) {
        console.error(`Error during polling attempt ${attempt} for DAG ${dagId}:`, error);
        
        // Continue polling even on errors (Airflow might be loading)
        if (attempt < maxAttempts) {
          const interval = getInterval(attempt);
          await new Promise(resolve => setTimeout(resolve, interval));
        }
      }
    }
    
    console.log(`❌ DAG ${dagId} not found after ${maxAttempts} attempts`);
    return {
      found: false,
      dag: null,
      attempts: maxAttempts,
      message: `DAG not found after ${maxAttempts} attempts`
    };
  }, [getDagWithAutoUnpause]);

  // Smart polling function for DAG availability
  const pollDagAvailability = useCallback(async (
    dagId: string, 
    maxAttempts = 10, 
    intervalMs = 10000,
    onProgress?: (attempt: number, maxAttempts: number) => void
  ): Promise<{ found: boolean; dag: DAG | null; attempts: number }> => {
    console.log(`🔄 Starting polling for DAG: ${dagId} (max ${maxAttempts} attempts, ${intervalMs}ms interval)`);
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        onProgress?.(attempt, maxAttempts);
        
        console.log(`Polling attempt ${attempt}/${maxAttempts} for DAG: ${dagId}`);
        
        // Force refresh to bypass cache
        const result = await getDag(dagId, true);
        
        if (result?.dag) {
          console.log(`✅ DAG ${dagId} found after ${attempt} attempts!`);
          return {
            found: true,
            dag: result.dag,
            attempts: attempt
          };
        }
        
        if (attempt < maxAttempts) {
          console.log(`DAG ${dagId} not found, waiting ${intervalMs}ms before next attempt...`);
          await new Promise(resolve => setTimeout(resolve, intervalMs));
        }
      } catch (error) {
        console.error(`Error during polling attempt ${attempt} for DAG ${dagId}:`, error);
        
        // Continue polling even on errors (Airflow might be loading)
        if (attempt < maxAttempts) {
          await new Promise(resolve => setTimeout(resolve, intervalMs));
        }
      }
    }
    
    console.log(`❌ DAG ${dagId} not found after ${maxAttempts} attempts`);
    return {
      found: false,
      dag: null,
      attempts: maxAttempts
    };
  }, [getDag]);

  // Enhanced getDagRuns with null safety
  const getDagRuns = useCallback(async (dagId: string, limit = 20, offset = 0, forceRefresh = false) => {
    const cacheKey = `dag_runs_${dagId}_${limit}_${offset}`;
    
    try {
      // Validate input
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      const result = await handleRequest<{
        runs: any[];
        total: number;
        success: true;
      }>(
        () => apiRequestWithRetry('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}/runs?limit=${limit}&offset=${offset}`),
        cacheKey,
        30, // 30 second cache for runs
        forceRefresh
      );
      
      if (result && result.runs) {
        // Process runs with null safety
        const processedRuns = result.runs
          .map(run => processDAGRunData(run))
          .filter((run): run is DAGRun => run !== null);
          
        return {
          ...result,
          runs: processedRuns
        };
      }
      
      return result;
    } catch (error) {
      console.error(`❌ Failed to get DAG runs for ${dagId}:`, error);
      return null;
    }
  }, [handleRequest]);

  // Enhanced getTaskInstances with null safety
  const getTaskInstances = useCallback(async (dagId: string, runId: string, forceRefresh = false) => {
    const cacheKey = `task_instances_${dagId}_${runId}`;
    
    try {
      // Validate input
      if (!dagId || !runId || typeof dagId !== 'string' || typeof runId !== 'string') {
        throw new Error('Invalid DAG ID or Run ID provided');
      }
      
      return handleRequest<{
        task_instances: TaskInstance[];
        success: true;
      }>(
        () => apiRequestWithRetry('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}/runs/${encodeURIComponent(runId)}/tasks`),
        cacheKey,
        60, // 1 minute cache for task instances
        forceRefresh
      );
    } catch (error) {
      console.error(`❌ Failed to get task instances for ${dagId}/${runId}:`, error);
      return null;
    }
  }, [handleRequest]);

  // Get Airflow system info with long cache
  const getAirflowInfo = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'airflow_info';
    
    return handleRequest<AirflowInfo & { success: true }>(
      () => apiRequestWithRetry('GET', '/api/airflow/info'),
      cacheKey,
      300, // 5 minute cache for system info
      forceRefresh
    );
  }, [handleRequest]);

  // Enhanced deleteDagRun with validation
  const deleteDagRun = useCallback(async (dagId: string, runId: string) => {
    try {
      // Validate input
      if (!dagId || !runId || typeof dagId !== 'string' || typeof runId !== 'string') {
        throw new Error('Invalid DAG ID or Run ID provided');
      }
      
      const result = await handleRequest<{
        success: true;
        message: string;
      }>(
        () => apiRequestWithRetry('DELETE', `/api/airflow/dags/${encodeURIComponent(dagId)}/runs/${encodeURIComponent(runId)}`),
        undefined, // Don't cache delete requests
        0,
        true // Skip cache
      );
      
      if (result) {
        // Invalidate related caches
        cache.invalidateByTag(dagId);
        cache.invalidateByTag('all_dags');
        console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
      }
      
      return result;
    } catch (error) {
      console.error(`❌ Failed to delete DAG run ${dagId}/${runId}:`, error);
      throw error;
    }
  }, [handleRequest, cache]);

  // Test connection with enhanced retry logic
  const testConnection = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'airflow_connection_test';
    const tags = ['connection', 'health'];
    
    return handleRequest<{
      connected: boolean;
      status?: any;
      url: string;
      token?: string;
      apiVersion?: string;
      authMethod?: string;
      error?: string;
    }>(
      () => apiRequestWithRetry('GET', '/api/test-airflow', undefined, 1), // Only 1 retry for connection test
      cacheKey,
      forceRefresh ? 5 : 60, // Shorter cache on force refresh
      forceRefresh,
      tags
    );
  }, [handleRequest]);

  // Get DAG source code
  const getDagSourceCode = useCallback(async (dagId: string, forceRefresh = false) => {
    const cacheKey = `dag_source_${dagId}`;
    
    try {
      // Validate input
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      console.log(`🔍 Fetching source code for DAG: ${dagId}`);
      
      const result = await handleRequest<{
        success: true;
        sourceCode: string;
        filePath: string;
        readMethod: string;
        message: string;
      }>(
        () => apiRequestWithRetry('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}/source`),
        cacheKey,
        300, // 5 minute cache for source code
        forceRefresh
      );
      
      if (result) {
        console.log(`✅ Successfully fetched source code for DAG: ${dagId} (${result.readMethod})`);
        return result;
      }
      
      return null;
    } catch (error) {
      console.error(`❌ Failed to get source code for DAG ${dagId}:`, error);
      
      // Provide fallback error message
      if (error instanceof Error) {
        if (error.message.includes('404')) {
          throw new Error(`DAG "${dagId}" source code not found. File may not be accessible.`);
        } else if (error.message.includes('403')) {
          throw new Error('Permission denied accessing DAG source code.');
        } else if (error.message.includes('500')) {
          throw new Error(`Server error when fetching source code for DAG "${dagId}".`);
        }
      }
      
      throw error;
    }
  }, [handleRequest]);

  // Enhanced cache management
  const clearCache = useCallback(() => {
    cache.clear();
    ongoingRequests.clear();
    console.log('🧹 Cleared all client-side caches and ongoing requests');
  }, [cache, ongoingRequests]);

  const invalidateDagCache = useCallback((dagId?: string) => {
    if (dagId) {
      cache.invalidateByTag(dagId);
      console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
    } else {
      cache.invalidateByTag('dag');
      cache.invalidateByTag('all_dags');
      console.log('🗑️ Invalidated all DAG caches');
    }
  }, [cache]);

  // Get detailed cache statistics
  const getCacheStats = useCallback(() => {
    return cache.getStats();
  }, [cache]);

  // Prefetch strategy for better performance
  const prefetchData = useCallback(async () => {
    console.log('🔄 Starting intelligent prefetch...');
    
    try {
      // Prefetch in parallel with appropriate timeouts
      await Promise.allSettled([
        Promise.race([
          getDags(),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 5000))
        ]),
        Promise.race([
          testConnection(),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 3000))
        ])
      ]);
      
      console.log('✅ Prefetch completed');
    } catch (error) {
      console.log('⚠️ Prefetch completed with some errors (this is normal)');
    }
  }, [getDags, testConnection]);

  return {
    loading,
    error,
    
    // Enhanced API methods
    getDags,
    getDag,
    getDagWithAutoUnpause,        // New enhanced method
    triggerDag,                   // Enhanced trigger with auto-unpause
    autoUnpauseDag,               // New auto-unpause method
    getDagSourceCode,
    pauseUnpauseDag,
    pauseDag,
    unpauseDag,
    getDagRuns,
    getTaskInstances,
    getAirflowInfo,
    deleteDagRun,
    testConnection,
    
    // Enhanced polling utilities
    pollDagAvailability,
    pollDagAvailabilityWithSetup,  // New enhanced polling with auto-setup
    
    // Enhanced cache management
    clearCache,
    invalidateDagCache,
    getCacheStats,
    prefetchData,
    
    // Utility methods
    setError,
    clearError: () => setError(null)
  };
}