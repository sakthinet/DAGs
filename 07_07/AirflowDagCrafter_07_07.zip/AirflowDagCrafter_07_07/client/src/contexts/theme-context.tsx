import { createContext, useContext, useEffect, useState } from "react";

type Theme = "light" | "dark" | "airflow";

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem("theme");
    return (saved as Theme) || "light";
  });

  useEffect(() => {
    // Update both HTML and BODY elements
    const root = document.documentElement;
    const body = document.body;
    
    // Remove all theme classes from both elements
    root.classList.remove("theme-light", "theme-dark", "theme-airflow");
    body.classList.remove("theme-light", "theme-dark", "theme-airflow");
    
    // Add current theme class to both elements (with theme- prefix)
    root.classList.add(`theme-${theme}`);
    body.classList.add(`theme-${theme}`);
    
    // Save to localStorage
    localStorage.setItem("theme", theme);
    
    // Force light theme text visibility
    if (theme === "light") {
      document.body.style.color = "#1e293b";
      document.body.style.backgroundColor = "#ffffff";
    } else {
      document.body.style.color = "";
      document.body.style.backgroundColor = "";
    }
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}