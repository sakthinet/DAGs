import { DAGRunState, TaskInstanceState } from '@/types/airflow';

/**
 * Utility functions for Airflow 3.x compatibility
 * Based on working implementation patterns
 */

/**
 * Safe string conversion for API responses
 */
export const safeString = (value: any): string => {
  if (value === null || value === undefined) return 'N/A';
  if (typeof value === 'string') return value;
  if (typeof value === 'object' && value.value !== undefined) return String(value.value);
  if (typeof value === 'object' && value.__type !== undefined) return String(value.__type);
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
};

/**
 * Extract schedule interval from Airflow 3.x response
 */
export const getScheduleInterval = (scheduleInterval: any): string => {
  if (!scheduleInterval) return 'None';
  if (typeof scheduleInterval === 'string') return scheduleInterval;
  if (typeof scheduleInterval === 'object') {
    if (scheduleInterval.__type) return scheduleInterval.__type;
    if (scheduleInterval.value) return scheduleInterval.value;
    return 'Complex Schedule';
  }
  return 'Unknown';
};

/**
 * Extract tag names from Airflow 3.x tags array
 */
export const getTagNames = (tags: any[]): string[] => {
  if (!tags || !Array.isArray(tags)) return [];
  return tags.map(tag => {
    if (typeof tag === 'string') return tag;
    if (typeof tag === 'object' && tag.name) return tag.name;
    return 'Unknown Tag';
  });
};

/**
 * Format a date string for display
 */
export function formatDate(dateString: string | null, options?: Intl.DateTimeFormatOptions): string {
  if (!dateString || dateString === 'N/A') return 'N/A';
  
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'Invalid Date';
    
    const defaultOptions: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    };
    
    return date.toLocaleString('en-US', { ...defaultOptions, ...options });
  } catch (error) {
    return 'Invalid Date';
  }
}

/**
 * Format a relative time (e.g., "2 hours ago")
 */
export function formatRelativeTime(dateString: string | null): string {
  if (!dateString) return 'N/A';
  
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'Invalid Date';
    
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    
    if (diffSec < 60) return `${diffSec}s ago`;
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHour < 24) return `${diffHour}h ago`;
    if (diffDay < 7) return `${diffDay}d ago`;
    
    return formatDate(dateString, { month: 'short', day: 'numeric' });
  } catch (error) {
    return 'N/A';
  }
}

/**
 * Calculate and format duration between two dates
 */
export function formatDuration(startDate: string | null, endDate: string | null): string {
  if (!startDate || !endDate) return 'N/A';
  
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (isNaN(start.getTime()) || isNaN(end.getTime())) return 'Invalid';
    
    const durationMs = end.getTime() - start.getTime();
    
    if (durationMs < 0) return 'N/A';
    
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days}d ${hours % 24}h ${minutes % 60}m`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  } catch (error) {
    return 'N/A';
  }
}

/**
 * Get color class for DAG run state (compatible with working implementation)
 */
export function getStateColor(state: DAGRunState | TaskInstanceState, darkMode = false): string {
  const lightColors = {
    success: 'bg-green-100 text-green-800 border-green-200',
    running: 'bg-blue-100 text-blue-800 border-blue-200',
    failed: 'bg-red-100 text-red-800 border-red-200',
    queued: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    scheduled: 'bg-purple-100 text-purple-800 border-purple-200',
    up_for_retry: 'bg-orange-100 text-orange-800 border-orange-200',
    up_for_reschedule: 'bg-orange-100 text-orange-800 border-orange-200',
    upstream_failed: 'bg-red-50 text-red-600 border-red-200',
    skipped: 'bg-gray-100 text-gray-800 border-gray-200',
    none: 'bg-gray-50 text-gray-600 border-gray-200'
  };

  const darkColors = {
    success: 'bg-green-900 text-green-300 border-green-700',
    running: 'bg-blue-900 text-blue-300 border-blue-700',
    failed: 'bg-red-900 text-red-300 border-red-700',
    queued: 'bg-yellow-900 text-yellow-300 border-yellow-700',
    scheduled: 'bg-purple-900 text-purple-300 border-purple-700',
    up_for_retry: 'bg-orange-900 text-orange-300 border-orange-700',
    up_for_reschedule: 'bg-orange-900 text-orange-300 border-orange-700',
    upstream_failed: 'bg-red-800 text-red-300 border-red-700',
    skipped: 'bg-gray-800 text-gray-300 border-gray-600',
    none: 'bg-gray-800 text-gray-400 border-gray-600'
  };

  const colors = darkMode ? darkColors : lightColors;
  return colors[state as keyof typeof colors] || colors.none;
}

/**
 * Get icon for DAG run state
 */
export function getStateIcon(state: DAGRunState | TaskInstanceState): string {
  const iconMap: Record<string, string> = {
    success: '✅',
    running: '🔄',
    failed: '❌',
    queued: '⏳',
    scheduled: '📅',
    up_for_retry: '🔄',
    up_for_reschedule: '⏰',
    upstream_failed: '⬆️❌',
    skipped: '⏭️',
    none: '⚪'
  };
  
  return iconMap[state] || '❓';
}

/**
 * Get human-readable state description
 */
export function getStateDescription(state: DAGRunState | TaskInstanceState): string {
  const descriptions: Record<string, string> = {
    success: 'Completed successfully',
    running: 'Currently running',
    failed: 'Failed with errors',
    queued: 'Waiting in queue',
    scheduled: 'Scheduled to run',
    up_for_retry: 'Retrying after failure',
    up_for_reschedule: 'Rescheduled for later',
    upstream_failed: 'Failed due to upstream task failure',
    skipped: 'Skipped execution',
    none: 'Not started'
  };
  
  return descriptions[state] || 'Unknown state';
}

/**
 * Format schedule interval for display (Airflow 3.x compatible)
 */
export function formatScheduleInterval(scheduleInterval: any): string {
  if (scheduleInterval === null || scheduleInterval === 'None') return 'Manual';
  
  if (typeof scheduleInterval === 'string') {
    const cronMap: Record<string, string> = {
      '@once': 'Run once',
      '@hourly': 'Every hour',
      '@daily': 'Daily',
      '@weekly': 'Weekly',
      '@monthly': 'Monthly',
      '@yearly': 'Yearly'
    };
    return cronMap[scheduleInterval] || scheduleInterval;
  }
  
  if (typeof scheduleInterval === 'object') {
    if (scheduleInterval.__type) {
      return scheduleInterval.__type;
    }
    if (scheduleInterval.value) {
      return scheduleInterval.value;
    }
    if (scheduleInterval.days) {
      return `Every ${scheduleInterval.days} days`;
    }
    if (scheduleInterval.seconds) {
      return `Every ${scheduleInterval.seconds} seconds`;
    }
  }
  
  return 'Custom schedule';
}

/**
 * Calculate success rate for DAG runs
 */
export function calculateSuccessRate(runs: { state: DAGRunState }[]): number {
  if (runs.length === 0) return 0;
  const successfulRuns = runs.filter(run => run.state === 'success').length;
  return Math.round((successfulRuns / runs.length) * 100);
}

/**
 * Group DAG runs by date
 */
export function groupRunsByDate(runs: { execution_date: string; state: DAGRunState }[]): Record<string, { state: DAGRunState }[]> {
  return runs.reduce((groups, run) => {
    const date = new Date(run.execution_date).toISOString().split('T')[0];
    if (!groups[date]) groups[date] = [];
    groups[date].push(run);
    return groups;
  }, {} as Record<string, { state: DAGRunState }[]>);
}

/**
 * Validate DAG ID format (Airflow 3.x compatible)
 */
export function validateDagId(dagId: string): { valid: boolean; error?: string } {
  if (!dagId) return { valid: false, error: 'DAG ID is required' };
  if (dagId.length < 1) return { valid: false, error: 'DAG ID must not be empty' };
  if (dagId.length > 250) return { valid: false, error: 'DAG ID must be less than 250 characters' };
  if (!/^[a-zA-Z0-9_.-]+$/.test(dagId)) {
    return { valid: false, error: 'DAG ID can only contain letters, numbers, underscores, hyphens, and dots' };
  }
  if (dagId.startsWith('.') || dagId.endsWith('.')) {
    return { valid: false, error: 'DAG ID cannot start or end with a dot' };
  }
  return { valid: true };
}

/**
 * Generate unique DAG run ID (Airflow 3.x format)
 */
export function generateDagRunId(prefix = 'manual'): string {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '_');
  const random = Math.random().toString(36).substring(2, 8);
  return `${prefix}_${timestamp}_${random}`;
}

/**
 * Parse file info from file location path
 */
export function getFileInfo(fileloc: string): { filename: string; directory: string } {
  const parts = fileloc.split(/[\/\\]/);
  const filename = parts[parts.length - 1];
  const directory = parts.slice(0, -1).join('/');
  return { filename, directory };
}

/**
 * Format file size for display
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Debounce function for search inputs
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

/**
 * Get status text for DAG state
 */
export function getStatusText(isPaused: boolean, isActive: boolean): string {
  if (!isActive) return 'Inactive';
  if (isPaused) return 'Paused';
  return 'Active';
}

/**
 * Process DAG data from Airflow 3.x API response
 */
export function processDagData(dag: any): any {
  return {
    ...dag,
    dag_id: safeString(dag.dag_id),
    description: safeString(dag.description || dag.timetable_description || ''),
    schedule_interval_display: getScheduleInterval(dag.schedule_interval),
    tag_names: getTagNames(dag.tags),
    fileloc: safeString(dag.fileloc),
    last_parsed_time: safeString(dag.last_parsed_time),
    max_active_runs: safeString(dag.max_active_runs),
    is_active: Boolean(dag.is_active),
    is_paused: Boolean(dag.is_paused)
  };
}

/**
 * Create trigger data for Airflow 3.x
 */
export function createTriggerData(conf: any = {}): any {
  return {
    conf: conf,
    dag_run_id: generateDagRunId('manual'),
    logical_date: new Date().toISOString()  // Airflow 3.x uses logical_date
  };
}