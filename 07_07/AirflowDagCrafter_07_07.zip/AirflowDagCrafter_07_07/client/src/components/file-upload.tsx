import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CloudUpload, FileText, X, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { UploadedFile } from "@/pages/dag-generator";

interface FileUploadProps {
  onFileUploaded: (file: UploadedFile) => void;
  onNext: () => void;
  uploadedFile: UploadedFile | null;
}

export function FileUpload({ onFileUploaded, onNext, uploadedFile }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleFileUpload = useCallback(async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.csv') && file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel') {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB
      toast({
        title: "File too large",
        description: "Please upload a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('csvFile', file);

      const response = await fetch('/api/upload-csv', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();

      if (result.success) {
        onFileUploaded({
          fileName: result.fileName,
          fileSize: result.fileSize,
          headers: result.headers,
          previewRows: result.previewRows
        });
        toast({
          title: "File uploaded successfully",
          description: result.message || `${result.fileName} has been processed`,
        });
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: "Failed to process the uploaded file",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  }, [onFileUploaded, toast]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, [handleFileUpload]);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, [handleFileUpload]);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const removeFile = () => {
    onFileUploaded(null as any);
  };

  return (
    <div className="max-w-4xl">
      <Card className="shadow-sm border border-gray-200">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="mx-auto w-16 h-16 bg-blue-50 rounded-xl flex items-center justify-center mb-4">
              <FileText className="text-2xl text-primary h-8 w-8" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Upload CSV File</h3>
            <p className="text-gray-600 mb-6">Select your CSV file to begin the DAG generation process</p>
            
            <div
              className={`border-2 border-dashed rounded-lg p-8 transition-colors cursor-pointer ${
                isDragging 
                  ? 'border-primary bg-blue-50' 
                  : 'border-gray-300 hover:border-primary hover:bg-blue-50'
              }`}
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => document.getElementById('csvFile')?.click()}
            >
              <input
                type="file"
                id="csvFile"
                accept=".csv"
                className="hidden"
                onChange={handleFileInputChange}
                disabled={isUploading}
              />
              <div className="text-center">
                <CloudUpload className="mx-auto text-3xl text-gray-400 mb-4 h-12 w-12" />
                <p className="text-lg font-medium text-gray-900 mb-2">
                  {isUploading ? 'Processing...' : 'Drop your CSV file here'}
                </p>
                <p className="text-gray-600 mb-4">
                  or <span className="text-primary font-medium">browse files</span>
                </p>
                <p className="text-sm text-gray-500">Supports: CSV files up to 10MB</p>
              </div>
            </div>
            
            {/* File Preview */}
            {uploadedFile && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg border text-left">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <FileText className="text-primary mr-2 h-5 w-5" />
                    <span className="font-medium">{uploadedFile.fileName}</span>
                    <span className="text-sm text-gray-500 ml-2">
                      ({formatFileSize(uploadedFile.fileSize)})
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={removeFile}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="text-left">
                  <p className="text-sm text-gray-600 mb-2">
                    Preview (first {uploadedFile.previewRows.length} rows):
                  </p>
                  <div className="overflow-x-auto">
                    <Table className="min-w-full text-xs">
                      <TableHeader>
                        <TableRow className="bg-gray-100">
                          {uploadedFile.headers.map((header, index) => (
                            <TableHead key={index} className="px-2 py-1 text-left font-medium text-gray-900">
                              {header}
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {uploadedFile.previewRows.map((row, rowIndex) => (
                          <TableRow key={rowIndex} className="border-t">
                            {row.map((cell, cellIndex) => (
                              <TableCell key={cellIndex} className="px-2 py-1 text-gray-700">
                                {cell}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end mt-6">
        <Button 
          onClick={onNext}
          disabled={!uploadedFile}
          className="font-medium"
        >
          Continue to Configuration
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
