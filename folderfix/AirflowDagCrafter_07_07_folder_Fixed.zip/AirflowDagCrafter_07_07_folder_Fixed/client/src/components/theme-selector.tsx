import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { 
  Palette, 
  Sun, 
  Moon, 
  Zap,
  CheckCircle
} from "lucide-react";
import { 
  changeTheme, 
  getCurrentTheme, 
  getAllThemes,
  THEME_STORAGE_KEY,
  type ThemeDefinition 
} from "../utils/theme-init";

export interface Theme {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  colors: {
    primary: string;
    background: string;
    surface: string;
    text: string;
  };
  cssClass: string;
}

export const THEMES: Theme[] = [
  {
    id: 'light',
    name: 'Light Theme',
    description: 'Clean and professional light interface',
    icon: Sun,
    colors: {
      primary: '#2563eb',
      background: '#ffffff',
      surface: '#ffffff',
      text: '#1e293b'
    },
    cssClass: 'theme-light'
  },
  {
    id: 'dark',
    name: 'Dark Theme',
    description: 'Modern dark interface for low-light environments',
    icon: Moon,
    colors: {
      primary: '#3b82f6',
      background: '#0f172a',
      surface: '#1e293b',
      text: '#f1f5f9'
    },
    cssClass: 'theme-dark'
  },
  {
    id: 'airflow',
    name: 'Apache Airflow',
    description: 'Official Apache Airflow documentation theme',
    icon: Zap,
    colors: {
      primary: '#017cee',
      background: '#fafafa',
      surface: '#ffffff',
      text: '#2c3e50'
    },
    cssClass: 'theme-airflow'
  }
];

export function ThemeSelector() {
  const [currentTheme, setCurrentTheme] = useState<string>('light');

  // Load current theme on mount
  useEffect(() => {
    const theme = getCurrentTheme();
    setCurrentTheme(theme.id);
  }, []);

  // Listen for theme changes from other sources
  useEffect(() => {
    const handleThemeChange = (event: CustomEvent) => {
      setCurrentTheme(event.detail.themeId);
    };

    window.addEventListener('themeChanged', handleThemeChange as EventListener);
    return () => {
      window.removeEventListener('themeChanged', handleThemeChange as EventListener);
    };
  }, []);

  const handleThemeChange = (themeId: string) => {
    // Use the centralized theme change function
    changeTheme(themeId);
    setCurrentTheme(themeId);
  };

  const getCurrentThemeInfo = () => THEMES.find(t => t.id === currentTheme) || THEMES[0];
  const CurrentThemeIcon = getCurrentThemeInfo().icon;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className="relative overflow-hidden transition-all duration-200 hover:shadow-md"
        >
          <div className="flex items-center space-x-2">
            <CurrentThemeIcon className="h-4 w-4" />
            <span className="hidden sm:inline-block">{getCurrentThemeInfo().name}</span>
            <Palette className="h-3 w-3 opacity-50" />
          </div>
        </Button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent 
        align="end" 
        className="w-64"
        sideOffset={8}
      >
        <DropdownMenuLabel className="text-sm font-semibold">
          Choose Theme
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        {THEMES.map((theme) => {
          const IconComponent = theme.icon;
          const isSelected = currentTheme === theme.id;
          
          return (
            <DropdownMenuItem
              key={theme.id}
              onClick={() => handleThemeChange(theme.id)}
              className="flex items-start space-x-3 p-3 cursor-pointer transition-colors"
            >
              <div className="flex-shrink-0 mt-0.5">
                <div 
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                    isSelected ? 'text-white' : 'text-gray-600'
                  }`}
                  style={{ 
                    backgroundColor: isSelected ? theme.colors.primary : '#f3f4f6'
                  }}
                >
                  <IconComponent className="h-4 w-4" />
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="font-medium text-sm">{theme.name}</div>
                  {isSelected && <CheckCircle className="h-4 w-4 text-green-600" />}
                </div>
                <div className="text-xs text-gray-500 mt-1">{theme.description}</div>
                
                {/* Color Preview */}
                <div className="flex space-x-1 mt-2">
                  <div 
                    className="w-4 h-4 rounded-full border border-gray-200" 
                    style={{ backgroundColor: theme.colors.primary }}
                    title="Primary Color"
                  />
                  <div 
                    className="w-4 h-4 rounded-full border border-gray-200" 
                    style={{ backgroundColor: theme.colors.background }}
                    title="Background"
                  />
                  <div 
                    className="w-4 h-4 rounded-full border border-gray-200" 
                    style={{ backgroundColor: theme.colors.surface }}
                    title="Surface"
                  />
                </div>
              </div>
            </DropdownMenuItem>
          );
        })}

        <DropdownMenuSeparator />
        
        <div className="p-2 text-xs text-center text-gray-500">
          TCS ECM Themes v1.0
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}