import { useState, useEffect } from "react";
import { Sidebar } from "@/components/sidebar";
import { FileUpload } from "@/components/file-upload";
import { DagConfiguration } from "@/components/dag-configuration";
import { ScriptGenerator } from "@/components/script-generator";
import { XmlViewer } from "@/components/xml-viewer";
import { DagDashboard } from "@/components/dag-dashboard";
import { SetupInstructions } from "@/components/setup-instructions";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Menu, Server, HelpCircle, Wifi, WifiOff } from "lucide-react";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { ThemeSelector } from "@/components/theme-selector";
import { ReportsViewer } from "@/components/reports-viewer";
import { useToast } from "@/hooks/use-toast";
import { Chatbot } from "@/components/chatbot";

export type Step = 'dashboard' | 'reports' | 'upload' | 'configure' | 'generate' | 'xml-viewer';

export interface UploadedFile {
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
}

export interface DagConfig {
  inputDirectory: string;
  outputDirectory: string;
  csvFileName: string;
  dagId: string;
  description: string;
  scheduleInterval: string;
  dagsDirectory: string;
  chunkSize: number;
}

export default function DagGenerator() {
  const [currentStep, setCurrentStep] = useState<Step>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [dagConfig, setDagConfig] = useState<DagConfig>({
    inputDirectory: 'C:\\Docker\\airflow3x2\\data',
    outputDirectory: 'C:\\Docker\\airflow3x2\\data',
    csvFileName: '',
    dagId: 'csv_to_xml_dag',
    description: 'Convert CSV data to XML format for downstream processing',
    scheduleInterval: 'None',
    dagsDirectory: 'C:\\Docker\\airflow3x2\\dags',
    chunkSize: 5000
  });
  const [generatedScript, setGeneratedScript] = useState<string>('');
  const [connectionStatus, setConnectionStatus] = useState({
    connected: false,
    url: 'http://localhost:8080',
    lastChecked: null as Date | null,
    isChecking: false
  });

  const airflowApi = useAirflowApi();
  const { toast } = useToast();

  // Enhanced connection test with better error handling
  const testAirflowConnection = async (showToast = false) => {
    setConnectionStatus(prev => ({ ...prev, isChecking: true }));
    
    try {
      console.log('Testing Airflow connection...');
      const result = await airflowApi.testConnection(true); // Force refresh
      
      if (result) {
        const newStatus = {
          connected: result.connected || false,
          url: result.url || 'localhost:8080',
          lastChecked: new Date(),
          isChecking: false
        };
        
        setConnectionStatus(newStatus);
        console.log('Connection test result:', result);
        
        if (showToast) {
          if (result.connected) {
            toast({
              title: "✅ Airflow Connected",
              description: `Successfully connected to ${result.url}`,
            });
          } else {
            toast({
              title: "❌ Airflow Disconnected",
              description: result.error || "Failed to connect to Airflow",
              variant: "destructive",
            });
          }
        }
        
        return result;
      } else {
        throw new Error('No response from connection test');
      }
    } catch (error) {
      console.error('Connection test failed:', error);
      const newStatus = {
        connected: false,
        url: 'http://localhost:8080',
        lastChecked: new Date(),
        isChecking: false
      };
      
      setConnectionStatus(newStatus);
      
      if (showToast) {
        toast({
          title: "Connection Test Failed",
          description: error instanceof Error ? error.message : "Unable to test Airflow connection",
          variant: "destructive",
        });
      }
      
      return null;
    }
  };

  // Test Airflow connection on component mount (only once)
  useEffect(() => {
    let isMounted = true;
    
    const checkConnection = async () => {
      // Delay initial check to avoid immediate API call on page load
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      if (isMounted) {
        await testAirflowConnection();
      }
    };

    checkConnection();

    return () => {
      isMounted = false;
    };
  }, []); // Empty dependency array - only run once on mount

  // Auto-refresh connection status periodically
  useEffect(() => {
    const interval = setInterval(async () => {
      if (!connectionStatus.isChecking) {
        await testAirflowConnection();
      }
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [connectionStatus.isChecking]);

  // ENHANCED: Smart config update when file is uploaded (NO AUTO-NAVIGATION)
  useEffect(() => {
    if (uploadedFile) {
      console.log('=== SMART CONFIG UPDATE FOR UPLOADED FILE ===');
      console.log('Uploaded file:', uploadedFile);
      
      const fileName = uploadedFile.fileName.replace('.csv', '');
      const cleanFileName = fileName.toLowerCase().replace(/[^a-z0-9]/g, '_');
      
      // Create enhanced DAG ID from filename
      let newDagId = cleanFileName.length >= 3 ? cleanFileName : `${cleanFileName}_dag`;
      
      // Ensure DAG ID starts with letter and is valid
      if (!/^[a-zA-Z]/.test(newDagId)) {
        newDagId = `dag_${newDagId}`;
      }
      
      // Update config with smart defaults based on uploaded file
      setDagConfig(prev => {
        const newConfig = {
          ...prev,
          csvFileName: uploadedFile.fileName,
          dagId: newDagId,
          description: `Convert ${fileName.replace(/_/g, ' ')} CSV data to XML format for downstream processing`,
          chunkSize: prev.chunkSize || 5000
        };
        
        console.log('Updated DAG config with file info:', newConfig);
        return newConfig;
      });
      
      // REMOVED: Auto-navigation - now user must manually click "Continue"
      console.log('File uploaded and config updated. User must click Continue to proceed.');
    }
  }, [uploadedFile]); // Removed currentStep dependency

  const getStepTitle = (step: Step): string => {
    const titles = {
      'dashboard': 'TCS ECM Automation Control Center',
      'reports': 'TCS ECM Analytics & Reports',
      'upload': 'TCS ECM Data Upload Studio',
      'configure': 'TCS ECM Workflow Configuration',
      'generate': 'TCS ECM Pipeline Builder Suite',
      'xml-viewer': 'TCS ECM Data Transformation Viewer'
    };
    return titles[step];
  };

  const getStepDescription = (step: Step): string => {
    const descriptions = {
      'dashboard': 'Monitor and orchestrate your enterprise workflows',
      'reports': 'View advanced analytics and business intelligence reports',
      'upload': 'Upload and prepare your data for transformation',
      'configure': 'Design and configure your workflow parameters',
      'generate': 'Build and deploy enterprise-grade data pipelines',
      'xml-viewer': 'Preview and validate data transformation outputs'
    };
    return descriptions[step];
  };

  const handleNextStep = () => {
    const steps: Step[] = ['dashboard', 'upload', 'configure', 'generate', 'xml-viewer'];
    const currentIndex = steps.indexOf(currentStep);
    if (currentIndex < steps.length - 1) {
      setCurrentStep(steps[currentIndex + 1]);
    }
  };

  const handlePrevStep = () => {
    const steps: Step[] = ['dashboard', 'upload', 'configure', 'generate', 'xml-viewer'];
    const currentIndex = steps.indexOf(currentStep);
    if (currentIndex > 0) {
      setCurrentStep(steps[currentIndex - 1]);
    }
  };

  const handleStepChange = (step: Step) => {
    setCurrentStep(step);
    setSidebarOpen(false); // Close sidebar on mobile when navigating
  };

  const handleTestConnection = async () => {
    await testAirflowConnection(true); // Show toast for manual tests
  };

  // Enhanced file upload handler with validation
  const handleFileUploaded = (file: UploadedFile) => {
    console.log('=== FILE UPLOADED IN MAIN COMPONENT ===');
    console.log('File details:', {
      name: file.fileName,
      size: file.fileSize,
      headers: file.headers.length,
      previewRows: file.previewRows.length
    });
    
    // Validate file before setting
    if (!file.fileName || !file.fileName.endsWith('.csv')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a valid CSV file",
        variant: "destructive",
      });
      return;
    }
    
    if (file.fileSize === 0) {
      toast({
        title: "Empty file",
        description: "The uploaded file appears to be empty",
        variant: "destructive",
      });
      return;
    }
    
    if (!file.headers || file.headers.length === 0) {
      toast({
        title: "Invalid CSV structure",
        description: "The CSV file must have headers",
        variant: "destructive",
      });
      return;
    }
    
    // Set the uploaded file
    setUploadedFile(file);
    
    toast({
      title: "File uploaded successfully",
      description: `${file.fileName} (${(file.fileSize / 1024).toFixed(1)} KB) is ready for processing`,
    });
    
    console.log('✅ File upload processing completed');
  };

  // Enhanced config change handler with validation
  const handleConfigChange = (newConfig: DagConfig) => {
    console.log('=== CONFIG CHANGE IN MAIN COMPONENT ===');
    console.log('Previous config:', dagConfig);
    console.log('New config:', newConfig);
    
    // Validate config before setting
    if (newConfig.chunkSize && (newConfig.chunkSize < 1 || newConfig.chunkSize > 100000)) {
      toast({
        title: "Invalid chunk size",
        description: "Chunk size must be between 1 and 100,000",
        variant: "destructive",
      });
      return;
    }
    
    setDagConfig(newConfig);
    console.log('✅ Config update completed');
  };

  // Enhanced script generation handler
  const handleScriptGenerated = (script: string) => {
    console.log('=== SCRIPT GENERATED IN MAIN COMPONENT ===');
    console.log('Script length:', script.length);
    console.log('First 200 chars:', script.substring(0, 200));
    
    if (!script || script.trim().length === 0) {
      toast({
        title: "Script generation failed",
        description: "Generated script is empty",
        variant: "destructive",
      });
      return;
    }
    
    setGeneratedScript(script);
    setCurrentStep('generate');
    
    toast({
      title: "DAG script generated",
      description: "Your DAG script has been created and is ready for deployment",
    });
    
    console.log('✅ Script generation completed');
  };

  // Navigation helpers
  const handleViewDashboard = () => {
    setCurrentStep('dashboard');
    
    // Refresh dashboard data when navigating to it
    setTimeout(() => {
      airflowApi.clearCache();
      airflowApi.prefetchData();
    }, 500);
  };

  const handleStartOver = () => {
    console.log('=== STARTING OVER - RESETTING ALL DATA ===');
    
    setCurrentStep('upload');
    setUploadedFile(null);
    setGeneratedScript('');
    
    // Reset config to defaults
    const defaultConfig = {
      inputDirectory: 'C:\\Docker\\airflow3x2\\data',
      outputDirectory: 'C:\\Docker\\airflow3x2\\data',
      csvFileName: '',
      dagId: 'csv_to_xml_dag',
      description: 'Convert CSV data to XML format for downstream processing',
      scheduleInterval: 'None',
      dagsDirectory: 'C:\\Docker\\airflow3x2\\dags',
      chunkSize: 5000
    };
    
    setDagConfig(defaultConfig);
    
    toast({
      title: "Starting over",
      description: "All data has been reset. You can upload a new CSV file.",
    });
    
    console.log('✅ Reset completed');
  };

  // Connection status indicator component
  const ConnectionIndicator = () => (
    <div className="flex items-center text-sm">
      <div className={`w-2 h-2 rounded-full mr-2 ${
        connectionStatus.isChecking ? 'bg-yellow-500 animate-pulse' :
        connectionStatus.connected ? 'bg-green-500' : 'bg-red-500'
      }`}></div>
      {connectionStatus.isChecking ? (
        <Wifi className="mr-2 h-4 w-4 animate-pulse" />
      ) : connectionStatus.connected ? (
        <Wifi className="mr-2 h-4 w-4" />
      ) : (
        <WifiOff className="mr-2 h-4 w-4" />
      )}
      <span className={
        connectionStatus.isChecking ? 'text-yellow-600' :
        connectionStatus.connected ? 'text-green-600' : 'text-red-600'
      }>
        Airflow 3.x {
          connectionStatus.isChecking ? 'Checking...' :
          connectionStatus.connected ? 'Connected' : 'Disconnected'
        }
      </span>
      <Button
        variant="ghost"
        size="sm"
        onClick={handleTestConnection}
        disabled={connectionStatus.isChecking}
        className="ml-2"
      >
        {connectionStatus.isChecking ? 'Testing...' : 'Test'}
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <Sidebar
        currentStep={currentStep}
        onStepChange={handleStepChange}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        connectionStatus={connectionStatus}
      />

      {/* Main Content */}
      <div className="flex-1 lg:ml-0">
        {/* Enhanced Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between h-16 px-6">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden mr-4"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div>
                <h2 className="text-xl font-semibold text-slate-800">
                  {getStepTitle(currentStep)}
                </h2>
                <p className="text-sm text-gray-600">
                  {getStepDescription(currentStep)}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Connection Status - visible on larger screens */}
              <div className="hidden sm:flex">
                <ConnectionIndicator />
              </div>
              
              {/* Theme Selector */}
              <ThemeSelector />
              
              {/* Help Dialog */}
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <HelpCircle className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Airflow 3.x Setup Instructions & Workflow</DialogTitle>
                  </DialogHeader>
                  <SetupInstructions />
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          {/* Mobile Connection Status */}
          <div className="sm:hidden px-6 pb-3">
            <ConnectionIndicator />
          </div>
        </header>

        {/* Main Content Area */}
        <main className="p-6">
          <div className="relative">
            {/* Connection Warning */}
            {!connectionStatus.connected && !connectionStatus.isChecking && (
              <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center">
                  <WifiOff className="mr-2 h-5 w-5 text-yellow-600" />
                  <div>
                    <div className="font-medium text-yellow-800">
                      Airflow Connection Issue
                    </div>
                    <div className="text-sm text-yellow-700">
                      Some features may be limited. Ensure Airflow is running at {connectionStatus.url}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleTestConnection}
                    className="ml-auto"
                  >
                    Retry Connection
                  </Button>
                </div>
              </div>
            )}

            {/* ENHANCED: Progress indicator for multi-step process */}
            {uploadedFile && currentStep !== 'dashboard' && currentStep !== 'reports' && (
              <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="text-sm font-medium text-blue-800">
                      Processing: {uploadedFile.fileName}
                    </div>
                    <div className="ml-2 text-xs text-blue-600">
                      ({(uploadedFile.fileSize / 1024).toFixed(1)} KB, {uploadedFile.headers.length} columns)
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${currentStep === 'upload' ? 'bg-blue-500' : 'bg-green-500'}`}></div>
                    <div className={`w-2 h-2 rounded-full ${currentStep === 'configure' ? 'bg-blue-500' : currentStep === 'upload' ? 'bg-gray-300' : 'bg-green-500'}`}></div>
                    <div className={`w-2 h-2 rounded-full ${currentStep === 'generate' ? 'bg-blue-500' : ['upload', 'configure'].includes(currentStep) ? 'bg-gray-300' : 'bg-green-500'}`}></div>
                    <div className={`w-2 h-2 rounded-full ${currentStep === 'xml-viewer' ? 'bg-blue-500' : 'bg-gray-300'}`}></div>
                  </div>
                </div>
              </div>
            )}

            {/* Step Content */}
            {currentStep === 'dashboard' && (
              <DagDashboard />
            )}
            
            {currentStep === 'reports' && (
              <ReportsViewer />
            )}
            
            {currentStep === 'upload' && (
              <FileUpload
                onFileUploaded={handleFileUploaded}
                onNext={handleNextStep}
                uploadedFile={uploadedFile}
              />
            )}
            
            {currentStep === 'configure' && (
              <DagConfiguration
                config={dagConfig}
                onConfigChange={handleConfigChange}
                onNext={handleNextStep}
                onPrev={handlePrevStep}
                onGenerate={handleScriptGenerated}
                uploadedFile={uploadedFile}
              />
            )}
            
            {currentStep === 'generate' && (
              <ScriptGenerator
                config={dagConfig}
                generatedScript={generatedScript}
                onNext={handleNextStep}
                onPrev={handlePrevStep}
                onViewDashboard={handleViewDashboard}
                uploadedFile={uploadedFile}
              />
            )}
            
            {currentStep === 'xml-viewer' && (
              <XmlViewer
                uploadedFile={uploadedFile}
                config={dagConfig}
                onPrev={handlePrevStep}
                onStartOver={handleStartOver}
              />
            )}
          </div>
        </main>
      </div>

      {/* Add Chatbot */}
      <Chatbot />

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}