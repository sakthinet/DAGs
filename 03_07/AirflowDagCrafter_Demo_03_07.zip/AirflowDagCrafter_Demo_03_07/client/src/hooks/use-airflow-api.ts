import { useState, useCallback, useRef } from 'react';

// API request function - update the import path as needed
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  return response;
};

export interface DAG {
  dag_id: string;
  is_paused: boolean;
  is_active: boolean;
  last_parsed_time: string;
  last_pickled: string;
  last_expired: string;
  scheduler_lock: boolean;
  pickle_id: string;
  default_view: string;
  fileloc: string;
  file_token: string;
  owners: string[];
  description: string;
  schedule_interval: any;
  tags: string[];
  max_active_tasks: number;
  max_active_runs: number;
  has_task_concurrency_limits: boolean;
  has_import_errors: boolean;
  recent_runs: DAGRun[];
  run_count: number;
  tag_names?: string[];
  schedule_interval_display?: string;
}

export interface DAGRun {
  dag_run_id: string;
  dag_id: string;
  execution_date: string;
  logical_date?: string;
  start_date: string;
  end_date: string;
  state: 'success' | 'running' | 'failed' | 'queued' | 'scheduled';
  external_trigger: boolean;
  run_type: string;
  conf: any;
}

export interface TaskInstance {
  task_id: string;
  dag_id: string;
  run_id: string;
  execution_date: string;
  start_date: string;
  end_date: string;
  state: string;
  try_number: number;
  max_tries: number;
  hostname: string;
  unixname: string;
  job_id: number;
  pool: string;
  pool_slots: number;
  queue: string;
  priority_weight: number;
  operator: string;
  queued_dttm: string;
  pid: number;
  executor_config: any;
}

export interface AirflowInfo {
  version: {
    version: string;
    git_version: string;
  };
  config: {
    airflow_version: string;
    executor: string;
    api_version: string;
  };
}

// Simple client-side cache for immediate responses
class RequestCache {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  
  set(key: string, data: any, ttlSeconds = 30): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlSeconds * 1000
    });
  }
  
  get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    
    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return null;
    }
    
    return entry.data;
  }
  
  invalidate(pattern: string): void {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
  
  clear(): void {
    this.cache.clear();
  }
}

// Safe property access helper
const safeGet = (obj: any, path: string, defaultValue: any = null): any => {
  if (!obj || typeof obj !== 'object') return defaultValue;
  
  const keys = path.split('.');
  let current = obj;
  
  for (const key of keys) {
    if (current === null || current === undefined || typeof current !== 'object') {
      return defaultValue;
    }
    current = current[key];
  }
  
  return current !== undefined ? current : defaultValue;
};

// Enhanced helper function to safely process schedule interval
const getScheduleInterval = (scheduleInterval: any): string => {
  try {
    if (!scheduleInterval) return 'None';
    if (typeof scheduleInterval === 'string') return scheduleInterval;
    if (typeof scheduleInterval === 'object' && scheduleInterval !== null) {
      if (scheduleInterval.__type) return scheduleInterval.__type;
      if (scheduleInterval.value) return scheduleInterval.value;
      return 'Complex Schedule';
    }
    return 'Unknown';
  } catch (error) {
    console.warn('Error processing schedule interval:', error);
    return 'Error';
  }
};

// Enhanced helper function to safely process tags with comprehensive null checks
const getTagNames = (tags: any): string[] => {
  try {
    // Handle null, undefined, or non-array inputs
    if (!tags) return [];
    if (!Array.isArray(tags)) return [];
    
    return tags
      .filter(tag => tag !== null && tag !== undefined) // Filter out null/undefined items
      .map(tag => {
        try {
          if (typeof tag === 'string') return tag;
          if (typeof tag === 'object' && tag !== null && safeGet(tag, 'name')) {
            return safeGet(tag, 'name', 'Unknown Tag');
          }
          return 'Unknown Tag';
        } catch (error) {
          console.warn('Error processing individual tag:', tag, error);
          return 'Error Tag';
        }
      });
  } catch (error) {
    console.warn('Error processing tags array:', error);
    return [];
  }
};

// Enhanced helper function to safely process arrays
const safeArray = (arr: any, defaultValue: any[] = []): any[] => {
  try {
    if (!arr) return defaultValue;
    if (!Array.isArray(arr)) return defaultValue;
    return arr.filter(item => item !== null && item !== undefined);
  } catch (error) {
    console.warn('Error processing array:', error);
    return defaultValue;
  }
};

// Enhanced helper function to safely convert to number
const safeNumber = (value: any, defaultValue: number = 0): number => {
  try {
    if (value === null || value === undefined) return defaultValue;
    const num = Number(value);
    return isNaN(num) ? defaultValue : num;
  } catch (error) {
    console.warn('Error converting to number:', value, error);
    return defaultValue;
  }
};

// Enhanced helper function to safely convert to boolean
const safeBoolean = (value: any, defaultValue: boolean = false): boolean => {
  try {
    if (value === null || value === undefined) return defaultValue;
    return Boolean(value);
  } catch (error) {
    console.warn('Error converting to boolean:', value, error);
    return defaultValue;
  }
};

// COMPLETELY REWRITTEN processDAGData function with comprehensive null safety
const processDAGData = (dag: any): DAG | null => {
  try {
    // Primary null check
    if (!dag || typeof dag !== 'object') {
      console.warn('processDAGData received null or invalid dag:', dag);
      return null;
    }

    // Validate essential fields
    const dagId = safeGet(dag, 'dag_id', '');
    if (!dagId || typeof dagId !== 'string') {
      console.warn('processDAGData received DAG without valid dag_id:', dag);
      return null;
    }

    console.log(`Processing DAG data for: ${dagId}`);

    // Process all fields with safe accessors
    const processedDAG: DAG = {
      dag_id: dagId,
      is_paused: safeBoolean(safeGet(dag, 'is_paused'), false),
      is_active: safeBoolean(safeGet(dag, 'is_active'), true),
      last_parsed_time: safeGet(dag, 'last_parsed_time', '') || '',
      last_pickled: safeGet(dag, 'last_pickled', '') || '',
      last_expired: safeGet(dag, 'last_expired', '') || '',
      scheduler_lock: safeBoolean(safeGet(dag, 'scheduler_lock'), false),
      pickle_id: safeGet(dag, 'pickle_id', '') || '',
      default_view: safeGet(dag, 'default_view', 'graph') || 'graph',
      fileloc: safeGet(dag, 'fileloc', '') || '',
      file_token: safeGet(dag, 'file_token', '') || '',
      owners: safeArray(safeGet(dag, 'owners'), []),
      description: safeGet(dag, 'description', '') || '',
      schedule_interval: safeGet(dag, 'schedule_interval'),
      tags: safeArray(safeGet(dag, 'tags'), []),
      max_active_tasks: safeNumber(safeGet(dag, 'max_active_tasks'), 16),
      max_active_runs: safeNumber(safeGet(dag, 'max_active_runs'), 16),
      has_task_concurrency_limits: safeBoolean(safeGet(dag, 'has_task_concurrency_limits'), false),
      has_import_errors: safeBoolean(safeGet(dag, 'has_import_errors'), false),
      recent_runs: safeArray(safeGet(dag, 'recent_runs'), []),
      run_count: safeNumber(safeGet(dag, 'run_count'), 0),
      tag_names: getTagNames(safeGet(dag, 'tags')),
      schedule_interval_display: getScheduleInterval(safeGet(dag, 'schedule_interval'))
    };

    console.log(`Successfully processed DAG: ${dagId}`);
    return processedDAG;
    
  } catch (error) {
    console.error('Critical error in processDAGData:', error, 'DAG data:', dag);
    return null;
  }
};

// Enhanced DAG run processing with null safety
const processDAGRunData = (run: any): DAGRun | null => {
  try {
    if (!run || typeof run !== 'object') {
      console.warn('processDAGRunData received null or invalid run:', run);
      return null;
    }

    const runId = safeGet(run, 'dag_run_id', '') || safeGet(run, 'run_id', '');
    const dagId = safeGet(run, 'dag_id', '');
    
    if (!runId || !dagId) {
      console.warn('processDAGRunData received run without valid IDs:', run);
      return null;
    }

    return {
      dag_run_id: runId,
      dag_id: dagId,
      execution_date: safeGet(run, 'execution_date', '') || '',
      logical_date: safeGet(run, 'logical_date', '') || safeGet(run, 'execution_date', '') || '',
      start_date: safeGet(run, 'start_date', '') || '',
      end_date: safeGet(run, 'end_date', '') || '',
      state: safeGet(run, 'state', 'queued') || 'queued',
      external_trigger: safeBoolean(safeGet(run, 'external_trigger'), false),
      run_type: safeGet(run, 'run_type', 'manual') || 'manual',
      conf: safeGet(run, 'conf', {}) || {}
    };
  } catch (error) {
    console.error('Error processing DAG run data:', error);
    return null;
  }
};

export function useAirflowApi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Use ref for cache to persist across renders but not cause re-renders
  const cache = useRef(new RequestCache()).current;
  
  // Track ongoing requests to prevent duplicate calls
  const ongoingRequests = useRef(new Map<string, Promise<any>>()).current;

  const handleRequest = useCallback(async <T>(
    requestFn: () => Promise<Response>,
    cacheKey?: string,
    cacheTTL = 30,
    skipCache = false
  ): Promise<T | null> => {
    // Check cache first if not skipping cache
    if (!skipCache && cacheKey) {
      const cached = cache.get(cacheKey);
      if (cached) {
        console.log(`📦 Client cache hit for: ${cacheKey}`);
        return cached as T;
      }
    }

    // Check if request is already ongoing to prevent duplicates
    if (cacheKey && ongoingRequests.has(cacheKey)) {
      console.log(`⏳ Request already ongoing for: ${cacheKey}`);
      return ongoingRequests.get(cacheKey);
    }

    setLoading(true);
    setError(null);
    
    const requestPromise = (async () => {
      try {
        const startTime = performance.now();
        const response = await requestFn();
        const endTime = performance.now();
        
        console.log(`⚡ Request completed in ${(endTime - startTime).toFixed(2)}ms`);
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`HTTP ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        // More flexible success checking
        const isSuccessful = result.success !== false && 
                           (result.success === true || 
                            result.dags || 
                            result.connected !== undefined || 
                            result.dag || 
                            result.runs || 
                            result.task_instances ||
                            result.version);
        
        if (!isSuccessful) {
          throw new Error(result.message || 'Request failed');
        }
        
        // Cache successful responses
        if (!skipCache && cacheKey) {
          cache.set(cacheKey, result, cacheTTL);
          console.log(`💾 Cached result for: ${cacheKey} (TTL: ${cacheTTL}s)`);
        }
        
        return result as T;
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
        setError(errorMessage);
        console.error('Airflow API error:', err);
        throw err;
      } finally {
        setLoading(false);
        if (cacheKey) {
          ongoingRequests.delete(cacheKey);
        }
      }
    })();

    // Track ongoing request
    if (cacheKey) {
      ongoingRequests.set(cacheKey, requestPromise);
    }

    try {
      return await requestPromise;
    } catch (err) {
      return null;
    }
  }, [cache, ongoingRequests]);

  // Enhanced getDags with better error handling and null safety
  const getDags = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'all_dags_enhanced';
    
    try {
      console.log('🔍 Fetching all DAGs...');
      
      const result = await handleRequest<{ dags: any[]; total: number; success: true }>(
        () => apiRequest('GET', '/api/airflow/dags'),
        cacheKey,
        30, // 30 second cache
        forceRefresh
      );
      
      if (result && result.dags) {
        console.log(`📋 Processing ${result.dags.length} DAGs...`);
        
        // Process DAGs with enhanced null safety
        const processedDAGs = result.dags
          .map((dag, index) => {
            try {
              console.log(`Processing DAG ${index + 1}/${result.dags.length}: ${safeGet(dag, 'dag_id', 'unknown')}`);
              return processDAGData(dag);
            } catch (error) {
              console.error(`Error processing DAG at index ${index}:`, error);
              return null;
            }
          })
          .filter((dag): dag is DAG => dag !== null);
        
        console.log(`✅ Successfully processed ${processedDAGs.length} DAGs`);
        
        return {
          ...result,
          dags: processedDAGs,
          total: processedDAGs.length
        };
      }
      
      console.warn('No DAGs data in response');
      return null;
    } catch (error) {
      console.error('❌ Failed to get DAGs:', error);
      return null;
    }
  }, [handleRequest]);

  // COMPLETELY REWRITTEN getDag function with comprehensive null safety
  const getDag = useCallback(async (dagId: string, forceRefresh = false) => {
    const cacheKey = `dag_details_${dagId}`;
    
    try {
      console.log(`🔍 Getting DAG details for: ${dagId}`);
      
      // Validate input
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        console.error('Invalid dagId provided to getDag:', dagId);
        return null;
      }
      
      const result = await handleRequest<{
        dag: any;
        runs: any[];
        tasks: any[];
        success: true;
      }>(
        () => apiRequest('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}`),
        cacheKey,
        60, // 1 minute cache
        forceRefresh
      );
      
      if (!result) {
        console.warn(`No result received for DAG: ${dagId}`);
        return null;
      }
      
      // Process DAG data with enhanced null safety
      let processedDag: DAG | null = null;
      if (result.dag) {
        try {
          processedDag = processDAGData(result.dag);
          if (!processedDag) {
            console.error(`Failed to process DAG data for: ${dagId}`);
          }
        } catch (error) {
          console.error(`Error processing DAG data for ${dagId}:`, error);
          processedDag = null;
        }
      } else {
        console.warn(`No DAG data in response for: ${dagId}`);
      }
      
      // Process runs with null safety
      let processedRuns: DAGRun[] = [];
      if (result.runs && Array.isArray(result.runs)) {
        try {
          processedRuns = result.runs
            .map(run => processDAGRunData(run))
            .filter((run): run is DAGRun => run !== null);
          console.log(`✅ Processed ${processedRuns.length} runs for DAG: ${dagId}`);
        } catch (error) {
          console.error(`Error processing runs for ${dagId}:`, error);
          processedRuns = [];
        }
      }
      
      // Process tasks with null safety
      let processedTasks: any[] = [];
      if (result.tasks && Array.isArray(result.tasks)) {
        try {
          processedTasks = safeArray(result.tasks);
          console.log(`✅ Processed ${processedTasks.length} tasks for DAG: ${dagId}`);
        } catch (error) {
          console.error(`Error processing tasks for ${dagId}:`, error);
          processedTasks = [];
        }
      }
      
      return {
        ...result,
        dag: processedDag,
        runs: processedRuns,
        tasks: processedTasks
      };
      
    } catch (error) {
      console.error(`❌ Failed to get DAG ${dagId}:`, error);
      
      // Don't throw error for 404 as it just means DAG doesn't exist yet
      if (error instanceof Error && error.message.includes('404')) {
        console.log(`DAG ${dagId} not found in Airflow`);
      }
      
      // For other errors, return null instead of throwing
      return null;
    }
  }, [handleRequest]);

  // Enhanced triggerDag function with better error handling
  const triggerDag = useCallback(async (dagId: string, conf: any = {}) => {
    try {
      // Validate input
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      console.log(`🚀 Triggering DAG: ${dagId} with config:`, conf);
      
      const result = await handleRequest<{
        success: true;
        message: string;
        dag_run: DAGRun;
      }>(
        () => apiRequest('POST', `/api/airflow/dags/${encodeURIComponent(dagId)}/trigger`, { conf }),
        undefined, // Don't cache trigger requests
        0,
        true // Skip cache
      );
      
      if (result) {
        // Invalidate related caches
        cache.invalidate(dagId);
        cache.invalidate('all_dags');
        console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
        console.log(`✅ DAG triggered successfully:`, result);
        return result;
      } else {
        throw new Error('No response received from trigger API');
      }
    } catch (error) {
      console.error(`❌ Failed to trigger DAG ${dagId}:`, error);
      
      // Provide more specific error messages
      if (error instanceof Error) {
        if (error.message.includes('404')) {
          throw new Error(`DAG "${dagId}" not found in Airflow. Please ensure the DAG is deployed and Airflow has loaded it.`);
        } else if (error.message.includes('400')) {
          throw new Error(`Invalid request to trigger DAG "${dagId}". Check the DAG configuration.`);
        } else if (error.message.includes('401') || error.message.includes('403')) {
          throw new Error('Authentication failed. Please check Airflow connection.');
        } else if (error.message.includes('500')) {
          throw new Error(`Server error when triggering DAG "${dagId}". Check Airflow logs.`);
        } else if (error.message.includes('ECONNREFUSED')) {
          throw new Error('Cannot connect to Airflow. Please ensure Airflow is running.');
        }
      }
      
      throw error;
    }
  }, [handleRequest, cache]);

  // Pause/Unpause DAG with cache invalidation and enhanced error handling
  const pauseUnpauseDag = useCallback(async (dagId: string, isPaused: boolean) => {
    try {
      // Validate input
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      const result = await handleRequest<{
        success: true;
        message: string;
        dag: any;
      }>(
        () => apiRequest('PATCH', `/api/airflow/dags/${encodeURIComponent(dagId)}`, { is_paused: isPaused }),
        undefined, // Don't cache update requests
        0,
        true // Skip cache
      );
      
      if (result) {
        // Process the returned DAG data safely
        let processedDag: DAG | null = null;
        if (result.dag) {
          processedDag = processDAGData(result.dag);
        }
        
        // Invalidate related caches
        cache.invalidate(dagId);
        cache.invalidate('all_dags');
        console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
        
        return {
          ...result,
          dag: processedDag
        };
      }
      
      return result;
    } catch (error) {
      console.error(`❌ Failed to ${isPaused ? 'pause' : 'unpause'} DAG ${dagId}:`, error);
      throw error;
    }
  }, [handleRequest, cache]);

  // Enhanced getDagRuns with null safety
  const getDagRuns = useCallback(async (dagId: string, limit = 20, offset = 0, forceRefresh = false) => {
    const cacheKey = `dag_runs_${dagId}_${limit}_${offset}`;
    
    try {
      // Validate input
      if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
        throw new Error('Invalid DAG ID provided');
      }
      
      const result = await handleRequest<{
        runs: any[];
        total: number;
        success: true;
      }>(
        () => apiRequest('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}/runs?limit=${limit}&offset=${offset}`),
        cacheKey,
        30, // 30 second cache for runs
        forceRefresh
      );
      
      if (result && result.runs) {
        // Process runs with null safety
        const processedRuns = result.runs
          .map(run => processDAGRunData(run))
          .filter((run): run is DAGRun => run !== null);
          
        return {
          ...result,
          runs: processedRuns
        };
      }
      
      return result;
    } catch (error) {
      console.error(`❌ Failed to get DAG runs for ${dagId}:`, error);
      return null;
    }
  }, [handleRequest]);

  // Enhanced getTaskInstances with null safety
  const getTaskInstances = useCallback(async (dagId: string, runId: string, forceRefresh = false) => {
    const cacheKey = `task_instances_${dagId}_${runId}`;
    
    try {
      // Validate input
      if (!dagId || !runId || typeof dagId !== 'string' || typeof runId !== 'string') {
        throw new Error('Invalid DAG ID or Run ID provided');
      }
      
      return handleRequest<{
        task_instances: TaskInstance[];
        success: true;
      }>(
        () => apiRequest('GET', `/api/airflow/dags/${encodeURIComponent(dagId)}/runs/${encodeURIComponent(runId)}/tasks`),
        cacheKey,
        60, // 1 minute cache for task instances
        forceRefresh
      );
    } catch (error) {
      console.error(`❌ Failed to get task instances for ${dagId}/${runId}:`, error);
      return null;
    }
  }, [handleRequest]);

  // Get Airflow system info with long cache
  const getAirflowInfo = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'airflow_info';
    
    return handleRequest<AirflowInfo & { success: true }>(
      () => apiRequest('GET', '/api/airflow/info'),
      cacheKey,
      300, // 5 minute cache for system info
      forceRefresh
    );
  }, [handleRequest]);

  // Enhanced deleteDagRun with validation
  const deleteDagRun = useCallback(async (dagId: string, runId: string) => {
    try {
      // Validate input
      if (!dagId || !runId || typeof dagId !== 'string' || typeof runId !== 'string') {
        throw new Error('Invalid DAG ID or Run ID provided');
      }
      
      const result = await handleRequest<{
        success: true;
        message: string;
      }>(
        () => apiRequest('DELETE', `/api/airflow/dags/${encodeURIComponent(dagId)}/runs/${encodeURIComponent(runId)}`),
        undefined, // Don't cache delete requests
        0,
        true // Skip cache
      );
      
      if (result) {
        // Invalidate related caches
        cache.invalidate(dagId);
        cache.invalidate('all_dags');
        console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
      }
      
      return result;
    } catch (error) {
      console.error(`❌ Failed to delete DAG run ${dagId}/${runId}:`, error);
      throw error;
    }
  }, [handleRequest, cache]);

  // Test Airflow connection with short cache
  const testConnection = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'airflow_connection_test';
    
    return handleRequest<{
      connected: boolean;
      status?: any;
      url: string;
      token?: string;
      apiVersion?: string;
      authMethod?: string;
      error?: string;
    }>(
      () => apiRequest('GET', '/api/test-airflow'),
      cacheKey,
      60, // 1 minute cache for connection test
      forceRefresh
    );
  }, [handleRequest]);

  // Pause DAG specifically
  const pauseDag = useCallback(async (dagId: string) => {
    return pauseUnpauseDag(dagId, true);
  }, [pauseUnpauseDag]);

  // Unpause DAG specifically
  const unpauseDag = useCallback(async (dagId: string) => {
    return pauseUnpauseDag(dagId, false);
  }, [pauseUnpauseDag]);

  // Clear all caches
  const clearCache = useCallback(() => {
    cache.clear();
    ongoingRequests.clear();
    console.log('🧹 Cleared all client-side caches');
  }, [cache, ongoingRequests]);

  // Get cache stats for debugging
  const getCacheStats = useCallback(() => {
    const entries = Array.from(cache['cache'].entries());
    return {
      totalEntries: entries.length,
      entries: entries.map(([key, value]) => ({
        key,
        age: Date.now() - value.timestamp,
        ttl: value.ttl,
        expired: Date.now() - value.timestamp > value.ttl
      }))
    };
  }, [cache]);

  // Prefetch common data
  const prefetchData = useCallback(async () => {
    console.log('🔄 Prefetching common data...');
    
    // Prefetch DAGs list and connection status in parallel
    await Promise.allSettled([
      getDags(),
      testConnection(),
      getAirflowInfo()
    ]);
    
    console.log('✅ Prefetch completed');
  }, [getDags, testConnection, getAirflowInfo]);

  return {
    loading,
    error,
    
    // Main API methods
    getDags,
    getDag,
    triggerDag,
    pauseUnpauseDag,
    pauseDag,
    unpauseDag,
    getDagRuns,
    getTaskInstances,
    getAirflowInfo,
    deleteDagRun,
    testConnection,
    
    // Cache management
    clearCache,
    getCacheStats,
    prefetchData,
    
    // Utility methods
    setError,
    clearError: () => setError(null)
  };
}