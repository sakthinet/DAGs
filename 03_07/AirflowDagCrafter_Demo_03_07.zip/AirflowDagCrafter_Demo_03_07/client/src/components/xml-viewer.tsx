import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, RotateCcw, Check, Indent, FileCode, Download, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";

interface XmlViewerProps {
  uploadedFile: UploadedFile | null;
  config: DagConfig;
  onPrev: () => void;
  onStartOver: () => void;
}

export function XmlViewer({ uploadedFile, config, onPrev, onStartOver }: XmlViewerProps) {
  const [sampleXml, setSampleXml] = useState<string>('');
  const [xmlConfig, setXmlConfig] = useState({
    fileSizeLimit: '100',
    encoding: 'UTF-8',
    rootElement: 'TICKETS',
    validateStructure: true,
    prettyFormat: false,
    includeDeclaration: true
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (uploadedFile) {
      generateSampleXml();
    }
  }, [uploadedFile]);

  const generateSampleXml = async () => {
    if (!uploadedFile) return;
    
    setIsGenerating(true);
    try {
      const response = await apiRequest('POST', '/api/generate-sample-xml', {
        headers: uploadedFile.headers,
        sampleRows: uploadedFile.previewRows
      });
      
      const result = await response.json();
      if (result.success) {
        setSampleXml(result.xml);
      }
    } catch (error) {
      console.error('XML generation failed:', error);
      toast({
        title: "XML generation failed",
        description: "Failed to generate sample XML",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const formatXml = () => {
    // Simple XML formatting (in a real app, you'd use a proper XML formatter)
    try {
      const formatted = sampleXml.replace(/></g, '>\n<');
      setSampleXml(formatted);
      toast({
        title: "XML formatted",
        description: "XML has been formatted for better readability",
      });
    } catch (error) {
      toast({
        title: "Format failed",
        description: "Failed to format XML",
        variant: "destructive",
      });
    }
  };

  const validateXml = () => {
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(sampleXml, "text/xml");
      const parseError = xmlDoc.getElementsByTagName("parsererror");
      
      if (parseError.length === 0) {
        toast({
          title: "XML is valid",
          description: "XML structure validation passed",
        });
      } else {
        toast({
          title: "XML validation failed",
          description: "XML contains syntax errors",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Validation error",
        description: "Failed to validate XML",
        variant: "destructive",
      });
    }
  };

  const downloadSampleXml = () => {
    const blob = new Blob([sampleXml], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample_output.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download started",
      description: "Sample XML file has been downloaded",
    });
  };

  const generateXsdSchema = () => {
    // Simulate XSD generation
    toast({
      title: "XSD Schema generated",
      description: "XSD schema has been generated based on XML structure",
    });
  };

  const handleFinish = () => {
    toast({
      title: "Process completed successfully!",
      description: "Your DAG has been generated and configured.",
    });
  };

  const xmlStats = {
    elementCount: uploadedFile ? uploadedFile.headers.length * (1 + uploadedFile.previewRows.length) : 0,
    attributeCount: 0,
    maxDepth: 3,
    estimatedSize: uploadedFile ? Math.round((sampleXml.length / 1024) * 100) / 100 : 0
  };

  const processingStatus = [
    { label: "CSV parsed successfully", icon: CheckCircle, status: "success" },
    { label: "XML structure validated", icon: CheckCircle, status: "success" },
    { label: "Output file ready", icon: CheckCircle, status: "success" }
  ];

  return (
    <div className="max-w-6xl">
      <div className="grid lg:grid-cols-3 gap-6">
        {/* XML Preview */}
        <div className="lg:col-span-2">
          <Card className="shadow-sm border border-gray-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="text-lg font-semibold text-slate-800">
                Sample XML Output
              </CardTitle>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={formatXml}>
                  <Indent className="mr-1 h-4 w-4" />
                  Format
                </Button>
                <Button variant="outline" size="sm" onClick={validateXml}>
                  <Check className="mr-1 h-4 w-4" />
                  Validate
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative">
                {isGenerating ? (
                  <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                      <p className="text-gray-600">Generating sample XML...</p>
                    </div>
                  </div>
                ) : (
                  <pre className="text-sm bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto max-h-96 custom-scrollbar">
                    <code className="language-xml">{sampleXml}</code>
                  </pre>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* XML Configuration */}
        <div className="space-y-6">
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">XML Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fileSizeLimit">File Size Limit</Label>
                <Select 
                  value={xmlConfig.fileSizeLimit} 
                  onValueChange={(value) => setXmlConfig({...xmlConfig, fileSizeLimit: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 MB</SelectItem>
                    <SelectItem value="50">50 MB</SelectItem>
                    <SelectItem value="100">100 MB</SelectItem>
                    <SelectItem value="500">500 MB</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="encoding">Encoding</Label>
                <Select 
                  value={xmlConfig.encoding} 
                  onValueChange={(value) => setXmlConfig({...xmlConfig, encoding: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTF-8">UTF-8</SelectItem>
                    <SelectItem value="UTF-16">UTF-16</SelectItem>
                    <SelectItem value="ISO-8859-1">ISO-8859-1</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="rootElement">Root Element</Label>
                <Input
                  id="rootElement"
                  value={xmlConfig.rootElement}
                  onChange={(e) => setXmlConfig({...xmlConfig, rootElement: e.target.value})}
                />
              </div>

              <div className="space-y-3">
                <Label>Validation Options</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="validateStructure"
                      checked={xmlConfig.validateStructure}
                      onCheckedChange={(checked) => setXmlConfig({...xmlConfig, validateStructure: checked as boolean})}
                    />
                    <Label htmlFor="validateStructure" className="text-sm">Validate XML structure</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="prettyFormat"
                      checked={xmlConfig.prettyFormat}
                      onCheckedChange={(checked) => setXmlConfig({...xmlConfig, prettyFormat: checked as boolean})}
                    />
                    <Label htmlFor="prettyFormat" className="text-sm">Pretty format output</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="includeDeclaration"
                      checked={xmlConfig.includeDeclaration}
                      onCheckedChange={(checked) => setXmlConfig({...xmlConfig, includeDeclaration: checked as boolean})}
                    />
                    <Label htmlFor="includeDeclaration" className="text-sm">Include XML declaration</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* XML Schema Information */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Schema Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-700">Elements:</span>
                <span className="font-medium">{xmlStats.elementCount}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-700">Attributes:</span>
                <span className="font-medium">{xmlStats.attributeCount}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-700">Max Depth:</span>
                <span className="font-medium">{xmlStats.maxDepth}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-700">Est. Size:</span>
                <span className="font-medium text-accent">{xmlStats.estimatedSize} KB</span>
              </div>

              <Button className="w-full mt-4" onClick={generateXsdSchema}>
                <FileCode className="mr-2 h-4 w-4" />
                Generate XSD Schema
              </Button>
            </CardContent>
          </Card>

          {/* Processing Status */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Processing Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {processingStatus.map((status, index) => (
                <div key={index} className="flex items-center text-sm">
                  <status.icon className="text-accent mr-3 h-4 w-4" />
                  <span className="text-gray-700">{status.label}</span>
                </div>
              ))}

              <Button variant="outline" className="w-full mt-4" onClick={downloadSampleXml}>
                <Download className="mr-2 h-4 w-4" />
                Download Sample XML
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Generate
        </Button>
        <div className="flex space-x-4">
          <Button variant="outline" onClick={onStartOver}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Start Over
          </Button>
          <Button className="bg-accent hover:bg-accent/90" onClick={handleFinish}>
            <Check className="mr-2 h-4 w-4" />
            Complete Process
          </Button>
        </div>
      </div>
    </div>
  );
}
