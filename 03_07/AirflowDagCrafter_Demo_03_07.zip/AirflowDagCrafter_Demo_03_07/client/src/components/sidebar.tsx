import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, 
  Upload, 
  Code, 
  FileCode, 
  X, 
  CheckCircle,
  XCircle,
  BarChart3,
  Database,
  Activity
} from "lucide-react";
import { Step } from "@/pages/dag-generator";

interface SidebarProps {
  currentStep: Step;
  onStepChange: (step: Step) => void;
  isOpen: boolean;
  onClose: () => void;
  connectionStatus: {
    connected: boolean;
    url: string;
  };
}

export function Sidebar({ 
  currentStep, 
  onStepChange, 
  isOpen, 
  onClose, 
  connectionStatus 
}: SidebarProps) {
  const generatorSteps = [
    { key: 'upload' as const, icon: Upload, label: 'Upload CSV' },
    { key: 'configure' as const, icon: Settings, label: 'Configure DAG' },
    { key: 'generate' as const, icon: Code, label: 'Generate Script' },
    { key: 'xml-viewer' as const, icon: FileCode, label: 'XML Viewer' }
  ];

  const managementSteps = [
    { key: 'dashboard' as const, icon: BarChart3, label: 'DAG Dashboard' },
  ];

  return (
    <div className={`
      fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out
      lg:translate-x-0 lg:static lg:inset-0
      ${isOpen ? 'translate-x-0' : '-translate-x-full'}
    `}>
      <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Database className="text-white text-sm h-4 w-4" />
          </div>
          <h1 className="text-lg font-semibold text-slate-800">TCS Airflow DAGs Manager</h1>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="lg:hidden"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      <nav className="mt-6 px-4 space-y-6">
        {/* Airflow Connection Status */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-gray-500 uppercase tracking-wider">
            Connection Status
          </div>
          <div className={`flex items-center p-3 rounded-lg border ${
            connectionStatus.connected 
              ? 'bg-green-50 border-green-200 text-green-800' 
              : 'bg-red-50 border-red-200 text-red-800'
          }`}>
            {connectionStatus.connected ? (
              <CheckCircle className="w-4 h-4 mr-2" />
            ) : (
              <XCircle className="w-4 h-4 mr-2" />
            )}
            <div className="text-sm">
              <div className="font-medium">
                {connectionStatus.connected ? 'Connected' : 'Disconnected'}
              </div>
              <div className="text-xs opacity-75">
                {connectionStatus.url}
              </div>
            </div>
          </div>
        </div>

        {/* DAG Management Section */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-gray-500 uppercase tracking-wider">
            DAG Management
          </div>
          <div className="space-y-1">
            {managementSteps.map(({ key, icon: Icon, label }) => (
              <button
                key={key}
                onClick={() => onStepChange(key)}
                className={`
                  nav-item w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors text-left
                  ${currentStep === key 
                    ? 'active bg-blue-50 text-primary border-l-4 border-primary pl-3' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }
                `}
              >
                <Icon className="mr-3 h-4 w-4" />
                <span>{label}</span>
                {currentStep === key && (
                  <span className="ml-auto w-2 h-2 bg-primary rounded-full"></span>
                )}
              </button>
            ))}
          </div>
        </div>

        <Separator />

        {/* DAG Generator Section */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-gray-500 uppercase tracking-wider">
            DAG Generator
          </div>
          <div className="space-y-1">
            {generatorSteps.map(({ key, icon: Icon, label }) => (
              <button
                key={key}
                onClick={() => onStepChange(key)}
                className={`
                  nav-item w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors text-left
                  ${currentStep === key 
                    ? 'active bg-blue-50 text-primary border-l-4 border-primary pl-3' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }
                `}
              >
                <Icon className="mr-3 h-4 w-4" />
                <span>{label}</span>
                {currentStep === key && (
                  <span className="ml-auto w-2 h-2 bg-primary rounded-full"></span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        {connectionStatus.connected && (
          <>
            <Separator />
            <div className="space-y-2">
              <div className="text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quick Actions
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start"
                onClick={() => onStepChange('dashboard')}
              >
                <Activity className="mr-2 h-4 w-4" />
                View All DAGs
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start"
                onClick={() => onStepChange('upload')}
              >
                <Upload className="mr-2 h-4 w-4" />
                Create New DAG
              </Button>
            </div>
          </>
        )}
      </nav>
    </div>
  );
}