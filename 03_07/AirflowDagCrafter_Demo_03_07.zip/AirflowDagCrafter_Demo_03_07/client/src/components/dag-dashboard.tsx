import { useState, useEffect, useCallback, useMemo, memo, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Pause, 
  RefreshCw, 
  CheckCircle,
  XCircle,
  MoreHorizontal,
  Activity,
  Database,
  Eye,
  GitBranch,
  Sun,
  Moon,
  Search,
  Filter
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface DAG {
  dag_id: string;
  is_paused: boolean;
  is_active: boolean;
  last_parsed_time: string;
  description: string;
  schedule_interval_display?: string;
  tag_names?: string[];
  max_active_runs: number;
  fileloc: string;
  recent_runs: any[];
  run_count: number;
}

interface Statistics {
  total: number;
  active: number;
  paused: number;
  inactive: number;
  avgMaxRuns: number;
}

// Memoized Statistics Card Component
const StatCard = memo(({ title, value, icon: Icon, color }: {
  title: string;
  value: number;
  icon: any;
  color: string;
}) => (
  <Card className="transition-all duration-200 hover:shadow-md">
    <CardContent className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600 font-medium">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        <Icon className={`w-8 h-8 ${color}`} />
      </div>
    </CardContent>
  </Card>
));

// Memoized DAG Card Component
const DagCard = memo(({ 
  dag, 
  darkMode, 
  isSelected, 
  onToggleSelection, 
  onPause, 
  onUnpause, 
  onTrigger 
}: {
  dag: DAG;
  darkMode: boolean;
  isSelected: boolean;
  onToggleSelection: (dagId: string) => void;
  onPause: (dagId: string) => void;
  onUnpause: (dagId: string) => void;
  onTrigger: (dagId: string) => void;
}) => {
  const getFileInfo = useCallback((fileloc: string) => {
    const parts = fileloc.split('/');
    const filename = parts[parts.length - 1];
    const directory = parts.slice(0, -1).join('/');
    return { filename, directory };
  }, []);

  const getStatusColor = useCallback((isPaused: boolean, isActive: boolean) => {
    if (!isActive) return darkMode 
      ? 'bg-gray-800 text-gray-300 border-gray-600' 
      : 'bg-gray-100 text-gray-800 border-gray-200';
    if (isPaused) return darkMode 
      ? 'bg-orange-900 text-orange-300 border-orange-700' 
      : 'bg-orange-100 text-orange-800 border-orange-200';
    return darkMode 
      ? 'bg-green-900 text-green-300 border-green-700' 
      : 'bg-green-100 text-green-800 border-green-200';
  }, [darkMode]);

  const getStatusText = useCallback((isPaused: boolean, isActive: boolean) => {
    if (!isActive) return 'Inactive';
    if (isPaused) return 'Paused';
    return 'Active';
  }, []);

  const fileInfo = useMemo(() => getFileInfo(dag.fileloc), [dag.fileloc, getFileInfo]);
  
  return (
    <div className={`rounded-xl border-2 transition-all duration-300 hover:shadow-xl hover:scale-[1.02] ${
      isSelected ? 'ring-2 ring-blue-500' : ''
    } ${
      darkMode 
        ? 'bg-gray-800 border-gray-700 hover:border-gray-600' 
        : 'bg-white border-gray-200 hover:border-gray-300'
    }`}>
      <div className="p-6">
        {/* Header with Checkbox */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={() => onToggleSelection(dag.dag_id)}
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
            />
            <div className={`w-2 h-8 rounded-full ${
              dag.is_active && !dag.is_paused ? 'bg-green-500' : 
              dag.is_paused ? 'bg-orange-500' : 'bg-gray-400'
            }`}></div>
            <div>
              <h3 className={`text-lg font-bold truncate max-w-48 ${darkMode ? 'text-white' : 'text-gray-900'}`} title={dag.dag_id}>
                {dag.dag_id}
              </h3>
              <span className="text-2xl">
                {dag.is_paused ? '⏸️' : dag.is_active ? '▶️' : '⏹️'}
              </span>
            </div>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${getStatusColor(dag.is_paused, dag.is_active)}`}>
            {getStatusText(dag.is_paused, dag.is_active)}
          </span>
        </div>

        {/* Description */}
        <p className={`text-sm mb-4 line-clamp-2 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          {dag.description || 'No description available'}
        </p>

        {/* File Information */}
        <div className={`mb-4 p-3 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
          <div className="text-xs">
            <div className={`font-semibold truncate ${darkMode ? 'text-gray-300' : 'text-gray-700'}`} title={fileInfo.filename}>
              📁 {fileInfo.filename}
            </div>
            <div className={`mt-1 text-xs truncate ${darkMode ? 'text-gray-400' : 'text-gray-500'}`} title={fileInfo.directory}>
              {fileInfo.directory}
            </div>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 gap-4 text-sm mb-4">
          <div>
            <span className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Schedule:</span>
            <div className={`font-semibold mt-1 truncate ${darkMode ? 'text-white' : 'text-gray-900'}`} title={dag.schedule_interval_display || 'None'}>
              {dag.schedule_interval_display || 'None'}
            </div>
          </div>
          <div>
            <span className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Max Runs:</span>
            <div className={`font-semibold mt-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {dag.max_active_runs || 0}
            </div>
          </div>
        </div>

        {/* Last Parsed */}
        <div className="text-xs mb-4">
          <span className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Last Parsed:</span>
          <div className={`mt-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
            {dag.last_parsed_time ? new Date(dag.last_parsed_time).toLocaleString() : 'N/A'}
          </div>
        </div>

        {/* Tags */}
        {dag.tag_names && dag.tag_names.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {dag.tag_names.slice(0, 3).map((tagName, tagIndex) => (
              <span key={tagIndex} className={`text-xs px-2 py-1 rounded-full truncate max-w-20 ${
                darkMode 
                  ? 'bg-blue-900 text-blue-300 border border-blue-700' 
                  : 'bg-blue-100 text-blue-800 border border-blue-200'
              }`} title={tagName}>
                {tagName}
              </span>
            ))}
            {dag.tag_names.length > 3 && (
              <span className={`text-xs px-2 py-1 rounded-full ${
                darkMode 
                  ? 'bg-gray-700 text-gray-300' 
                  : 'bg-gray-100 text-gray-600'
              }`}>
                +{dag.tag_names.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2">
          <button
            onClick={() => dag.is_paused ? onUnpause(dag.dag_id) : onPause(dag.dag_id)}
            className={`flex-1 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
              dag.is_paused 
                ? 'bg-green-600 text-white hover:bg-green-700' 
                : 'bg-orange-600 text-white hover:bg-orange-700'
            }`}
          >
            {dag.is_paused ? '▶️ Unpause' : '⏸️ Pause'}
          </button>
          <button
            onClick={() => onTrigger(dag.dag_id)}
            className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors"
          >
            🚀 Trigger
          </button>
        </div>
      </div>
    </div>
  );
});

// Memoized Search and Filters Component
const SearchAndFilters = memo(({ 
  searchTerm, 
  onSearchChange, 
  statusFilter, 
  onStatusFilterChange, 
  onClearFilters,
  darkMode,
  resultCount,
  totalCount
}: {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  statusFilter: string;
  onStatusFilterChange: (value: string) => void;
  onClearFilters: () => void;
  darkMode: boolean;
  resultCount: number;
  totalCount: number;
}) => (
  <Card className="mb-6">
    <CardContent className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Search */}
        <div className="md:col-span-2 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search DAGs by name or description..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className={`w-full pl-10 pr-4 py-2 rounded-lg border transition-colors ${
              darkMode 
                ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500' 
                : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:border-blue-500'
            } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20`}
          />
        </div>

        {/* Status Filter */}
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          <select
            value={statusFilter}
            onChange={(e) => onStatusFilterChange(e.target.value)}
            className={`w-full pl-10 pr-4 py-2 rounded-lg border transition-colors appearance-none ${
              darkMode 
                ? 'bg-gray-700 border-gray-600 text-white focus:border-blue-500' 
                : 'bg-white border-gray-300 text-gray-900 focus:border-blue-500'
            } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20`}
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Results Summary */}
      <div className="mt-4 flex items-center justify-between">
        <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          Showing {resultCount} of {totalCount} DAGs
          {searchTerm && ` for "${searchTerm}"`}
        </span>
        
        {/* Clear Filters */}
        {(searchTerm || statusFilter !== 'all') && (
          <button
            onClick={onClearFilters}
            className="text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors"
          >
            Clear filters
          </button>
        )}
      </div>
    </CardContent>
  </Card>
));

export function DagDashboard() {
  const [dags, setDags] = useState<DAG[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [darkMode, setDarkMode] = useState(false);
  const [viewMode, setViewMode] = useState<'cards' | 'list'>('cards');
  const [selectedDags, setSelectedDags] = useState<Set<string>>(new Set());

  // Filter states with debouncing
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // CRITICAL: Add refs to prevent infinite loops
  const loadingRef = useRef(false);
  const mountedRef = useRef(true);
  const initialLoadDone = useRef(false);

  const { toast } = useToast();
  const airflowApi = useAirflowApi();

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Calculate statistics using useMemo
  const statistics = useMemo((): Statistics => {
    if (dags.length === 0) {
      return { total: 0, active: 0, paused: 0, inactive: 0, avgMaxRuns: 0 };
    }

    const total = dags.length;
    const active = dags.filter(dag => dag.is_active && !dag.is_paused).length;
    const paused = dags.filter(dag => dag.is_paused).length;
    const inactive = dags.filter(dag => !dag.is_active).length;
    const avgMaxRuns = Math.round(dags.reduce((sum, dag) => sum + (dag.max_active_runs || 0), 0) / total);

    return { total, active, paused, inactive, avgMaxRuns };
  }, [dags]);

  // Filter DAGs using useMemo with debounced search
  const filteredDags = useMemo(() => {
    return dags.filter(dag => {
      const matchesSearch = dag.dag_id.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                           (dag.description || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || 
                           (statusFilter === 'active' && dag.is_active && !dag.is_paused) ||
                           (statusFilter === 'paused' && dag.is_paused) ||
                           (statusFilter === 'inactive' && !dag.is_active);
      
      return matchesSearch && matchesStatus;
    });
  }, [dags, debouncedSearchTerm, statusFilter]);

  // Load theme preference
  useEffect(() => {
    const savedTheme = localStorage.getItem('airflow-dashboard-theme');
    if (savedTheme === 'dark') setDarkMode(true);
  }, []);

  // Apply theme
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('airflow-dashboard-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('airflow-dashboard-theme', 'light');
    }
  }, [darkMode]);

  // FIXED: Stable loadData function with proper guards
  const loadData = useCallback(async (forceRefresh = false) => {
    // CRITICAL: Prevent multiple simultaneous calls
    if (loadingRef.current) {
      console.log('⏭️ Load already in progress, skipping...');
      return;
    }

    // CRITICAL: Don't reload if we already have data and it's not a force refresh
    if (!forceRefresh && dags.length > 0 && initialLoadDone.current) {
      console.log('⏭️ Data already loaded, skipping...');
      return;
    }

    loadingRef.current = true;
    setLoading(true);
    setError(null);
    
    try {
      console.log('🔄 Loading DAGs from Airflow API...');
      const result = await airflowApi.getDags(forceRefresh);
      
      // CRITICAL: Check if component is still mounted
      if (!mountedRef.current) {
        console.log('⏭️ Component unmounted, aborting...');
        return;
      }
      
      if (result && result.dags) {
        console.log(`✅ Loaded ${result.dags.length} DAGs successfully`);
        setDags(result.dags);
        setLastRefresh(new Date());
        setError(null);
        initialLoadDone.current = true;
      } else {
        throw new Error('No DAGs data received from API');
      }
    } catch (err) {
      console.error('❌ Error loading DAGs:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to load DAGs';
      
      // Only set error if component is still mounted
      if (mountedRef.current) {
        setError(errorMessage);
        toast({
          title: "Failed to load DAGs",
          description: errorMessage,
          variant: "destructive",
        });
      }
    } finally {
      if (mountedRef.current) {
        setLoading(false);
      }
      loadingRef.current = false;
    }
  }, [airflowApi, toast, dags.length]); // FIXED: Remove unnecessary dependencies

  const pauseDag = useCallback(async (dagId: string) => {
    try {
      await airflowApi.pauseDag(dagId);
      
      setDags(prev => prev.map(dag => 
        dag.dag_id === dagId ? { ...dag, is_paused: true } : dag
      ));
      
      toast({
        title: "DAG paused",
        description: `DAG ${dagId} has been paused`,
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to pause DAG';
      setError(errorMessage);
      toast({
        title: "Failed to pause DAG",
        description: errorMessage,
        variant: "destructive",
      });
    }
  }, [airflowApi, toast]);

  const unpauseDag = useCallback(async (dagId: string) => {
    try {
      await airflowApi.unpauseDag(dagId);
      
      setDags(prev => prev.map(dag => 
        dag.dag_id === dagId ? { ...dag, is_paused: false } : dag
      ));
      
      toast({
        title: "DAG unpaused",
        description: `DAG ${dagId} has been unpaused`,
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to unpause DAG';
      setError(errorMessage);
      toast({
        title: "Failed to unpause DAG",
        description: errorMessage,
        variant: "destructive",
      });
    }
  }, [airflowApi, toast]);

  const triggerDag = useCallback(async (dagId: string) => {
    try {
      const result = await airflowApi.triggerDag(dagId, {
        triggered_by: 'dag_generator',
        timestamp: new Date().toISOString()
      });
      
      if (result) {
        toast({
          title: "DAG triggered successfully",
          description: `DAG run has been started for ${dagId}`,
        });
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to trigger DAG';
      setError(errorMessage);
      toast({
        title: "Failed to trigger DAG",
        description: errorMessage,
        variant: "destructive",
      });
    }
  }, [airflowApi, toast]);

  const toggleDagSelection = useCallback((dagId: string) => {
    setSelectedDags(prev => {
      const newSelected = new Set(prev);
      if (newSelected.has(dagId)) {
        newSelected.delete(dagId);
      } else {
        newSelected.add(dagId);
      }
      return newSelected;
    });
  }, []);

  const handleClearFilters = useCallback(() => {
    setSearchTerm('');
    setStatusFilter('all');
  }, []);

  const handleManualRefresh = useCallback(() => {
    console.log('🔄 Manual refresh triggered');
    loadData(true); // Force refresh
  }, [loadData]);

  const clearCache = useCallback(async () => {
    try {
      const response = await fetch('/api/cache/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.ok) {
        toast({
          title: "Cache cleared",
          description: "All cached data has been cleared",
        });
        // Force reload after clearing cache
        loadData(true);
      }
    } catch (error) {
      console.error('Failed to clear cache:', error);
      toast({
        title: "Failed to clear cache",
        description: "Could not clear cache",
        variant: "destructive",
      });
    }
  }, [loadData, toast]);

  // FIXED: Load data only once on component mount
  useEffect(() => {
    mountedRef.current = true;
    
    // Only load if we don't have data yet
    if (dags.length === 0 && !initialLoadDone.current) {
      console.log('🏗️ Component mounted, loading initial data...');
      loadData();
    }
    
    // Cleanup function
    return () => {
      console.log('🧹 Component unmounting...');
      mountedRef.current = false;
    };
  }, []); // CRITICAL: Empty dependency array - only run once!

  if (loading && dags.length === 0) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${
        darkMode ? 'bg-gray-900' : 'bg-gray-50'
      }`}>
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
          <h2 className={`text-xl font-semibold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            Loading DAGs...
          </h2>
          <p className={`${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            Fetching data from Airflow 3.x API
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      darkMode ? 'bg-gray-900' : 'bg-gray-50'
    }`}>
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6">
        {/* Header */}
        <div className={`rounded-xl border-2 p-6 mb-6 ${
          darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className={`text-4xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                Airflow DAGs Dashboard
              </h1>
              <p className={`mt-1 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                Monitor and manage your Apache Airflow DAGs (v3.x)
              </p>
            </div>
            <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
              {/* Theme Toggle */}
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  darkMode ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                <span className="text-sm font-medium">{darkMode ? 'Light' : 'Dark'}</span>
              </button>

              {/* View Mode Toggle */}
              <div className={`flex rounded-lg p-1 ${darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
                <button
                  onClick={() => setViewMode('cards')}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    viewMode === 'cards'
                      ? (darkMode ? 'bg-blue-600 text-white' : 'bg-blue-600 text-white')
                      : (darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900')
                  }`}
                >
                  📇 Cards
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    viewMode === 'list'
                      ? (darkMode ? 'bg-blue-600 text-white' : 'bg-blue-600 text-white')
                      : (darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900')
                  }`}
                >
                  📋 List
                </button>
              </div>

              {lastRefresh && (
                <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Last updated: {lastRefresh.toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <StatCard title="Total DAGs" value={statistics.total} icon={Database} color="text-blue-600" />
          <StatCard title="Active DAGs" value={statistics.active} icon={CheckCircle} color="text-green-600" />
          <StatCard title="Paused DAGs" value={statistics.paused} icon={Pause} color="text-yellow-600" />
          <StatCard title="Avg Max Runs" value={statistics.avgMaxRuns} icon={Activity} color="text-purple-600" />
        </div>

        {/* Search and Filters */}
        <SearchAndFilters
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
          onClearFilters={handleClearFilters}
          darkMode={darkMode}
          resultCount={filteredDags.length}
          totalCount={dags.length}
        />

        {/* Error Display */}
        {error && (
          <Card className="mb-6 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="flex items-start">
                <XCircle className="w-5 h-5 text-red-500 mr-3 mt-0.5" />
                <div>
                  <h3 className="font-bold text-red-800">Error</h3>
                  <p className="mt-1 text-sm text-red-700">{error}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4">
              <Button
                onClick={handleManualRefresh}
                disabled={loading}
              >
                {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                {loading ? 'Loading...' : 'Refresh DAGs'}
              </Button>
              
              <Button
                onClick={clearCache}
                variant="outline"
                disabled={loading}
              >
                Clear Cache
              </Button>
              
              <Button
                onClick={async () => {
                  try {
                    const result = await airflowApi.testConnection();
                    if (result && result.connected) {
                      toast({
                        title: "Connection successful",
                        description: `Connected to Airflow at ${result.url}`,
                      });
                    } else {
                      throw new Error(result?.error || 'Connection test failed');
                    }
                  } catch (err) {
                    const errorMessage = err instanceof Error ? err.message : 'Connection test failed';
                    setError(errorMessage);
                    toast({
                      title: "Connection failed",
                      description: errorMessage,
                      variant: "destructive",
                    });
                  }
                }}
                variant="outline"
                disabled={loading}
              >
                Test Connection
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <GitBranch className="w-5 h-5 mr-2" />
              DAGs Overview ({filteredDags.length}/{dags.length})
              {loading && (
                <RefreshCw className="w-4 h-4 animate-spin ml-2 text-blue-600" />
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredDags.length > 0 ? (
              viewMode === 'cards' ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredDags.map((dag) => (
                    <DagCard 
                      key={dag.dag_id} 
                      dag={dag}
                      darkMode={darkMode}
                      isSelected={selectedDags.has(dag.dag_id)}
                      onToggleSelection={toggleDagSelection}
                      onPause={pauseDag}
                      onUnpause={unpauseDag}
                      onTrigger={triggerDag}
                    />
                  ))}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-10">
                          <input
                            type="checkbox"
                            checked={selectedDags.size === filteredDags.length && filteredDags.length > 0}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedDags(new Set(filteredDags.map(dag => dag.dag_id)));
                              } else {
                                setSelectedDags(new Set());
                              }
                            }}
                            className="w-4 h-4"
                          />
                        </TableHead>
                        <TableHead>DAG ID</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Schedule</TableHead>
                        <TableHead>Last Parsed</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDags.map((dag) => (
                        <TableRow key={dag.dag_id}>
                          <TableCell>
                            <input
                              type="checkbox"
                              checked={selectedDags.has(dag.dag_id)}
                              onChange={() => toggleDagSelection(dag.dag_id)}
                              className="w-4 h-4"
                            />
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium">{dag.dag_id}</div>
                              <div className="text-sm text-gray-500 truncate max-w-xs">
                                {dag.description || 'No description'}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={dag.is_paused ? "secondary" : dag.is_active ? "default" : "outline"}>
                              {dag.is_paused ? 'Paused' : dag.is_active ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell>{dag.schedule_interval_display || 'None'}</TableCell>
                          <TableCell>{dag.last_parsed_time ? new Date(dag.last_parsed_time).toLocaleString() : 'N/A'}</TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => triggerDag(dag.dag_id)}
                                disabled={dag.is_paused || loading}
                              >
                                <Play className="w-4 h-4" />
                              </Button>
                              
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button size="sm" variant="outline" disabled={loading}>
                                    <MoreHorizontal className="w-4 h-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuItem 
                                    onClick={() => dag.is_paused ? unpauseDag(dag.dag_id) : pauseDag(dag.dag_id)}
                                  >
                                    {dag.is_paused ? (
                                      <>
                                        <Play className="w-4 h-4 mr-2" />
                                        Unpause
                                      </>
                                    ) : (
                                      <>
                                        <Pause className="w-4 h-4 mr-2" />
                                        Pause
                                      </>
                                    )}
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )
            ) : (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="font-bold mb-2">
                  {dags.length === 0 ? 'No DAGs found' : 'No DAGs match your filters'}
                </h3>
                <p className="mb-4 text-gray-500">
                  {dags.length === 0 
                    ? 'Click "Refresh DAGs" to load DAGs from Airflow 3.x API' 
                    : 'Try adjusting your search terms or filters'}
                </p>
                {dags.length === 0 && (
                  <Button onClick={handleManualRefresh} disabled={loading}>
                    {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : 'Refresh DAGs'}
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}