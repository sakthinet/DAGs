import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  ArrowRight, 
  Copy, 
  Download, 
  FolderPlus, 
  CheckCircle, 
  Rocket, 
  Play, 
  FileText, 
  Database, 
  Activity, 
  BarChart3,
  AlertCircle,
  Loader2,
  RefreshCw,
  Settings,
  Zap,
  XCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";

// API request function with better error handling
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  console.log(`Making API request: ${method} ${url}`);
  const response = await fetch(url, options);
  console.log(`API response status: ${response.status} ${response.statusText}`);
  
  return response;
};

// Helper function to safely parse API responses
const parseApiResponse = async (response: Response) => {
  const contentType = response.headers.get('content-type');
  
  if (contentType && contentType.includes('application/json')) {
    try {
      return await response.json();
    } catch (error) {
      console.error('Failed to parse JSON response:', error);
      throw new Error('Invalid JSON response from server');
    }
  } else {
    // If we get HTML instead of JSON, it's likely an error page
    const text = await response.text();
    console.error('Received non-JSON response:', text.substring(0, 200));
    throw new Error(`Server returned ${response.status}: Expected JSON but received HTML. The API endpoint may not be available.`);
  }
};

// Types
interface DagConfig {
  dagId: string;
  inputPath: string;
  outputPath: string;
  description: string;
  scheduleInterval: string;
  dagsDirectory: string;
}

interface UploadedFile {
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
}

interface ScriptGeneratorProps {
  config: DagConfig;
  generatedScript: string;
  onNext: () => void;
  onPrev: () => void;
  onViewDashboard: () => void;
  uploadedFile: UploadedFile | null;
}

export function ScriptGenerator({ 
  config, 
  generatedScript, 
  onNext, 
  onPrev, 
  onViewDashboard,
  uploadedFile 
}: ScriptGeneratorProps) {
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [isTriggering, setIsTriggering] = useState(false);
  const [dagDeployed, setDagDeployed] = useState(true); // Set to true since it's auto-deployed
  const [dagTriggered, setDagTriggered] = useState(false);
  const [validationStatus, setValidationStatus] = useState({
    syntax: true,
    dagId: true,
    filePaths: true,
    dependencies: true,
    fileLocation: true
  });
  const [testResults, setTestResults] = useState<any>(null);
  
  const { toast } = useToast();
  const { triggerDag, getDag, loading: airflowLoading, error: airflowError } = useAirflowApi();

  // Check if DAG exists in Airflow after deployment
  useEffect(() => {
    if (dagDeployed && config.dagId) {
      // Delay the check to allow Airflow time to load the DAG
      const timer = setTimeout(() => {
        checkDagInAirflow();
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [dagDeployed, config.dagId]);

  const checkDagInAirflow = async () => {
    try {
      console.log(`Checking if DAG ${config.dagId} exists in Airflow...`);
      const result = await getDag(config.dagId);
      if (result?.dag) {
        console.log(`✅ DAG ${config.dagId} found in Airflow`);
        setDagDeployed(true);
        
        // Update validation status to reflect that DAG is in Airflow
        setValidationStatus(prev => ({
          ...prev,
          dependencies: true,
          fileLocation: true
        }));
      } else {
        console.log(`❌ DAG ${config.dagId} not found in Airflow yet`);
        setDagDeployed(false);
      }
    } catch (error) {
      console.error('Failed to verify DAG in Airflow:', error);
      setDagDeployed(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedScript);
      toast({
        title: "Code copied",
        description: "DAG script has been copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Failed to copy code to clipboard",
        variant: "destructive",
      });
    }
  };

  const downloadScript = () => {
    const blob = new Blob([generatedScript], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${config.dagId}.py`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download started",
      description: `${config.dagId}.py has been downloaded`,
    });
  };

  const validateDeployment = async () => {
    setIsValidating(true);
    try {
      const response = await apiRequest('POST', '/api/validate-deployment', {
        dagId: config.dagId,
        inputPath: config.inputPath,
        outputPath: config.outputPath,
        dagsDirectory: config.dagsDirectory
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      setValidationStatus(result.validation || validationStatus);
      
      if (result.success) {
        toast({
          title: "Validation completed",
          description: "All deployment checks passed successfully",
        });
      } else {
        toast({
          title: "Validation issues found",
          description: result.message || "Some validation checks failed",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Validation failed:', error);
      toast({
        title: "Validation failed",
        description: error instanceof Error ? error.message : "Failed to validate deployment",
        variant: "destructive",
      });
    } finally {
      setIsValidating(false);
    }
  };

  const saveToDagsDirectory = async () => {
    setIsSaving(true);
    try {
      const response = await apiRequest('POST', '/api/save-dag', {
        dagId: config.dagId,
        dagScript: generatedScript,
        dagsDirectory: config.dagsDirectory
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      if (result.success) {
        setDagDeployed(true);
        toast({
          title: "DAG saved successfully",
          description: result.note ? 
            `${result.note} File saved to: ${result.filePath}` : 
            `Saved to ${result.filePath}`,
        });
        
        // Trigger a check to see if DAG appears in Airflow
        setTimeout(() => checkDagInAirflow(), 3000);
      } else {
        throw new Error(result.message || 'Failed to save DAG');
      }
    } catch (error) {
      console.error('Save failed:', error);
      toast({
        title: "Save failed",
        description: error instanceof Error ? error.message : "Failed to save DAG to directory",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const testDag = async () => {
    setIsTesting(true);
    setTestResults(null);
    
    try {
      console.log(`Testing DAG: ${config.dagId}`);
      
      const response = await apiRequest('POST', '/api/test-dag', {
        dagId: config.dagId,
        dagScript: generatedScript
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      setTestResults(result);
      
      if (result.success) {
        // Update validation status with results
        if (result.validation) {
          setValidationStatus(result.validation);
        }
        
        toast({
          title: "DAG test completed",
          description: "DAG syntax and structure validation passed successfully",
        });
      } else {
        // Update validation status even on failure
        if (result.validation) {
          setValidationStatus(result.validation);
        }
        
        const errorDetails = result.errors && result.errors.length > 0 
          ? `Issues found: ${result.errors.join(', ')}` 
          : result.message || "DAG validation failed";
        
        toast({
          title: "DAG test failed",
          description: errorDetails,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Test failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to test DAG';
      
      // Set failed validation status
      setValidationStatus(prev => ({
        ...prev,
        syntax: false,
        dependencies: false
      }));
      
      setTestResults({
        success: false,
        message: errorMessage,
        errors: [errorMessage]
      });
      
      toast({
        title: "Test failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsTesting(false);
    }
  };

  const deployToAirflow = async () => {
    setIsDeploying(true);
    try {
      // First save the DAG
      const response = await apiRequest('POST', '/api/save-dag', {
        dagId: config.dagId,
        dagScript: generatedScript,
        dagsDirectory: config.dagsDirectory
      });
      
      if (!response.ok) {
        const errorResult = await parseApiResponse(response);
        throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await parseApiResponse(response);
      if (result.success) {
        setDagDeployed(true);
        toast({
          title: "DAG deployed successfully",
          description: `DAG ${config.dagId} has been saved. Airflow will load it within 30 seconds.`,
        });
        
        // Wait a moment then check if DAG appears in Airflow
        setTimeout(async () => {
          try {
            await checkDagInAirflow();
          } catch (error) {
            console.log('DAG not yet visible in Airflow, this is normal and may take up to 30 seconds');
          }
        }, 5000);
        
      } else {
        throw new Error(result.message || 'Deployment failed');
      }
    } catch (error) {
      console.error('Deployment failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to deploy DAG to Airflow';
      toast({
        title: "Deployment failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsDeploying(false);
    }
  };

  const triggerDagRun = async () => {
    setIsTriggering(true);
    try {
      console.log(`Attempting to trigger DAG: ${config.dagId}`);
      
      // First verify DAG exists in Airflow
      console.log(`Checking if DAG ${config.dagId} exists in Airflow...`);
      
      let dagResult;
      try {
        dagResult = await getDag(config.dagId);
      } catch (dagError) {
        console.error('Error checking DAG status:', dagError);
        // If we can't get the DAG, try to trigger anyway and let the API handle it
      }
      
      if (dagResult && !dagResult.dag) {
        toast({
          title: "DAG not found",
          description: `DAG ${config.dagId} not found in Airflow. Please wait a few seconds for Airflow to load the DAG and try again.`,
          variant: "destructive",
        });
        return;
      }
      
      if (dagResult?.dag?.is_paused) {
        toast({
          title: "DAG is paused",
          description: "The DAG is currently paused. Please unpause it first in the dashboard.",
          variant: "destructive",
        });
        return;
      }
      
      console.log(`Triggering DAG: ${config.dagId}`);
      const result = await triggerDag(config.dagId, {
        triggered_by: 'dag_generator',
        timestamp: new Date().toISOString(),
        conf: {
          input_file: config.inputPath,
          output_file: config.outputPath,
          description: config.description
        }
      });
      
      if (result && result.dag_run) {
        setDagTriggered(true);
        toast({
          title: "DAG triggered successfully",
          description: `DAG run ${result.dag_run.dag_run_id} has been started. Check the dashboard to monitor progress.`,
        });
      } else if (result && result.success) {
        setDagTriggered(true);
        toast({
          title: "DAG triggered successfully",
          description: `DAG run has been started. Check the dashboard to monitor progress.`,
        });
      } else {
        throw new Error('No DAG run information returned');
      }
    } catch (error) {
      console.error('Failed to trigger DAG:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to trigger DAG run';
      toast({
        title: "Failed to trigger DAG",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsTriggering(false);
    }
  };

  const validationResults = [
    { label: "Syntax validation", icon: CheckCircle, status: validationStatus.syntax ? "success" : "error" },
    { label: "DAG ID is unique", icon: CheckCircle, status: validationStatus.dagId ? "success" : "error" },
    { label: "File paths validated", icon: CheckCircle, status: validationStatus.filePaths ? "success" : "error" },
    { label: "Dependencies available", icon: CheckCircle, status: validationStatus.dependencies ? "success" : "error" },
    { label: "DAG deployed to Airflow", icon: CheckCircle, status: dagDeployed ? "success" : "error" }
  ];

  return (
    <div className="max-w-6xl">
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Generated Code */}
        <div className="lg:col-span-2">
          <Card className="shadow-sm border border-gray-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="text-lg font-semibold text-slate-800">
                Generated DAG Script
              </CardTitle>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  <Copy className="mr-1 h-4 w-4" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadScript}>
                  <Download className="mr-1 h-4 w-4" />
                  Download
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <pre className="text-sm bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto max-h-96 custom-scrollbar">
                  <code className="language-python">{generatedScript}</code>
                </pre>
              </div>
              
              {/* File Status */}
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <h4 className="text-sm font-medium text-gray-800 mb-2">File Status</h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div className="flex items-center">
                    <Database className="mr-2 h-4 w-4 text-green-600" />
                    <div>
                      <div className="font-medium">CSV Input</div>
                      <div className="text-gray-600 break-all">{config.inputPath}</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <FileText className="mr-2 h-4 w-4 text-blue-600" />
                    <div>
                      <div className="font-medium">XML Output</div>
                      <div className="text-gray-600 break-all">{config.outputPath}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Deployment Status */}
              {dagDeployed && (
                <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center text-green-700">
                    <CheckCircle className="mr-2 h-4 w-4" />
                    <div className="font-medium">DAG Deployed Successfully</div>
                  </div>
                  <div className="text-sm text-green-600 mt-1">
                    Your DAG is available in Airflow and ready to run
                  </div>
                </div>
              )}

              {/* Trigger Status */}
              {dagTriggered && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center text-blue-700">
                    <Activity className="mr-2 h-4 w-4" />
                    <div className="font-medium">DAG Run Started</div>
                  </div>
                  <div className="text-sm text-blue-600 mt-1">
                    Check the dashboard to monitor progress
                  </div>
                </div>
              )}

              {/* Test Results */}
              {testResults && (
                <div className={`mt-4 p-3 rounded-lg border ${
                  testResults.success 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-red-50 border-red-200'
                }`}>
                  <div className={`flex items-center ${
                    testResults.success ? 'text-green-700' : 'text-red-700'
                  }`}>
                    {testResults.success ? (
                      <CheckCircle className="mr-2 h-4 w-4" />
                    ) : (
                      <XCircle className="mr-2 h-4 w-4" />
                    )}
                    <div className="font-medium">
                      {testResults.success ? 'Test Passed' : 'Test Failed'}
                    </div>
                  </div>
                  <div className={`text-sm mt-1 ${
                    testResults.success ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {testResults.message}
                  </div>
                  {testResults.errors && testResults.errors.length > 0 && (
                    <div className="mt-2">
                      {testResults.errors.map((error: string, index: number) => (
                        <div key={index} className="text-xs text-red-600 mt-1">
                          • {error}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Actions Panel */}
        <div className="space-y-6">
          {/* Deployment Actions */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Deployment Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-green-600 bg-green-50 p-3 rounded-lg border border-green-200">
                <div className="font-medium mb-1">✓ Auto-deployed to DAGs directory</div>
                <div className="text-xs text-green-700">
                  Script automatically saved to: {config.dagsDirectory}
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={downloadScript}
              >
                <div className="text-left">
                  <div className="font-medium">Download Copy</div>
                  <div className="text-xs text-muted-foreground">Save backup to local machine</div>
                </div>
                <Download className="h-4 w-4" />
              </Button>

              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={validateDeployment}
                disabled={isValidating}
              >
                <div className="text-left">
                  <div className="font-medium">
                    {isValidating ? 'Validating...' : 'Re-validate Deployment'}
                  </div>
                  <div className="text-xs text-muted-foreground">Check file locations & paths</div>
                </div>
                {isValidating ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle className="h-4 w-4" />
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Airflow Integration */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Airflow Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-700">DAG Status</span>
                <div className="flex items-center">
                  {dagDeployed ? (
                    <Badge variant="default" className="bg-green-600">Deployed</Badge>
                  ) : (
                    <Badge variant="outline">Not Found</Badge>
                  )}
                </div>
              </div>
              
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                onClick={deployToAirflow}
                disabled={isDeploying}
              >
                {isDeploying ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deploying...
                  </>
                ) : (
                  <>
                    <Rocket className="mr-2 h-4 w-4" />
                    Re-deploy to Airflow
                  </>
                )}
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full"
                onClick={testDag}
                disabled={isTesting}
              >
                {isTesting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Test DAG
                  </>
                )}
              </Button>

              {/* Trigger DAG */}
              <Button 
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                onClick={triggerDagRun}
                disabled={isTriggering || airflowLoading}
              >
                {isTriggering ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Triggering...
                  </>
                ) : (
                  <>
                    <Activity className="mr-2 h-4 w-4" />
                    Trigger DAG Run
                  </>
                )}
              </Button>

              {/* View in Dashboard */}
              <Button 
                variant="outline" 
                className="w-full"
                onClick={onViewDashboard}
              >
                <BarChart3 className="mr-2 h-4 w-4" />
                View in Dashboard
              </Button>
            </CardContent>
          </Card>

          {/* Validation Results */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Validation Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {validationResults.map((result, index) => (
                <div key={index} className="flex items-center text-sm">
                  <result.icon className={`mr-3 h-4 w-4 ${
                    result.status === 'success' ? 'text-green-600' : 'text-red-600'
                  }`} />
                  <span className="text-gray-700">{result.label}</span>
                  {result.status === 'success' ? (
                    <span className="ml-auto text-green-600 text-xs">✓</span>
                  ) : (
                    <span className="ml-auto text-red-600 text-xs">✗</span>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* File Locations */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">File Locations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-xs space-y-2">
                <div>
                  <div className="font-medium text-gray-700">DAG Script:</div>
                  <div className="text-gray-600 break-all font-mono">
                    {config.dagsDirectory}\{config.dagId}.py
                  </div>
                </div>
                <div>
                  <div className="font-medium text-gray-700">Data Directory:</div>
                  <div className="text-gray-600 break-all font-mono">
                    C:\Docker\airflow3x2\data\
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Configuration
        </Button>
        <Button onClick={onNext}>
          View XML Output
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}