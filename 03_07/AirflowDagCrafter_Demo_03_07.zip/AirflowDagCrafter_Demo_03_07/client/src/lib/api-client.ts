// src/lib/api-client.ts
// Simple API client utility for making requests

export const apiRequest = async (method: string, url: string, data?: any): Promise<Response> => {
  const config: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  };

  if (data && method !== 'GET') {
    config.body = JSON.stringify(data);
  }

  // Add any additional query parameters for GET requests
  let requestUrl = url;
  if (data && method === 'GET') {
    const params = new URLSearchParams();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        params.append(key, String(data[key]));
      }
    });
    const queryString = params.toString();
    if (queryString) {
      requestUrl += (url.includes('?') ? '&' : '?') + queryString;
    }
  }

  try {
    console.log(`Making ${method} request to: ${requestUrl}`);
    const response = await fetch(requestUrl, config);
    
    if (!response.ok) {
      console.error(`API request failed: ${method} ${requestUrl} - ${response.status} ${response.statusText}`);
    }
    
    return response;
  } catch (error) {
    console.error(`Network error for ${method} ${requestUrl}:`, error);
    throw error;
  }
};

// Alternative export if you prefer named exports
export { apiRequest as default };