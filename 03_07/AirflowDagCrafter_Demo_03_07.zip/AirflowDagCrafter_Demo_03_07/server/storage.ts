import { users, dagConfigurations, type User, type InsertUser, type DagConfiguration, type InsertDagConfiguration } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getDagConfiguration(id: number): Promise<DagConfiguration | undefined>;
  getDagConfigurationByDagId(dagId: string): Promise<DagConfiguration | undefined>;
  createDagConfiguration(config: InsertDagConfiguration): Promise<DagConfiguration>;
  getAllDagConfigurations(): Promise<DagConfiguration[]>;
  updateDagConfiguration(id: number, config: Partial<InsertDagConfiguration>): Promise<DagConfiguration>;
  deleteDagConfiguration(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private dagConfigurations: Map<number, DagConfiguration>;
  private currentUserId: number;
  private currentDagConfigId: number;

  constructor() {
    this.users = new Map();
    this.dagConfigurations = new Map();
    this.currentUserId = 1;
    this.currentDagConfigId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getDagConfiguration(id: number): Promise<DagConfiguration | undefined> {
    return this.dagConfigurations.get(id);
  }

  async getDagConfigurationByDagId(dagId: string): Promise<DagConfiguration | undefined> {
    return Array.from(this.dagConfigurations.values()).find(
      (config) => config.dagId === dagId,
    );
  }

  async createDagConfiguration(insertConfig: InsertDagConfiguration): Promise<DagConfiguration> {
    const id = this.currentDagConfigId++;
    const config: DagConfiguration = { 
      ...insertConfig,
      description: insertConfig.description || null,
      scheduleInterval: insertConfig.scheduleInterval || null,
      dagsDirectory: insertConfig.dagsDirectory || null,
      id,
      createdAt: new Date()
    };
    this.dagConfigurations.set(id, config);
    return config;
  }

  async getAllDagConfigurations(): Promise<DagConfiguration[]> {
    return Array.from(this.dagConfigurations.values());
  }

  async updateDagConfiguration(id: number, updateConfig: Partial<InsertDagConfiguration>): Promise<DagConfiguration> {
    const existing = this.dagConfigurations.get(id);
    if (!existing) {
      throw new Error(`DAG configuration with id ${id} not found`);
    }
    const updated = { ...existing, ...updateConfig };
    this.dagConfigurations.set(id, updated);
    return updated;
  }

  async deleteDagConfiguration(id: number): Promise<void> {
    this.dagConfigurations.delete(id);
  }
}

export const storage = new MemStorage();
