// routes.ts - Optimized version with caching and batch operations

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { dagConfigurationSchema, type DagConfigurationInput } from "@shared/schema";
import { z } from "zod";
import fs from "fs/promises";
import path from "path";
import multer from "multer";
import { execSync } from "child_process";

// Configure multer for file uploads
const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv') || file.mimetype === 'application/vnd.ms-excel') {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  }
});

// Cache configuration
interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiry: number;
}

class SimpleCache {
  private cache = new Map<string, CacheEntry<any>>();
  
  set<T>(key: string, data: T, ttlSeconds = 30): void {
    const now = Date.now();
    this.cache.set(key, {
      data,
      timestamp: now,
      expiry: now + (ttlSeconds * 1000)
    });
  }
  
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    
    if (Date.now() > entry.expiry) {
      this.cache.delete(key);
      return null;
    }
    
    return entry.data;
  }
  
  clear(): void {
    this.cache.clear();
  }
  
  invalidatePattern(pattern: string): void {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

const cache = new SimpleCache();

// Airflow 3.x configuration
const AIRFLOW_CONFIG = {
  baseUrl: process.env.AIRFLOW_URL || "http://localhost:8083",
  apiVersion: '/api/v2',
  authEndpoint: '/auth/token',
  defaultCredentials: {
    username: process.env.AIRFLOW_USERNAME || 'airflow',
    password: process.env.AIRFLOW_PASSWORD || 'airflow'
  }
};

// Global JWT token management
let currentJwtToken: string | null = null;
let tokenExpiry: number | null = null;
let isAuthenticating = false;

// Helper function to check if token is expired
const isTokenExpired = (): boolean => {
  if (!currentJwtToken || !tokenExpiry) return true;
  const fiveMinutesFromNow = Date.now() + (5 * 60 * 1000);
  return tokenExpiry <= fiveMinutesFromNow;
};

// Function to authenticate and get JWT token
const authenticateAndGetToken = async (): Promise<string> => {
  if (isAuthenticating) {
    while (isAuthenticating) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return currentJwtToken!;
  }

  isAuthenticating = true;
  
  try {
    console.log('🔐 Authenticating with Airflow 3.x API...');
    
    const response = await fetch(`${AIRFLOW_CONFIG.baseUrl}${AIRFLOW_CONFIG.authEndpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        username: AIRFLOW_CONFIG.defaultCredentials.username,
        password: AIRFLOW_CONFIG.defaultCredentials.password
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Authentication failed: HTTP ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    const token = data.access_token || data.token || data.accessToken;
    
    if (!token) {
      throw new Error('No access token received from authentication endpoint');
    }

    currentJwtToken = token;
    tokenExpiry = Date.now() + (50 * 60 * 1000);
    
    console.log('✅ Successfully authenticated with Airflow 3.x API');
    return currentJwtToken;
    
  } catch (error) {
    console.error('❌ Authentication failed:', error);
    currentJwtToken = null;
    tokenExpiry = null;
    throw error;
  } finally {
    isAuthenticating = false;
  }
};

// Function to get valid JWT token
const getValidToken = async (): Promise<string> => {
  if (isTokenExpired()) {
    console.log('🔄 Token expired or missing, getting new token...');
    return await authenticateAndGetToken();
  }
  return currentJwtToken!;
};

// Helper function to make authenticated API requests with caching
const makeAuthenticatedRequest = async (endpoint: string, options: RequestInit = {}, cacheKey?: string, cacheTTL = 30): Promise<any> => {
  // Check cache first for GET requests
  if ((!options.method || options.method === 'GET') && cacheKey) {
    const cached = cache.get(cacheKey);
    if (cached) {
      console.log(`📦 Cache hit for: ${cacheKey}`);
      return cached;
    }
  }

  const maxRetries = 2;
  let retryCount = 0;
  
  while (retryCount < maxRetries) {
    try {
      const token = await getValidToken();
      const url = `${AIRFLOW_CONFIG.baseUrl}${AIRFLOW_CONFIG.apiVersion}${endpoint}`;
      
      const config: RequestInit = {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`,
          ...options.headers
        },
        ...options,
      };

      console.log(`📡 Making authenticated request to: ${url}`);
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorText = await response.text();
        if (response.status === 401 || response.status === 403) {
          console.log('🔐 Authentication error detected, clearing token...');
          currentJwtToken = null;
          tokenExpiry = null;
          if (retryCount === 0) {
            retryCount++;
            continue;
          }
        }
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const contentType = response.headers.get('content-type');
      let result;
      
      if (contentType && contentType.includes('application/json')) {
        result = await response.json();
      } else if (response.status === 204 || response.status === 200) {
        result = { success: true };
      } else {
        result = await response.text();
      }

      // Cache successful GET responses
      if ((!options.method || options.method === 'GET') && cacheKey) {
        cache.set(cacheKey, result, cacheTTL);
        console.log(`💾 Cached result for: ${cacheKey}`);
      }
      
      return result;
      
    } catch (error) {
      console.error(`API Request failed for ${endpoint} (attempt ${retryCount + 1}):`, error);
      
      if (retryCount >= maxRetries - 1) {
        throw error;
      }
      retryCount++;
    }
  }
};
const fetchDagRunsCompatible = async (dagId: string, limit: number = 5, offset: number = 0): Promise<any> => {
  const endpoints = [
    // Try Airflow 3.x format first
    `/dags/${dagId}/dagRuns?limit=${limit}&offset=${offset}&order_by=-logical_date`,
    // Fallback to Airflow 2.x format
    `/dags/${dagId}/dagRuns?limit=${limit}&offset=${offset}&order_by=-execution_date`,
    // Final fallback without ordering
    `/dags/${dagId}/dagRuns?limit=${limit}&offset=${offset}`
  ];

  for (const endpoint of endpoints) {
    try {
      console.log(`Trying endpoint: ${endpoint}`);
      const result = await makeAuthenticatedRequest(endpoint, {}, undefined, 0, true);
      console.log(`✅ Success with endpoint: ${endpoint}`);
      return result;
    } catch (error) {
      console.log(`❌ Failed with endpoint: ${endpoint}`);
      if (endpoint === endpoints[endpoints.length - 1]) {
        throw error; // Re-throw if it's the last attempt
      }
      continue;
    }
  }
};
// Batch function to get multiple DAG runs efficiently
const getBatchDagRuns = async (dagIds: string[], limit = 5): Promise<Record<string, any[]>> => {
  const cacheKey = `batch_runs_${dagIds.join(',')}_${limit}`;
  const cached = cache.get<Record<string, any[]>>(cacheKey);
  if (cached) {
    console.log('📦 Cache hit for batch DAG runs');
    return cached;
  }

  const runsMap: Record<string, any[]> = {};
  
  // Process in batches of 5 to avoid overwhelming the API
  const batchSize = 5;
  for (let i = 0; i < dagIds.length; i += batchSize) {
    const batch = dagIds.slice(i, i + batchSize);
    
    const batchPromises = batch.map(async (dagId) => {
      try {
        const runs = await fetchDagRunsCompatible(dagId, limit);
        return { dagId, runs: runs.dag_runs || [] };
      } catch (error) {
        console.error(`Failed to get runs for DAG ${dagId}:`, error);
        return { dagId, runs: [] };
      }
    });
    
    const batchResults = await Promise.all(batchPromises);
    
    batchResults.forEach(({ dagId, runs }) => {
      runsMap[dagId] = runs;
    });
  }
  
  // Cache the batch result
  cache.set(cacheKey, runsMap, 20);
  return runsMap;
};
// Helper function to try Windows path first, fallback to local if needed
async function getTargetPath(targetPath: string, fallbackType: 'dags' | 'data' = 'dags'): Promise<{ path: string, isLocal: boolean }> {
  if (targetPath.includes(':\\')) {
    try {
      const targetDir = path.dirname(targetPath);
      await fs.mkdir(targetDir, { recursive: true });
      
      const testFile = path.join(targetDir, '.write-test');
      await fs.writeFile(testFile, 'test');
      await fs.unlink(testFile);
      
      console.log(`✓ Using actual Windows path: ${targetPath}`);
      return { path: targetPath, isLocal: false };
    } catch (error) {
      console.log(`⚠️ Cannot access Windows path ${targetPath}, falling back to local: ${error}`);
    }
  }
  
  const pathParts = targetPath.split(/[\\\/]/);
  const lastPart = pathParts[pathParts.length - 1];
  const localPath = `./${lastPart}`;
  
  console.log(`Using local fallback path: ${localPath}`);
  return { path: localPath, isLocal: true };
}

// Helper function to ensure directory exists
async function ensureDirectory(dirPath: string): Promise<void> {
  try {
    await fs.mkdir(dirPath, { recursive: true });
  } catch (error) {
    console.error(`Failed to create directory ${dirPath}:`, error);
    throw error;
  }
}

// Helper function to find file in multiple locations
async function findFile(fileName: string): Promise<string | null> {
  const possiblePaths = [
    path.join(process.cwd(), 'uploads', fileName),
    path.join(process.cwd(), 'input-files', fileName),
    path.resolve('./uploads', fileName),
    path.resolve('./input-files', fileName)
  ];

  for (const filePath of possiblePaths) {
    try {
      await fs.access(filePath);
      return filePath;
    } catch (error) {
      // Continue to next path
    }
  }
  return null;
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // EXISTING ROUTES (keeping all your existing functionality)
  
  // Upload CSV file
  app.post("/api/upload-csv", upload.single('csvFile'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const filePath = req.file.path;
      const originalName = req.file.originalname;
      
      const fileContent = await fs.readFile(filePath, 'utf-8');
      const lines = fileContent.trim().split('\n');
      
      if (lines.length === 0) {
        await fs.unlink(filePath);
        return res.status(400).json({ message: "CSV file is empty" });
      }
      
      const parseCSVLine = (line: string) => {
        const result = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current.trim());
        return result;
      };
      
      const headers = parseCSVLine(lines[0]);
      const previewLines = lines.slice(1, 4);
      const rows = previewLines.filter(line => line.trim()).map(line => parseCSVLine(line));

      const inputDir = './input-files';
      await ensureDirectory(inputDir);
      const savedCsvPath = path.join(inputDir, originalName);
      await fs.copyFile(filePath, savedCsvPath);
      
      console.log(`File uploaded and saved: ${originalName}`);

      res.json({
        fileName: originalName,
        fileSize: req.file.size,
        headers,
        previewRows: rows,
        success: true,
        localCsvPath: savedCsvPath,
        uploadedPath: filePath,
        message: `CSV file uploaded and saved.`
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ 
        message: "Failed to process uploaded file",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Move uploaded file to Airflow data directory
  app.post("/api/move-file-to-data", async (req, res) => {
    try {
      const { fileName, targetPath } = req.body;
      
      if (!fileName || !targetPath) {
        return res.status(400).json({ 
          success: false, 
          message: "fileName and targetPath are required" 
        });
      }
      
      console.log(`Moving file: ${fileName} to ${targetPath}`);
      
      const sourcePath = await findFile(fileName);
      
      if (!sourcePath) {
        return res.status(404).json({
          success: false,
          message: `Source file not found: ${fileName}. Checked: uploads/, input-files/`
        });
      }
      
      const { path: actualTargetPath, isLocal } = await getTargetPath(targetPath, 'data');
      const targetDir = path.dirname(actualTargetPath);
      
      await ensureDirectory(targetDir);
      await fs.copyFile(sourcePath, actualTargetPath);
      
      console.log(`File successfully moved from ${sourcePath} to: ${actualTargetPath}`);
      
      res.json({
        success: true,
        message: `File moved successfully to ${isLocal ? 'local' : 'Airflow'} data directory`,
        filePath: actualTargetPath,
        sourcePath: sourcePath,
        isLocal: isLocal,
        note: isLocal ? 
          "Could not access Windows Airflow directory, saved locally instead." : 
          "File saved to actual Airflow data directory."
      });
    } catch (error) {
      console.error('File move failed:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to move file'
      });
    }
  });

  // Test DAG script for syntax and validation
app.post("/api/test-dag", async (req, res) => {
  try {
    const { dagId, dagScript } = req.body;
    
    if (!dagId || !dagScript) {
      return res.status(400).json({ 
        success: false,
        message: "DAG ID and script are required" 
      });
    }

    console.log(`Testing DAG: ${dagId}`);
    
    // Basic syntax validation
    const syntaxErrors = [];
    
    // Check for required imports
    if (!dagScript.includes('from airflow import DAG')) {
      syntaxErrors.push('Missing required import: from airflow import DAG');
    }
    
    if (!dagScript.includes('from datetime import datetime')) {
      syntaxErrors.push('Missing required import: from datetime import datetime');
    }
    
    // Check for DAG definition
    if (!dagScript.includes('with DAG(')) {
      syntaxErrors.push('Missing DAG definition with DAG()');
    }
    
    // Check for DAG ID in script
    if (!dagScript.includes(`dag_id='${dagId}'`)) {
      syntaxErrors.push(`DAG ID '${dagId}' not found in script`);
    }
    
    // Check for task definition
    if (!dagScript.includes('@task') && !dagScript.includes('PythonOperator')) {
      syntaxErrors.push('No tasks found in DAG script');
    }
    
    // Try to save to temporary file and validate Python syntax
    const tempDir = './temp';
    await ensureDirectory(tempDir);
    const tempFilePath = path.join(tempDir, `${dagId}_test.py`);
    
    try {
      await fs.writeFile(tempFilePath, dagScript, 'utf-8');
      
      // Use Python to check syntax (if available)
      try {
        execSync(`python -m py_compile "${tempFilePath}"`, { stdio: 'pipe' });
        console.log('✅ Python syntax validation passed');
      } catch (pythonError) {
        console.log('⚠️ Python syntax check failed (this is optional)');
        // Don't add this as an error since Python might not be available
      }
      
      // Clean up temp file
      await fs.unlink(tempFilePath).catch(() => {});
    } catch (fileError) {
      console.warn('Could not create temp file for validation:', fileError);
    }
    
    const hasErrors = syntaxErrors.length > 0;
    
    res.json({
      success: !hasErrors,
      message: hasErrors ? 'DAG validation failed' : 'DAG validation passed successfully',
      errors: syntaxErrors,
      validation: {
        syntax: syntaxErrors.length === 0,
        hasRequiredImports: dagScript.includes('from airflow import DAG'),
        hasDagDefinition: dagScript.includes('with DAG('),
        hasTaskDefinition: dagScript.includes('@task') || dagScript.includes('PythonOperator'),
        dagIdMatches: dagScript.includes(`dag_id='${dagId}'`)
      }
    });
    
  } catch (error) {
    console.error('DAG test error:', error);
    res.status(500).json({ 
      success: false,
      message: "Failed to test DAG script",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});

// Add these missing endpoints to your routes.ts file
// Place them after your existing endpoints, before the return httpServer line

// Test DAG script for syntax and validation
app.post("/api/test-dag", async (req, res) => {
  try {
    const { dagId, dagScript } = req.body;
    
    if (!dagId || !dagScript) {
      return res.status(400).json({ 
        success: false,
        message: "DAG ID and script are required" 
      });
    }

    console.log(`Testing DAG: ${dagId}`);
    
    // Basic syntax validation
    const syntaxErrors = [];
    
    // Check for required imports
    if (!dagScript.includes('from airflow import DAG')) {
      syntaxErrors.push('Missing required import: from airflow import DAG');
    }
    
    if (!dagScript.includes('from datetime import datetime')) {
      syntaxErrors.push('Missing required import: from datetime import datetime');
    }
    
    // Check for DAG definition
    if (!dagScript.includes('with DAG(')) {
      syntaxErrors.push('Missing DAG definition with DAG()');
    }
    
    // Check for DAG ID in script
    if (!dagScript.includes(`dag_id='${dagId}'`)) {
      syntaxErrors.push(`DAG ID '${dagId}' not found in script`);
    }
    
    // Check for task definition
    if (!dagScript.includes('@task') && !dagScript.includes('PythonOperator')) {
      syntaxErrors.push('No tasks found in DAG script');
    }
    
    // Try to save to temporary file and validate Python syntax
    const tempDir = './temp';
    await ensureDirectory(tempDir);
    const tempFilePath = path.join(tempDir, `${dagId}_test.py`);
    
    try {
      await fs.writeFile(tempFilePath, dagScript, 'utf-8');
      
      // Use Python to check syntax (if available)
      try {
        execSync(`python -m py_compile "${tempFilePath}"`, { stdio: 'pipe' });
        console.log('✅ Python syntax validation passed');
      } catch (pythonError) {
        console.log('⚠️ Python syntax check failed (this is optional)');
        // Don't add this as an error since Python might not be available
      }
      
      // Clean up temp file
      await fs.unlink(tempFilePath).catch(() => {});
    } catch (fileError) {
      console.warn('Could not create temp file for validation:', fileError);
    }
    
    const hasErrors = syntaxErrors.length > 0;
    
    res.json({
      success: !hasErrors,
      message: hasErrors ? 'DAG validation failed' : 'DAG validation passed successfully',
      errors: syntaxErrors,
      validation: {
        syntax: syntaxErrors.length === 0,
        hasRequiredImports: dagScript.includes('from airflow import DAG'),
        hasDagDefinition: dagScript.includes('with DAG('),
        hasTaskDefinition: dagScript.includes('@task') || dagScript.includes('PythonOperator'),
        dagIdMatches: dagScript.includes(`dag_id='${dagId}'`)
      }
    });
    
  } catch (error) {
    console.error('DAG test error:', error);
    res.status(500).json({ 
      success: false,
      message: "Failed to test DAG script",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});

// Validate deployment endpoint
app.post("/api/validate-deployment", async (req, res) => {
  try {
    const { dagId, inputPath, outputPath, dagsDirectory } = req.body;
    
    if (!dagId || !inputPath || !outputPath || !dagsDirectory) {
      return res.status(400).json({ 
        success: false,
        message: "All parameters are required" 
      });
    }

    const validation = {
      syntax: true,
      dagId: true,
      filePaths: true,
      dependencies: true,
      fileLocation: true
    };

    let hasErrors = false;

    // Check if DAG ID is unique
    try {
      const existingConfig = await storage.getDagConfigurationByDagId(dagId);
      if (existingConfig) {
        validation.dagId = false;
        hasErrors = true;
      }
    } catch (error) {
      console.warn('Could not check DAG uniqueness:', error);
    }

    // Check file paths
    try {
      const inputDir = path.dirname(inputPath);
      const outputDir = path.dirname(outputPath);
      
      // Try to access directories (don't fail validation if not accessible)
      try {
        await fs.access(inputDir);
        console.log(`✅ Input directory accessible: ${inputDir}`);
      } catch {
        console.log(`⚠️ Input directory not accessible: ${inputDir}`);
      }
      
      try {
        await fs.access(outputDir);
        console.log(`✅ Output directory accessible: ${outputDir}`);
      } catch {
        console.log(`⚠️ Output directory not accessible: ${outputDir}`);
      }
    } catch (error) {
      console.log('Directory check failed:', error);
    }

    // Check if DAGs directory exists
    try {
      const { path: actualDagsDir } = await getTargetPath(dagsDirectory, 'dags');
      await fs.access(actualDagsDir);
      console.log(`✅ DAGs directory accessible: ${actualDagsDir}`);
    } catch (error) {
      console.log('DAGs directory not accessible, will use local fallback');
    }

    res.json({
      success: !hasErrors,
      message: hasErrors ? 'Validation completed with some issues' : 'All validation checks passed',
      validation
    });
    
  } catch (error) {
    console.error('Validation error:', error);
    res.status(500).json({ 
      success: false,
      message: "Failed to validate deployment",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});
  // Check DAG ID uniqueness
  app.post("/api/check-dag-id", async (req, res) => {
    try {
      const { dagId } = req.body;
      if (!dagId) {
        return res.status(400).json({ message: "DAG ID is required" });
      }

      const existingConfig = await storage.getDagConfigurationByDagId(dagId);
      if (existingConfig) {
        return res.json({ isUnique: false, message: "DAG ID already exists in database" });
      }

      const dagsDir = process.env.AIRFLOW_DAGS_DIR || "C:\\Docker\\airflow3x2\\dags";
      const { path: actualDagsDir } = await getTargetPath(dagsDir, 'dags');
      
      try {
        const dagFilePath = path.join(actualDagsDir, `${dagId}.py`);
        await fs.access(dagFilePath);
        return res.json({ isUnique: false, message: "DAG file already exists in directory" });
      } catch {
        // File doesn't exist, which is good
      }
      
      try {
        const localDagFilePath = path.join('./dags', `${dagId}.py`);
        await fs.access(localDagFilePath);
        return res.json({ isUnique: false, message: "DAG file already exists in local directory" });
      } catch {
        // File doesn't exist, which is good
      }

      res.json({ isUnique: true, message: "DAG ID is available" });
    } catch (error) {
      console.error('DAG ID check error:', error);
      res.status(500).json({ message: "Failed to check DAG ID uniqueness" });
    }
  });

  // Generate DAG script
  app.post("/api/generate-dag", async (req, res) => {
    try {
      console.log('Received DAG generation request:', req.body);
      
      const validatedData = dagConfigurationSchema.parse(req.body);
      console.log('Validated data:', validatedData);
      
      const configToSave = {
        dagId: validatedData.dagId,
        inputPath: validatedData.inputPath,
        outputPath: validatedData.outputPath,
        description: validatedData.description || null,
        scheduleInterval: validatedData.scheduleInterval || null,
        dagsDirectory: validatedData.dagsDirectory || null,
      };
      
      const config = await storage.createDagConfiguration(configToSave);
      const dagScript = generateDagScript(validatedData);

      res.json({
        config,
        dagScript,
        success: true,
        message: "DAG script generated successfully"
      });
    } catch (error) {
      console.error('DAG generation error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Validation error",
          errors: error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message,
            code: err.code
          }))
        });
      }
      
      res.status(500).json({ 
        message: "Failed to generate DAG script",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Save DAG to directory
  app.post("/api/save-dag", async (req, res) => {
    try {
      const { dagId, dagScript, dagsDirectory } = req.body;
      
      console.log('Save DAG request:', { dagId, dagsDirectory, scriptLength: dagScript?.length });
      
      if (!dagId || !dagScript) {
        return res.status(400).json({ message: "DAG ID and script are required" });
      }

      const { path: actualDagsDir, isLocal } = await getTargetPath(dagsDirectory || "C:\\Docker\\airflow3x2\\dags", 'dags');
      const dagFilePath = path.join(actualDagsDir, `${dagId}.py`);

      console.log('Attempting to save to:', dagFilePath);

      await ensureDirectory(actualDagsDir);
      console.log('Directory created/verified:', actualDagsDir);
      
      let fileExists = false;
      try {
        await fs.access(dagFilePath);
        fileExists = true;
      } catch (error) {
        // File doesn't exist, which is fine
      }
      
      await fs.writeFile(dagFilePath, dagScript, 'utf-8');
      console.log('File written successfully to:', dagFilePath);

      const stats = await fs.stat(dagFilePath);
      console.log('File stats:', { size: stats.size, created: stats.birthtime });

      const note = fileExists ? 'Existing DAG file updated.' : 'New DAG file created.';
      const locationNote = isLocal ? 
        "Could not access Windows Airflow directory, saved to local directory instead." : 
        "File saved to actual Airflow DAGs directory.";

      res.json({
        success: true,
        message: `DAG saved successfully to ${isLocal ? 'local' : 'Airflow'} directory`,
        filePath: dagFilePath,
        fileSize: stats.size,
        isLocal: isLocal,
        note: `${note} ${locationNote}`
      });
    } catch (error) {
      console.error('DAG save error:', error);
      res.status(500).json({ 
        message: "Failed to save DAG to directory",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Clear cache endpoint
  app.post("/api/cache/clear", async (req, res) => {
    try {
      const { pattern } = req.body;
      
      if (pattern) {
        cache.invalidatePattern(pattern);
        res.json({ success: true, message: `Cache cleared for pattern: ${pattern}` });
      } else {
        cache.clear();
        res.json({ success: true, message: "All cache cleared" });
      }
    } catch (error) {
      console.error('Cache clear error:', error);
      res.status(500).json({ message: "Failed to clear cache" });
    }
  });

  // Get all DAG configurations
  app.get("/api/dag-configurations", async (req, res) => {
    try {
      const configs = await storage.getAllDagConfigurations();
      res.json(configs);
    } catch (error) {
      console.error('Get configurations error:', error);
      res.status(500).json({ message: "Failed to retrieve DAG configurations" });
    }
  });

  // Test Airflow connection
  app.get("/api/test-airflow", async (req, res) => {
    try {
      const token = await authenticateAndGetToken();
      const versionInfo = await makeAuthenticatedRequest('/version', {}, 'airflow_version', 60);
      
      res.json({ 
        connected: true, 
        status: versionInfo,
        url: AIRFLOW_CONFIG.baseUrl,
        token: token ? '✓ Valid JWT Token' : '✗ Invalid Token',
        apiVersion: AIRFLOW_CONFIG.apiVersion,
        authMethod: 'JWT Bearer Token (Airflow 3.x)'
      });
    } catch (error) {
      let errorMessage = "Connection failed";
      if (error instanceof Error) {
        if (error.message.includes('ECONNREFUSED')) {
          errorMessage = "Connection refused - Airflow is not running on this port";
        } else {
          errorMessage = error.message;
        }
      }
      
      res.json({ 
        connected: false, 
        error: errorMessage,
        url: AIRFLOW_CONFIG.baseUrl
      });
    }
  });

  // Generate sample XML
  app.post("/api/generate-sample-xml", async (req, res) => {
    try {
      const { headers, sampleRows } = req.body;
      
      if (!headers || !Array.isArray(headers)) {
        return res.status(400).json({ message: "Headers are required" });
      }

      const sampleXml = generateSampleXml(headers, sampleRows || []);
      
      res.json({
        xml: sampleXml,
        success: true
      });
    } catch (error) {
      console.error('XML generation error:', error);
      res.status(500).json({ message: "Failed to generate sample XML" });
    }
  });

  // OPTIMIZED AIRFLOW 3.x API ROUTES

  // Get all DAGs from Airflow 3.x with optimized batch loading
  app.get("/api/airflow/dags", async (req, res) => {
    try {
      const cacheKey = 'all_dags_enhanced';
      
      // Check cache first
      const cached = cache.get(cacheKey);
      if (cached) {
        console.log('📦 Returning cached DAGs data');
        return res.json(cached);
      }

      console.log('🔄 Loading fresh DAGs data...');
      
      // Get basic DAG info first
      const dags = await makeAuthenticatedRequest('/dags?limit=100', {}, 'basic_dags', 30);
      
      if (!dags.dags || dags.dags.length === 0) {
        const result = { dags: [], total: 0, success: true };
        cache.set(cacheKey, result, 30);
        return res.json(result);
      }

      const dagIds = dags.dags.map((dag: any) => dag.dag_id);
      
      // Get runs for all DAGs in batches
      const runsMap = await getBatchDagRuns(dagIds, 5);
      
      // Enhance DAGs with runs data
      const enhancedDags = dags.dags.map((dag: any) => ({
        ...dag,
        recent_runs: runsMap[dag.dag_id] || [],
        run_count: (runsMap[dag.dag_id] || []).length
      }));
      
      const result = {
        dags: enhancedDags,
        total: dags.total_entries || enhancedDags.length,
        success: true
      };
      
      // Cache the enhanced result
      cache.set(cacheKey, result, 30); // 30 second cache
      
      res.json(result);
    } catch (error) {
      console.error('Failed to fetch DAGs from Airflow:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch DAGs from Airflow'
      });
    }
  });

  // Get specific DAG details with caching
app.get("/api/airflow/dags/:dagId", async (req, res) => {
  try {
    const { dagId } = req.params;
    const cacheKey = `dag_details_${dagId}`;
    
    // Check cache first
    const cached = cache.get(cacheKey);
    if (cached) {
      console.log(`📦 Returning cached DAG details for ${dagId}`);
      return res.json(cached);
    }
    
    console.log(`🔄 Fetching DAG details for: ${dagId}`);
    
    const [dag, runs, tasks] = await Promise.allSettled([
      makeAuthenticatedRequest(`/dags/${dagId}`, {}, `dag_${dagId}`, 60),
      fetchDagRunsCompatible(dagId, 10), // Use the compatible function
      makeAuthenticatedRequest(`/dags/${dagId}/tasks`, {}, `dag_tasks_${dagId}`, 300)
    ]);
    
    const result = {
      dag: dag.status === 'fulfilled' ? dag.value : null,
      runs: runs.status === 'fulfilled' ? (runs.value?.dag_runs || []) : [],
      tasks: tasks.status === 'fulfilled' ? (tasks.value?.tasks || []) : [],
      success: true
    };
    
    cache.set(cacheKey, result, 60); // 1 minute cache
    
    res.json(result);
  } catch (error) {
    console.error(`Failed to fetch DAG ${req.params.dagId}:`, error);
    res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Failed to fetch DAG details'
    });
  }
});
  // Trigger a DAG run (Airflow 3.x format) with cache invalidation
  app.post("/api/airflow/dags/:dagId/trigger", async (req, res) => {
    try {
      const { dagId } = req.params;
      const { conf = {} } = req.body;
      
      console.log(`Triggering DAG: ${dagId}`);
      
      const triggerData = {
        conf: conf,
        dag_run_id: `manual_${Date.now()}`,
        logical_date: new Date().toISOString()
      };
      
      const result = await makeAuthenticatedRequest(`/dags/${dagId}/dagRuns`, {
        method: 'POST',
        body: JSON.stringify(triggerData)
      });
      
      // Invalidate related caches
      cache.invalidatePattern(dagId);
      cache.invalidatePattern('all_dags');
      
      res.json({
        success: true,
        message: `DAG ${dagId} triggered successfully`,
        dag_run: result
      });
    } catch (error) {
      console.error(`Failed to trigger DAG ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to trigger DAG'
      });
    }
  });

  // Pause/Unpause DAG with cache invalidation
  app.patch("/api/airflow/dags/:dagId", async (req, res) => {
    try {
      const { dagId } = req.params;
      const { is_paused } = req.body;
      
      console.log(`${is_paused ? 'Pausing' : 'Unpausing'} DAG: ${dagId}`);
      
      const result = await makeAuthenticatedRequest(`/dags/${dagId}`, {
        method: 'PATCH',
        body: JSON.stringify({ is_paused })
      });
      
      // Invalidate related caches
      cache.invalidatePattern(dagId);
      cache.invalidatePattern('all_dags');
      
      res.json({
        success: true,
        message: `DAG ${dagId} ${is_paused ? 'paused' : 'unpaused'} successfully`,
        dag: result
      });
    } catch (error) {
      console.error(`Failed to update DAG ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to update DAG'
      });
    }
  });

  // Get DAG runs for a specific DAG with caching
app.get("/api/airflow/dags/:dagId/runs", async (req, res) => {
  try {
    const { dagId } = req.params;
    const { limit = 20, offset = 0 } = req.query;
    const cacheKey = `dag_runs_${dagId}_${limit}_${offset}`;
    
    console.log(`🔄 Fetching DAG runs for: ${dagId}`);
    
    const runs = await fetchDagRunsCompatible(dagId, Number(limit), Number(offset));
    
    // Cache the result
    cache.set(cacheKey, runs, 30);
    
    res.json({
      runs: runs.dag_runs || [],
      total: runs.total_entries || 0,
      success: true
    });
  } catch (error) {
    console.error(`Failed to fetch runs for DAG ${req.params.dagId}:`, error);
    res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Failed to fetch DAG runs'
    });
  }
});
  // Get task instances for a DAG run
  app.get("/api/airflow/dags/:dagId/runs/:runId/tasks", async (req, res) => {
    try {
      const { dagId, runId } = req.params;
      const cacheKey = `task_instances_${dagId}_${runId}`;
      
      const taskInstances = await makeAuthenticatedRequest(
        `/dags/${dagId}/dagRuns/${runId}/taskInstances`,
        {},
        cacheKey,
        60 // 1 minute cache for task instances
      );
      
      res.json({
        task_instances: taskInstances.task_instances || [],
        success: true
      });
    } catch (error) {
      console.error(`Failed to fetch task instances for ${req.params.dagId}/${req.params.runId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch task instances'
      });
    }
  });

  // Get Airflow system information
  app.get("/api/airflow/info", async (req, res) => {
    try {
      const version = await makeAuthenticatedRequest('/version', {}, 'airflow_info', 300); // 5 minute cache
      
      res.json({
        version,
        config: {
          airflow_version: version.version || 'unknown',
          executor: 'unknown',
          api_version: AIRFLOW_CONFIG.apiVersion
        },
        success: true
      });
    } catch (error) {
      console.error('Failed to fetch Airflow info:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch Airflow info'
      });
    }
  });

  // Delete a DAG run with cache invalidation
  app.delete("/api/airflow/dags/:dagId/runs/:runId", async (req, res) => {
    try {
      const { dagId, runId } = req.params;
      
      await makeAuthenticatedRequest(`/dags/${dagId}/dagRuns/${runId}`, {
        method: 'DELETE'
      });
      
      // Invalidate related caches
      cache.invalidatePattern(dagId);
      cache.invalidatePattern('all_dags');
      
      res.json({
        success: true,
        message: `DAG run ${runId} deleted successfully`
      });
    } catch (error) {
      console.error(`Failed to delete DAG run ${req.params.runId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to delete DAG run'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function generateDagScript(config: DagConfigurationInput): string {
  const inputPath = config.inputPath;
  const outputPath = config.outputPath;
  
  const template = `from airflow import DAG
from airflow.decorators import task
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime
import csv, os, glob
import xml.etree.ElementTree as ET

input_directory = r'${path.dirname(inputPath)}'
output_directory = r'${path.dirname(outputPath)}'

default_args = {
    "owner": "airflow",
    "retries": 1,
}

with DAG(
    dag_id='${config.dagId}',
    default_args=default_args,
    description='${config.description || 'Convert CSV to XML format'}',
    schedule=${config.scheduleInterval === 'None' ? 'None' : `'${config.scheduleInterval}'`},
    start_date=datetime(2024, 1, 1),
    catchup=False,
) as dag:
    
    @task
    def convert_csv_to_xml():
        # Find all CSV files in the input directory
        csv_files = glob.glob(os.path.join(input_directory, '*.csv'))
        
        if not csv_files:
            print(f"⚠️  No CSV files found in {input_directory}")
            return
            
        # Ensure output directory exists
        os.makedirs(output_directory, exist_ok=True)
        
        for csv_path in csv_files:
            print(f"📄 Processing: {csv_path}")
            
            # Extract filename without extension for customer name
            filename = os.path.basename(csv_path)
            customer_name = os.path.splitext(filename)[0]
            
            # Create XML structure
            with open(csv_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                tickets = ET.Element('TICKETS')
                customer = ET.SubElement(tickets, customer_name)

                for row in reader:
                    row_elem = ET.SubElement(customer, 'ROW')
                    for key, val in row.items():
                        col = ET.SubElement(row_elem, key.replace(' ', '_'))
                        col.text = str(val) if val else ''

            # Save XML file with same base name as CSV
            xml_filename = f"{customer_name}.xml"
            output_path = os.path.join(output_directory, xml_filename)
            
            ET.ElementTree(tickets).write(output_path, encoding='utf-8', xml_declaration=True)
            print(f'✅ XML saved to: {output_path}')
        
        print(f"🎉 Processed {len(csv_files)} CSV file(s)")

    convert_csv_to_xml()`;

  return template;
}

function generateSampleXml(headers: string[], sampleRows: string[][]): string {
  const customerName = "SampleCorp";
  
  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<TICKETS>
    <${customerName}>`;

  sampleRows.forEach((row, index) => {
    xml += `
        <ROW>`;
    headers.forEach((header, headerIndex) => {
      const value = row[headerIndex] || '';
      xml += `
            <${header}>${value}</${header}>`;
    });
    xml += `
        </ROW>`;
  });

  xml += `
    </${customerName}>
</TICKETS>`;

  return xml;
}