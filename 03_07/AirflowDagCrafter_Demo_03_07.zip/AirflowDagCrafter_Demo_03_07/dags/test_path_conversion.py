# Test DAG for path conversion
from airflow import DAG
from datetime import datetime

with DAG(dag_id="test_path_conversion", start_date=datetime(2024, 1, 1)) as dag:
    pass
