from airflow import DAG
from airflow.decorators import task
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime
import csv, os, glob
import xml.etree.ElementTree as ET

input_directory = r'C:\Docker\airflow3x2\data'
output_directory = r'C:\Docker\airflow3x2\data'

default_args = {
    "owner": "airflow",
    "retries": 1,
}

with DAG(
    dag_id='directory_based_workflow',
    default_args=default_args,
    description='Directory-based CSV to XML processing',
    schedule=None,
    start_date=datetime(2024, 1, 1),
    catchup=False,
) as dag:
    
    @task
    def convert_csv_to_xml():
        # Find all CSV files in the input directory
        csv_files = glob.glob(os.path.join(input_directory, '*.csv'))
        
        if not csv_files:
            print(f"⚠️  No CSV files found in {input_directory}")
            return
            
        # Ensure output directory exists
        os.makedirs(output_directory, exist_ok=True)
        
        for csv_path in csv_files:
            print(f"📄 Processing: {csv_path}")
            
            # Extract filename without extension for customer name
            filename = os.path.basename(csv_path)
            customer_name = os.path.splitext(filename)[0]
            
            # Create XML structure
            with open(csv_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                tickets = ET.Element('TICKETS')
                customer = ET.SubElement(tickets, customer_name)

                for row in reader:
                    row_elem = ET.SubElement(customer, 'ROW')
                    for key, val in row.items():
                        col = ET.SubElement(row_elem, key.replace(' ', '_'))
                        col.text = str(val) if val else ''

            # Save XML file with same base name as CSV
            xml_filename = f"{customer_name}.xml"
            output_path = os.path.join(output_directory, xml_filename)
            
            ET.ElementTree(tickets).write(output_path, encoding='utf-8', xml_declaration=True)
            print(f'✅ XML saved to: {output_path}')
        
        print(f"🎉 Processed {len(csv_files)} CSV file(s)")

    convert_csv_to_xml()