import { useState, useEffect } from "react";
import { Sidebar } from "@/components/sidebar";
import { FileUpload } from "@/components/file-upload";
import { DagConfiguration } from "@/components/dag-configuration";
import { ScriptGenerator } from "@/components/script-generator";
import { XmlViewer } from "@/components/xml-viewer";
import { SetupInstructions } from "@/components/setup-instructions";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Menu, Server, HelpCircle } from "lucide-react";
import { useAirflow } from "@/hooks/use-airflow";
import { ThemeSelector } from "@/components/theme-selector";

export type Step = 'upload' | 'configure' | 'generate' | 'xml-viewer';

export interface UploadedFile {
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
}

export interface DagConfig {
  inputPath: string;
  outputPath: string;
  dagId: string;
  description: string;
  scheduleInterval: string;
  dagsDirectory: string;
}

export default function DagGenerator() {
  const [currentStep, setCurrentStep] = useState<Step>('upload');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [dagConfig, setDagConfig] = useState<DagConfig>({
    inputPath: 'C:\\Docker\\airflow3x2\\data\\AcmeCorp_tabledata.csv',
    outputPath: 'C:\\Docker\\airflow3x2\\data\\AcmeCorp_tabledata.xml',
    dagId: 'csv_to_xml_acme_corp',
    description: 'Convert AcmeCorp CSV data to XML format for downstream processing',
    scheduleInterval: 'None',
    dagsDirectory: 'C:\\Docker\\airflow3x2\\dags'
  });
  const [generatedScript, setGeneratedScript] = useState<string>('');

  const { connectionStatus, testConnection } = useAirflow();

  useEffect(() => {
    // Test Airflow connection on component mount
    testConnection();
  }, [testConnection]);

  // Update file paths when a file is uploaded
  useEffect(() => {
    if (uploadedFile) {
      const fileName = uploadedFile.fileName.replace('.csv', '');
      setDagConfig(prev => ({
        ...prev,
        inputPath: `C:\\Docker\\airflow3x2\\data\\${uploadedFile.fileName}`,
        outputPath: `C:\\Docker\\airflow3x2\\data\\${fileName}.xml`,
        dagId: fileName.toLowerCase().replace(/[^a-z0-9]/g, '_')
      }));
    }
  }, [uploadedFile]);

  const getStepTitle = (step: Step): string => {
    const titles = {
      'upload': 'Upload CSV File',
      'configure': 'Configure DAG Parameters',
      'generate': 'Airflow DAG Generator',
      'xml-viewer': 'XML Viewer & Configuration'
    };
    return titles[step];
  };

  const getStepDescription = (step: Step): string => {
    const descriptions = {
      'upload': 'Start by uploading your CSV file to convert to XML',
      'configure': 'Set up your DAG configuration and file paths',
      'generate': 'Review and deploy your generated DAG script',
      'xml-viewer': 'Preview XML output and configure settings'
    };
    return descriptions[step];
  };

  const handleNextStep = () => {
    const steps: Step[] = ['upload', 'configure', 'generate', 'xml-viewer'];
    const currentIndex = steps.indexOf(currentStep);
    if (currentIndex < steps.length - 1) {
      setCurrentStep(steps[currentIndex + 1]);
    }
  };

  const handlePrevStep = () => {
    const steps: Step[] = ['upload', 'configure', 'generate', 'xml-viewer'];
    const currentIndex = steps.indexOf(currentStep);
    if (currentIndex > 0) {
      setCurrentStep(steps[currentIndex - 1]);
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <Sidebar
        currentStep={currentStep}
        onStepChange={setCurrentStep}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        connectionStatus={connectionStatus}
      />

      {/* Main Content */}
      <div className="flex-1 lg:ml-0">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between h-16 px-6">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden mr-4"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div>
                <h2 className="text-xl font-semibold text-slate-800">
                  {getStepTitle(currentStep)}
                </h2>
                <p className="text-sm text-gray-600">
                  {getStepDescription(currentStep)}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center text-sm text-gray-600">
                <Server className="mr-2 h-4 w-4" />
                <span>Apache Airflow</span>
              </div>
              <ThemeSelector />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <HelpCircle className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Setup Instructions & File Workflow</DialogTitle>
                  </DialogHeader>
                  <SetupInstructions />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="p-6">
          <div className="relative">
            {currentStep === 'upload' && (
              <FileUpload
                onFileUploaded={setUploadedFile}
                onNext={handleNextStep}
                uploadedFile={uploadedFile}
              />
            )}
            
            {currentStep === 'configure' && (
              <DagConfiguration
                config={dagConfig}
                onConfigChange={setDagConfig}
                onNext={handleNextStep}
                onPrev={handlePrevStep}
                onGenerate={(script) => {
                  setGeneratedScript(script);
                  setCurrentStep('generate');
                }}
                uploadedFile={uploadedFile}
              />
            )}
            
            {currentStep === 'generate' && (
              <ScriptGenerator
                config={dagConfig}
                generatedScript={generatedScript}
                onNext={handleNextStep}
                onPrev={handlePrevStep}
                uploadedFile={uploadedFile}
              />
            )}
            
            {currentStep === 'xml-viewer' && (
              <XmlViewer
                uploadedFile={uploadedFile}
                config={dagConfig}
                onPrev={handlePrevStep}
                onStartOver={() => setCurrentStep('upload')}
              />
            )}
          </div>
        </main>
      </div>

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}