import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, ArrowRight, Code, CheckCircle, XCircle, FolderOpen, GitBranch, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AirflowStatus } from "@/components/airflow-status";
import { DagConfig, UploadedFile } from "@/pages/dag-generator";

interface DagConfigurationProps {
  config: DagConfig;
  onConfigChange: (config: DagConfig) => void;
  onNext: () => void;
  onPrev: () => void;
  onGenerate: (script: string) => void;
  uploadedFile: UploadedFile | null;
}

export function DagConfiguration({ 
  config, 
  onConfigChange, 
  onNext, 
  onPrev, 
  onGenerate,
  uploadedFile
}: DagConfigurationProps) {
  const [dagIdStatus, setDagIdStatus] = useState<'checking' | 'available' | 'taken'>('available');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isMovingFiles, setIsMovingFiles] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (config.dagId) {
        checkDagIdUniqueness(config.dagId);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [config.dagId]);

  const checkDagIdUniqueness = async (dagId: string) => {
    if (!dagId) return;
    
    setDagIdStatus('checking');
    try {
      const response = await apiRequest('POST', '/api/check-dag-id', { dagId });
      const result = await response.json();
      setDagIdStatus(result.isUnique ? 'available' : 'taken');
    } catch (error) {
      console.error('DAG ID check failed:', error);
      setDagIdStatus('available'); // Default to available on error
    }
  };

  const handleInputChange = (field: keyof DagConfig, value: string) => {
    onConfigChange({ ...config, [field]: value });
  };

  // Move uploaded CSV file to Airflow data directory
  const moveUploadedFileToDataDirectory = async () => {
    if (!uploadedFile) return true;
    
    try {
      const response = await apiRequest('POST', '/api/move-file-to-data', {
        fileName: uploadedFile.fileName,
        targetPath: config.inputPath
      });
      
      const result = await response.json();
      if (!result.success) {
        throw new Error(result.message || 'Failed to move file to data directory');
      }
      return true;
    } catch (error) {
      console.error('File move failed:', error);
      toast({
        title: "File move failed",
        description: "Failed to move uploaded file to Airflow data directory",
        variant: "destructive",
      });
      return false;
    }
  };

  const handleGenerateScript = async () => {
    if (dagIdStatus === 'taken') {
      toast({
        title: "DAG ID not available",
        description: "Please choose a different DAG ID",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setIsMovingFiles(true);

    try {
      // Step 1: Move uploaded file to data directory
      const fileMoved = await moveUploadedFileToDataDirectory();
      if (!fileMoved) {
        setIsGenerating(false);
        setIsMovingFiles(false);
        return;
      }

      setIsMovingFiles(false);

      // Step 2: Generate DAG script
      const dagData = {
        dagId: config.dagId,
        inputPath: config.inputPath,
        outputPath: config.outputPath,
        description: config.description || undefined,
        scheduleInterval: config.scheduleInterval || undefined,
        dagsDirectory: config.dagsDirectory || undefined,
      };
      
      console.log('Sending DAG data:', dagData);
      
      const response = await apiRequest('POST', '/api/generate-dag', dagData);
      const result = await response.json();
      
      if (result.success) {
        // Step 3: Auto-save DAG script to dags directory
        const saveResponse = await apiRequest('POST', '/api/save-dag', {
          dagId: config.dagId,
          dagScript: result.dagScript,
          dagsDirectory: config.dagsDirectory
        });
        
        const saveResult = await saveResponse.json();
        if (saveResult.success) {
          toast({
            title: "DAG script generated and saved",
            description: `DAG script generated and automatically saved to: ${saveResult.filePath}`,
          });
        } else {
          toast({
            title: "DAG script generated",
            description: "DAG script generated successfully but auto-save to dags directory failed",
            variant: "destructive",
          });
        }

        onGenerate(result.dagScript);
      } else {
        throw new Error(result.message || 'Generation failed');
      }
    } catch (error) {
      console.error('DAG generation failed:', error);
      let errorMessage = "Failed to generate DAG script";
      
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: "Generation failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
      setIsMovingFiles(false);
    }
  };

  const getDagIdStatusIcon = () => {
    switch (dagIdStatus) {
      case 'checking':
        return <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />;
      case 'available':
        return <CheckCircle className="w-4 h-4 text-accent" />;
      case 'taken':
        return <XCircle className="w-4 h-4 text-destructive" />;
    }
  };

  const getDagIdStatusMessage = () => {
    switch (dagIdStatus) {
      case 'checking':
        return 'Checking availability...';
      case 'available':
        return '✓ DAG ID is available';
      case 'taken':
        return '✗ DAG ID already exists';
    }
  };

  return (
    <div className="max-w-4xl">
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Configuration Form */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800">DAG Configuration</CardTitle>
            {uploadedFile && (
              <div className="text-sm text-green-600 flex items-center">
                <Upload className="mr-1 h-4 w-4" />
                File uploaded: {uploadedFile.fileName}
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="inputPath">
                Input CSV Path <span className="text-red-500">*</span>
              </Label>
              <Input
                id="inputPath"
                value={config.inputPath}
                onChange={(e) => handleInputChange('inputPath', e.target.value)}
                placeholder="C:\Docker\airflow3x2\data\input.csv"
              />
              <p className="text-xs text-gray-500">Full path to your CSV file in Airflow data directory</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="outputPath">
                Output XML Path <span className="text-red-500">*</span>
              </Label>
              <Input
                id="outputPath"
                value={config.outputPath}
                onChange={(e) => handleInputChange('outputPath', e.target.value)}
                placeholder="C:\Docker\airflow3x2\data\output.xml"
              />
              <p className="text-xs text-gray-500">Destination path for generated XML file in data directory</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dagId">
                DAG ID <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="dagId"
                  value={config.dagId}
                  onChange={(e) => handleInputChange('dagId', e.target.value)}
                  placeholder="my_csv_to_xml_dag"
                  className="pr-10"
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  {getDagIdStatusIcon()}
                </div>
              </div>
              <p className="text-xs text-gray-500">
                Unique identifier for your DAG (letters, numbers, underscores only)
              </p>
              <div className={`text-xs ${
                dagIdStatus === 'available' ? 'text-accent' : 
                dagIdStatus === 'taken' ? 'text-destructive' : 'text-gray-500'
              }`}>
                {getDagIdStatusMessage()}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">DAG Description</Label>
              <Textarea
                id="description"
                value={config.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Describe your DAG's purpose..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="scheduleInterval">Schedule Interval</Label>
              <Select 
                value={config.scheduleInterval} 
                onValueChange={(value) => handleInputChange('scheduleInterval', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="None">Manual Trigger Only</SelectItem>
                  <SelectItem value="@daily">Daily</SelectItem>
                  <SelectItem value="@weekly">Weekly</SelectItem>
                  <SelectItem value="@monthly">Monthly</SelectItem>
                  <SelectItem value="@hourly">Hourly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="border border-gray-200 rounded-lg p-4 space-y-3">
              <h4 className="font-medium text-gray-800 flex items-center">
                <FolderOpen className="mr-2 h-4 w-4" />
                Airflow DAGs Directory
              </h4>
              <div className="flex items-center space-x-3">
                <Input
                  value={config.dagsDirectory}
                  onChange={(e) => handleInputChange('dagsDirectory', e.target.value)}
                  className="flex-1 text-sm"
                  placeholder="C:\Docker\airflow3x2\dags"
                />
                <Button variant="outline" size="sm">
                  <FolderOpen className="mr-1 h-4 w-4" />
                  Browse
                </Button>
              </div>
              <p className="text-xs text-gray-500">
                Path to your Airflow DAGs directory for automatic deployment
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Real-time Preview */}
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800">DAG Preview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-700">DAG ID:</span>
              <code className="text-sm text-primary font-mono">{config.dagId}</code>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-700">Schedule:</span>
              <span className="text-sm text-gray-600">
                {config.scheduleInterval === 'None' ? 'Manual' : config.scheduleInterval}
              </span>
            </div>
            
            <div className="p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-700 block mb-2">File Paths:</span>
              <div className="text-xs font-mono text-gray-600 space-y-1 break-all">
                <div>Input: {config.inputPath}</div>
                <div>Output: {config.outputPath}</div>
              </div>
            </div>

            <div className="p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-700 block mb-2">Directory Paths:</span>
              <div className="text-xs font-mono text-gray-600 space-y-1 break-all">
                <div>DAGs: {config.dagsDirectory}</div>
                <div>Data: C:\Docker\airflow3x2\data</div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <h4 className="text-sm font-medium text-gray-800 mb-3 flex items-center">
                <GitBranch className="mr-2 h-4 w-4" />
                DAG Structure
              </h4>
              <div className="text-sm text-gray-600 space-y-2">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-primary rounded mr-2"></div>
                  <span>convert_csv_to_xml</span>
                </div>
                <div className="ml-5 text-xs text-gray-500">
                  Converts CSV to XML format with customer grouping
                </div>
              </div>
            </div>

            {isMovingFiles && (
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-sm text-blue-700 font-medium mb-1">Preparing Files...</div>
                <div className="text-xs text-blue-600">Moving uploaded file to data directory</div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Upload
        </Button>
        <Button 
          onClick={handleGenerateScript}
          disabled={!config.dagId || !config.inputPath || !config.outputPath || dagIdStatus === 'taken' || isGenerating}
        >
          {isGenerating ? (isMovingFiles ? 'Moving Files...' : 'Generating...') : 'Generate & Deploy DAG'}
          <Code className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}