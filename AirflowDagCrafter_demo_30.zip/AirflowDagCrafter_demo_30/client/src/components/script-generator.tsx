import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, ArrowRight, Copy, Download, FolderPlus, CheckCircle, Rocket, Play, FileText, Database } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { DagConfig, UploadedFile } from "@/pages/dag-generator";

interface ScriptGeneratorProps {
  config: DagConfig;
  generatedScript: string;
  onNext: () => void;
  onPrev: () => void;
  uploadedFile: UploadedFile | null;
}

export function ScriptGenerator({ config, generatedScript, onNext, onPrev, uploadedFile }: ScriptGeneratorProps) {
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationStatus, setValidationStatus] = useState({
    syntax: true,
    dagId: true,
    filePaths: true,
    dependencies: true,
    fileLocation: true
  });
  const { toast } = useToast();

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generatedScript);
      toast({
        title: "Code copied",
        description: "DAG script has been copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Failed to copy code to clipboard",
        variant: "destructive",
      });
    }
  };

  const downloadScript = () => {
    const blob = new Blob([generatedScript], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${config.dagId}.py`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download started",
      description: `${config.dagId}.py has been downloaded`,
    });
  };

  const validateDeployment = async () => {
    setIsValidating(true);
    try {
      const response = await apiRequest('POST', '/api/validate-deployment', {
        dagId: config.dagId,
        inputPath: config.inputPath,
        outputPath: config.outputPath,
        dagsDirectory: config.dagsDirectory
      });
      
      const result = await response.json();
      setValidationStatus(result.validation || validationStatus);
      
      if (result.success) {
        toast({
          title: "Validation completed",
          description: "All deployment checks passed successfully",
        });
      } else {
        toast({
          title: "Validation issues found",
          description: result.message || "Some validation checks failed",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Validation failed:', error);
      toast({
        title: "Validation failed",
        description: "Failed to validate deployment",
        variant: "destructive",
      });
    } finally {
      setIsValidating(false);
    }
  };

  const saveToDagsDirectory = async () => {
    setIsSaving(true);
    try {
      const response = await apiRequest('POST', '/api/save-dag', {
        dagId: config.dagId,
        dagScript: generatedScript,
        dagsDirectory: config.dagsDirectory
      });
      
      const result = await response.json();
      if (result.success) {
        toast({
          title: "DAG saved successfully",
          description: result.note ? 
            `${result.note} File saved to: ${result.filePath}` : 
            `Saved to ${result.filePath}`,
        });
      }
    } catch (error) {
      console.error('Save failed:', error);
      toast({
        title: "Save failed",
        description: "Failed to save DAG to directory",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const testDag = async () => {
    setIsTesting(true);
    try {
      const response = await apiRequest('POST', '/api/test-dag', {
        dagId: config.dagId,
        dagScript: generatedScript
      });
      
      const result = await response.json();
      if (result.success) {
        toast({
          title: "DAG test completed",
          description: "DAG syntax and structure validation passed",
        });
      } else {
        toast({
          title: "DAG test failed",
          description: result.message || "DAG validation failed",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Test failed:', error);
      toast({
        title: "Test failed",
        description: "Failed to test DAG",
        variant: "destructive",
      });
    } finally {
      setIsTesting(false);
    }
  };

  const deployToAirflow = async () => {
    setIsDeploying(true);
    try {
      const response = await apiRequest('POST', '/api/deploy-dag', {
        dagId: config.dagId,
        dagScript: generatedScript,
        dagsDirectory: config.dagsDirectory
      });
      
      const result = await response.json();
      if (result.success) {
        toast({
          title: "Deployment successful",
          description: `DAG ${config.dagId} has been deployed to Airflow`,
        });
      } else {
        toast({
          title: "Deployment failed",
          description: result.message || "Failed to deploy DAG",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Deployment failed:', error);
      toast({
        title: "Deployment failed",
        description: "Failed to deploy DAG to Airflow",
        variant: "destructive",
      });
    } finally {
      setIsDeploying(false);
    }
  };

  const validationResults = [
    { label: "Syntax validation passed", icon: CheckCircle, status: validationStatus.syntax ? "success" : "error" },
    { label: "DAG ID is unique", icon: CheckCircle, status: validationStatus.dagId ? "success" : "error" },
    { label: "File paths validated", icon: CheckCircle, status: validationStatus.filePaths ? "success" : "error" },
    { label: "Dependencies available", icon: CheckCircle, status: validationStatus.dependencies ? "success" : "error" },
    { label: "Files in data directory", icon: CheckCircle, status: validationStatus.fileLocation ? "success" : "error" }
  ];

  return (
    <div className="max-w-6xl">
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Generated Code */}
        <div className="lg:col-span-2">
          <Card className="shadow-sm border border-gray-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="text-lg font-semibold text-slate-800">
                Generated DAG Script
              </CardTitle>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  <Copy className="mr-1 h-4 w-4" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadScript}>
                  <Download className="mr-1 h-4 w-4" />
                  Download
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <pre className="text-sm bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto max-h-96 custom-scrollbar">
                  <code className="language-python">{generatedScript}</code>
                </pre>
              </div>
              
              {/* File Status */}
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <h4 className="text-sm font-medium text-gray-800 mb-2">File Status</h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div className="flex items-center">
                    <Database className="mr-2 h-4 w-4 text-green-600" />
                    <div>
                      <div className="font-medium">CSV Input</div>
                      <div className="text-gray-600 break-all">{config.inputPath}</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <FileText className="mr-2 h-4 w-4 text-blue-600" />
                    <div>
                      <div className="font-medium">XML Output</div>
                      <div className="text-gray-600 break-all">{config.outputPath}</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions Panel */}
        <div className="space-y-6">
          {/* Save Options */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Deployment Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-green-600 bg-green-50 p-3 rounded-lg border border-green-200">
                <div className="font-medium mb-1">✓ Auto-deployed to DAGs directory</div>
                <div className="text-xs text-green-700">
                  Script automatically saved to: {config.dagsDirectory}
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={downloadScript}
              >
                <div className="text-left">
                  <div className="font-medium">Download Copy</div>
                  <div className="text-xs text-muted-foreground">Save backup to local machine</div>
                </div>
                <Download className="h-4 w-4" />
              </Button>

              <Button 
                variant="outline" 
                className="w-full justify-between"
                onClick={validateDeployment}
                disabled={isValidating}
              >
                <div className="text-left">
                  <div className="font-medium">
                    {isValidating ? 'Validating...' : 'Re-validate Deployment'}
                  </div>
                  <div className="text-xs text-muted-foreground">Check file locations & paths</div>
                </div>
                <CheckCircle className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          {/* Validation Results */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Validation Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {validationResults.map((result, index) => (
                <div key={index} className="flex items-center text-sm">
                  <result.icon className={`mr-3 h-4 w-4 ${
                    result.status === 'success' ? 'text-accent' : 'text-destructive'
                  }`} />
                  <span className="text-gray-700">{result.label}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* File Locations */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">File Locations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-xs space-y-2">
                <div>
                  <div className="font-medium text-gray-700">DAG Script:</div>
                  <div className="text-gray-600 break-all font-mono">
                    {config.dagsDirectory}\{config.dagId}.py
                  </div>
                </div>
                <div>
                  <div className="font-medium text-gray-700">Data Files:</div>
                  <div className="text-gray-600 break-all font-mono">
                    C:\Docker\airflow3x2\data\
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Airflow Integration */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Airflow Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-700">Connection Status</span>
                <div className="flex items-center text-accent">
                  <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                  Connected
                </div>
              </div>
              
              <Button 
                className="w-full bg-accent hover:bg-accent/90"
                onClick={deployToAirflow}
                disabled={isDeploying}
              >
                <Rocket className="mr-2 h-4 w-4" />
                {isDeploying ? 'Deploying...' : 'Re-deploy to Airflow'}
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full"
                onClick={testDag}
                disabled={isTesting}
              >
                <Play className="mr-2 h-4 w-4" />
                {isTesting ? 'Testing...' : 'Test DAG'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Configuration
        </Button>
        <Button onClick={onNext}>
          View XML Output
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}