import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, 
  Upload, 
  Code, 
  FileCode, 
  X, 
  CheckCircle,
  XCircle 
} from "lucide-react";
import { Step } from "@/pages/dag-generator";

interface SidebarProps {
  currentStep: Step;
  onStepChange: (step: Step) => void;
  isOpen: boolean;
  onClose: () => void;
  connectionStatus: {
    connected: boolean;
    url: string;
  };
}

export function Sidebar({ 
  currentStep, 
  onStepChange, 
  isOpen, 
  onClose, 
  connectionStatus 
}: SidebarProps) {
  const steps = [
    { key: 'upload' as const, icon: Upload, label: 'Upload CSV' },
    { key: 'configure' as const, icon: Settings, label: 'Configure DAG' },
    { key: 'generate' as const, icon: Code, label: 'Generate Script' },
    { key: 'xml-viewer' as const, icon: FileCode, label: 'XML Viewer' }
  ];

  return (
    <div className={`
      fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out
      lg:translate-x-0 lg:static lg:inset-0
      ${isOpen ? 'translate-x-0' : '-translate-x-full'}
    `}>
      <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Settings className="text-white text-sm h-4 w-4" />
          </div>
          <h1 className="text-lg font-semibold text-slate-800">Apache Airflow DAG Generator</h1>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="lg:hidden"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      <nav className="mt-6 px-4">
        <div className="space-y-2">
          {steps.map(({ key, icon: Icon, label }) => (
            <button
              key={key}
              onClick={() => onStepChange(key)}
              className={`
                nav-item w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors text-left
                ${currentStep === key 
                  ? 'active bg-blue-50 text-primary border-l-4 border-primary pl-3' 
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }
              `}
            >
              <Icon className="mr-3 h-4 w-4" />
              <span>{label}</span>
              {currentStep === key && (
                <span className="ml-auto w-2 h-2 bg-primary rounded-full"></span>
              )}
            </button>
          ))}
        </div>
        
        <Separator className="my-6" />
        

      </nav>
    </div>
  );
}
