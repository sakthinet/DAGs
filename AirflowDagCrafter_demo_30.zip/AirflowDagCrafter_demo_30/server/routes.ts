import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { dagConfigurationSchema, type DagConfigurationInput } from "@shared/schema";
import { z } from "zod";
import fs from "fs/promises";
import path from "path";
import multer from "multer";
import { execSync } from "child_process";

// Configure multer for file uploads
const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv') || file.mimetype === 'application/vnd.ms-excel') {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  }
});

// Helper function to try Windows path first, fallback to local if needed
async function getTargetPath(targetPath: string, fallbackType: 'dags' | 'data' = 'dags'): Promise<{ path: string, isLocal: boolean }> {
  // If it's a Windows path, try to use it directly first
  if (targetPath.includes(':\\')) {
    try {
      // Check if the directory exists or can be created
      const targetDir = path.dirname(targetPath);
      await fs.mkdir(targetDir, { recursive: true });
      
      // Test write permissions
      const testFile = path.join(targetDir, '.write-test');
      await fs.writeFile(testFile, 'test');
      await fs.unlink(testFile);
      
      console.log(`✓ Using actual Windows path: ${targetPath}`);
      return { path: targetPath, isLocal: false };
    } catch (error) {
      console.log(`⚠️ Cannot access Windows path ${targetPath}, falling back to local: ${error}`);
    }
  }
  
  // Fallback to local development path
  const pathParts = targetPath.split(/[\\\/]/);
  const lastPart = pathParts[pathParts.length - 1];
  const localPath = `./${lastPart}`;
  
  console.log(`Using local fallback path: ${localPath}`);
  return { path: localPath, isLocal: true };
}

// Helper function to ensure directory exists
async function ensureDirectory(dirPath: string): Promise<void> {
  try {
    await fs.mkdir(dirPath, { recursive: true });
  } catch (error) {
    console.error(`Failed to create directory ${dirPath}:`, error);
    throw error;
  }
}

// Helper function to find file in multiple locations
async function findFile(fileName: string): Promise<string | null> {
  const possiblePaths = [
    path.join(process.cwd(), 'uploads', fileName),
    path.join(process.cwd(), 'input-files', fileName),
    path.resolve('./uploads', fileName),
    path.resolve('./input-files', fileName)
  ];

  for (const filePath of possiblePaths) {
    try {
      await fs.access(filePath);
      return filePath;
    } catch (error) {
      // Continue to next path
    }
  }
  return null;
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Upload CSV file
  app.post("/api/upload-csv", upload.single('csvFile'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const filePath = req.file.path;
      const originalName = req.file.originalname;
      
      // Read and parse CSV for preview
      const fileContent = await fs.readFile(filePath, 'utf-8');
      const lines = fileContent.trim().split('\n');
      
      if (lines.length === 0) {
        await fs.unlink(filePath);
        return res.status(400).json({ message: "CSV file is empty" });
      }
      
      // Parse CSV more robustly
      const parseCSVLine = (line: string) => {
        const result = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current.trim());
        return result;
      };
      
      const headers = parseCSVLine(lines[0]);
      const previewLines = lines.slice(1, 4); // Take up to 3 preview rows
      const rows = previewLines.filter(line => line.trim()).map(line => parseCSVLine(line));

      // Save CSV file to local input directory for backup
      const inputDir = './input-files';
      await ensureDirectory(inputDir);
      const savedCsvPath = path.join(inputDir, originalName);
      await fs.copyFile(filePath, savedCsvPath);
      
      console.log(`File uploaded and saved: ${originalName}`);

      res.json({
        fileName: originalName,
        fileSize: req.file.size,
        headers,
        previewRows: rows,
        success: true,
        localCsvPath: savedCsvPath,
        uploadedPath: filePath,
        message: `CSV file uploaded and saved.`
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ 
        message: "Failed to process uploaded file",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Move uploaded file to Airflow data directory
  app.post("/api/move-file-to-data", async (req, res) => {
    try {
      const { fileName, targetPath } = req.body;
      
      if (!fileName || !targetPath) {
        return res.status(400).json({ 
          success: false, 
          message: "fileName and targetPath are required" 
        });
      }
      
      console.log(`Moving file: ${fileName} to ${targetPath}`);
      
      // Find the source file
      const sourcePath = await findFile(fileName);
      
      if (!sourcePath) {
        return res.status(404).json({
          success: false,
          message: `Source file not found: ${fileName}. Checked: uploads/, input-files/`
        });
      }
      
      // Try to use the actual target path, fallback to local if needed
      const { path: actualTargetPath, isLocal } = await getTargetPath(targetPath, 'data');
      const targetDir = path.dirname(actualTargetPath);
      
      // Ensure target directory exists
      await ensureDirectory(targetDir);
      
      // Copy file to target location
      await fs.copyFile(sourcePath, actualTargetPath);
      
      console.log(`File successfully moved from ${sourcePath} to: ${actualTargetPath}`);
      
      res.json({
        success: true,
        message: `File moved successfully to ${isLocal ? 'local' : 'Airflow'} data directory`,
        filePath: actualTargetPath,
        sourcePath: sourcePath,
        isLocal: isLocal,
        note: isLocal ? 
          "Could not access Windows Airflow directory, saved locally instead." : 
          "File saved to actual Airflow data directory."
      });
    } catch (error) {
      console.error('File move failed:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to move file'
      });
    }
  });

  // Validate deployment setup
  app.post("/api/validate-deployment", async (req, res) => {
    try {
      const { dagId, inputPath, outputPath, dagsDirectory } = req.body;
      
      console.log(`Validating deployment for DAG: ${dagId}`);
      
      // Try actual paths first, then local fallbacks
      const { path: actualInputPath } = await getTargetPath(inputPath, 'data');
      const { path: actualOutputDir } = await getTargetPath(path.dirname(outputPath), 'data');
      const { path: actualDagsDir } = await getTargetPath(dagsDirectory, 'dags');
      
      // Check if input file exists
      let fileLocationValid = false;
      try {
        await fs.access(actualInputPath);
        fileLocationValid = true;
      } catch (error) {
        console.log(`Input file not found at: ${actualInputPath}`);
      }
      
      // Check if directories exist
      let filePathsValid = false;
      try {
        await fs.access(path.dirname(actualInputPath));
        await fs.access(actualOutputDir);
        filePathsValid = true;
      } catch (error) {
        console.log(`Directory validation failed`);
      }
      
      // Check if DAGs directory exists
      let dagsDirectoryValid = false;
      try {
        await fs.access(actualDagsDir);
        dagsDirectoryValid = true;
      } catch (error) {
        console.log(`DAGs directory not found: ${actualDagsDir}`);
      }
      
      const validation = {
        syntax: true,
        dagId: true,
        filePaths: filePathsValid && dagsDirectoryValid,
        dependencies: true,
        fileLocation: fileLocationValid
      };
      
      const allValid = Object.values(validation).every(v => v);
      
      res.json({
        success: allValid,
        message: allValid ? 'All validation checks passed' : 'Some validation checks failed',
        validation
      });
    } catch (error) {
      console.error('Validation failed:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Validation failed',
        validation: {
          syntax: false,
          dagId: false,
          filePaths: false,
          dependencies: false,
          fileLocation: false
        }
      });
    }
  });

  // Test DAG script syntax
  app.post("/api/test-dag", async (req, res) => {
    try {
      const { dagId, dagScript } = req.body;
      
      if (!dagId || !dagScript) {
        return res.status(400).json({
          success: false,
          message: "dagId and dagScript are required"
        });
      }
      
      console.log(`Testing DAG script: ${dagId}`);
      
      // Create temp directory if it doesn't exist
      const tempDir = './temp';
      await ensureDirectory(tempDir);
      
      // Write script to temp file
      const tempFile = path.join(tempDir, `${dagId}_test.py`);
      await fs.writeFile(tempFile, dagScript);
      
      try {
        // Test Python syntax (requires Python to be installed)
        execSync(`python -m py_compile "${tempFile}"`, { stdio: 'pipe' });
        
        // Clean up temp file
        await fs.unlink(tempFile);
        
        res.json({
          success: true,
          message: 'DAG syntax validation passed'
        });
      } catch (pythonError) {
        // Clean up temp file even on error
        try {
          await fs.unlink(tempFile);
        } catch (cleanupError) {
          console.error('Failed to clean up temp file:', cleanupError);
        }
        
        // If Python is not available, do basic string validation
        if (dagScript.includes('from airflow') && dagScript.includes('with DAG(')) {
          res.json({
            success: true,
            message: 'Basic DAG structure validation passed (Python not available for syntax check)'
          });
        } else {
          res.json({
            success: false,
            message: 'DAG structure validation failed',
            errors: ['Missing required Airflow imports or DAG definition']
          });
        }
      }
    } catch (error) {
      console.error('DAG test failed:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'DAG test failed'
      });
    }
  });

  // Deploy DAG to Airflow
  app.post("/api/deploy-dag", async (req, res) => {
    try {
      const { dagId, dagScript, dagsDirectory } = req.body;
      
      if (!dagId || !dagScript) {
        return res.status(400).json({
          success: false,
          message: "dagId and dagScript are required"
        });
      }
      
      console.log(`Deploying DAG: ${dagId} to ${dagsDirectory}`);
      
      // Try to use the actual DAGs directory, fallback to local if needed
      const { path: actualDagsDir, isLocal } = await getTargetPath(dagsDirectory, 'dags');
      const filePath = path.join(actualDagsDir, `${dagId}.py`);
      
      // Ensure DAGs directory exists
      await ensureDirectory(actualDagsDir);
      
      // Write DAG script to file
      await fs.writeFile(filePath, dagScript, 'utf8');
      
      console.log(`DAG deployed successfully to: ${filePath}`);
      
      res.json({
        success: true,
        message: `DAG deployed successfully to ${isLocal ? 'local' : 'Airflow'} directory`,
        filePath,
        isLocal: isLocal,
        note: isLocal ? 
          "Could not access Windows Airflow directory, saved locally instead." : 
          "File saved to actual Airflow DAGs directory."
      });
    } catch (error) {
      console.error('DAG deployment failed:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'DAG deployment failed'
      });
    }
  });

  // Check DAG ID uniqueness
  app.post("/api/check-dag-id", async (req, res) => {
    try {
      const { dagId } = req.body;
      if (!dagId) {
        return res.status(400).json({ message: "DAG ID is required" });
      }

      // Check in storage
      const existingConfig = await storage.getDagConfigurationByDagId(dagId);
      if (existingConfig) {
        return res.json({ isUnique: false, message: "DAG ID already exists in database" });
      }

      // Check in both actual DAGs directory and local directory
      const dagsDir = process.env.AIRFLOW_DAGS_DIR || "C:\\Docker\\airflow3x2\\dags";
      const { path: actualDagsDir } = await getTargetPath(dagsDir, 'dags');
      
      try {
        const dagFilePath = path.join(actualDagsDir, `${dagId}.py`);
        await fs.access(dagFilePath);
        return res.json({ isUnique: false, message: "DAG file already exists in directory" });
      } catch {
        // File doesn't exist, which is good
      }
      
      // Also check local dags directory
      try {
        const localDagFilePath = path.join('./dags', `${dagId}.py`);
        await fs.access(localDagFilePath);
        return res.json({ isUnique: false, message: "DAG file already exists in local directory" });
      } catch {
        // File doesn't exist, which is good
      }

      res.json({ isUnique: true, message: "DAG ID is available" });
    } catch (error) {
      console.error('DAG ID check error:', error);
      res.status(500).json({ message: "Failed to check DAG ID uniqueness" });
    }
  });

  // Generate DAG script
  app.post("/api/generate-dag", async (req, res) => {
    try {
      console.log('Received DAG generation request:', req.body);
      
      const validatedData = dagConfigurationSchema.parse(req.body);
      console.log('Validated data:', validatedData);
      
      // Save configuration with proper defaults
      const configToSave = {
        dagId: validatedData.dagId,
        inputPath: validatedData.inputPath,
        outputPath: validatedData.outputPath,
        description: validatedData.description || null,
        scheduleInterval: validatedData.scheduleInterval || null,
        dagsDirectory: validatedData.dagsDirectory || null,
      };
      
      const config = await storage.createDagConfiguration(configToSave);

      // Generate DAG script
      const dagScript = generateDagScript(validatedData);

      res.json({
        config,
        dagScript,
        success: true,
        message: "DAG script generated successfully"
      });
    } catch (error) {
      console.error('DAG generation error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Validation error",
          errors: error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message,
            code: err.code
          }))
        });
      }
      
      res.status(500).json({ 
        message: "Failed to generate DAG script",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Save DAG to directory (enhanced to use actual Windows paths)
  app.post("/api/save-dag", async (req, res) => {
    try {
      const { dagId, dagScript, dagsDirectory } = req.body;
      
      console.log('Save DAG request:', { dagId, dagsDirectory, scriptLength: dagScript?.length });
      
      if (!dagId || !dagScript) {
        return res.status(400).json({ message: "DAG ID and script are required" });
      }

      // Try to use the actual DAGs directory, fallback to local if needed
      const { path: actualDagsDir, isLocal } = await getTargetPath(dagsDirectory || "C:\\Docker\\airflow3x2\\dags", 'dags');
      const dagFilePath = path.join(actualDagsDir, `${dagId}.py`);

      console.log('Attempting to save to:', dagFilePath);

      // Ensure directory exists
      await ensureDirectory(actualDagsDir);
      console.log('Directory created/verified:', actualDagsDir);
      
      // Check if file already exists
      let fileExists = false;
      try {
        await fs.access(dagFilePath);
        fileExists = true;
      } catch (error) {
        // File doesn't exist, which is fine
      }
      
      // Write DAG file
      await fs.writeFile(dagFilePath, dagScript, 'utf-8');
      console.log('File written successfully to:', dagFilePath);

      // Verify file was written
      const stats = await fs.stat(dagFilePath);
      console.log('File stats:', { size: stats.size, created: stats.birthtime });

      const note = fileExists ? 'Existing DAG file updated.' : 'New DAG file created.';
      const locationNote = isLocal ? 
        "Could not access Windows Airflow directory, saved to local directory instead." : 
        "File saved to actual Airflow DAGs directory.";

      res.json({
        success: true,
        message: `DAG saved successfully to ${isLocal ? 'local' : 'Airflow'} directory`,
        filePath: dagFilePath,
        fileSize: stats.size,
        isLocal: isLocal,
        note: `${note} ${locationNote}`
      });
    } catch (error) {
      console.error('DAG save error:', error);
      res.status(500).json({ 
        message: "Failed to save DAG to directory",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get all DAG configurations
  app.get("/api/dag-configurations", async (req, res) => {
    try {
      const configs = await storage.getAllDagConfigurations();
      res.json(configs);
    } catch (error) {
      console.error('Get configurations error:', error);
      res.status(500).json({ message: "Failed to retrieve DAG configurations" });
    }
  });

  // Test Airflow connection
  app.get("/api/test-airflow", async (req, res) => {
    try {
      const airflowUrl = process.env.AIRFLOW_URL || "http://localhost:8083";
      
      // Create a more robust health check with timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
      
      const response = await fetch(`${airflowUrl}/api/v1/health`, {
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });
      
      clearTimeout(timeoutId);
      
      if (response.ok) {
        const health = await response.json();
        res.json({ 
          connected: true, 
          status: health,
          url: airflowUrl
        });
      } else {
        res.json({ 
          connected: false, 
          error: `Airflow returned HTTP ${response.status}. Make sure Airflow is running on ${airflowUrl}`,
          url: airflowUrl
        });
      }
    } catch (error) {
      let errorMessage = "Connection failed";
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          errorMessage = "Connection timeout - Airflow may not be running";
        } else if (error.message.includes('ECONNREFUSED')) {
          errorMessage = "Connection refused - Airflow is not running on this port";
        } else {
          errorMessage = error.message;
        }
      }
      
      res.json({ 
        connected: false, 
        error: errorMessage,
        url: process.env.AIRFLOW_URL || "http://localhost:8083"
      });
    }
  });

  // Generate sample XML
  app.post("/api/generate-sample-xml", async (req, res) => {
    try {
      const { headers, sampleRows } = req.body;
      
      if (!headers || !Array.isArray(headers)) {
        return res.status(400).json({ message: "Headers are required" });
      }

      const sampleXml = generateSampleXml(headers, sampleRows || []);
      
      res.json({
        xml: sampleXml,
        success: true
      });
    } catch (error) {
      console.error('XML generation error:', error);
      res.status(500).json({ message: "Failed to generate sample XML" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function generateDagScript(config: DagConfigurationInput): string {
  // Use the actual paths as specified by the user
  const inputPath = config.inputPath;
  const outputPath = config.outputPath;
  
  const template = `from airflow import DAG
from airflow.decorators import task
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime
import csv, os, glob
import xml.etree.ElementTree as ET

input_directory = r'${path.dirname(inputPath)}'
output_directory = r'${path.dirname(outputPath)}'

default_args = {
    "owner": "airflow",
    "retries": 1,
}

with DAG(
    dag_id='${config.dagId}',
    default_args=default_args,
    description='${config.description || 'Convert CSV to XML format'}',
    schedule=${config.scheduleInterval === 'None' ? 'None' : `'${config.scheduleInterval}'`},
    start_date=datetime(2024, 1, 1),
    catchup=False,
) as dag:
    
    @task
    def convert_csv_to_xml():
        # Find all CSV files in the input directory
        csv_files = glob.glob(os.path.join(input_directory, '*.csv'))
        
        if not csv_files:
            print(f"⚠️  No CSV files found in {input_directory}")
            return
            
        # Ensure output directory exists
        os.makedirs(output_directory, exist_ok=True)
        
        for csv_path in csv_files:
            print(f"📄 Processing: {csv_path}")
            
            # Extract filename without extension for customer name
            filename = os.path.basename(csv_path)
            customer_name = os.path.splitext(filename)[0]
            
            # Create XML structure
            with open(csv_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                tickets = ET.Element('TICKETS')
                customer = ET.SubElement(tickets, customer_name)

                for row in reader:
                    row_elem = ET.SubElement(customer, 'ROW')
                    for key, val in row.items():
                        col = ET.SubElement(row_elem, key.replace(' ', '_'))
                        col.text = str(val) if val else ''

            # Save XML file with same base name as CSV
            xml_filename = f"{customer_name}.xml"
            output_path = os.path.join(output_directory, xml_filename)
            
            ET.ElementTree(tickets).write(output_path, encoding='utf-8', xml_declaration=True)
            print(f'✅ XML saved to: {output_path}')
        
        print(f"🎉 Processed {len(csv_files)} CSV file(s)")

    convert_csv_to_xml()`;

  return template;
}

function generateSampleXml(headers: string[], sampleRows: string[][]): string {
  const customerName = "SampleCorp";
  
  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<TICKETS>
    <${customerName}>`;

  sampleRows.forEach((row, index) => {
    xml += `
        <ROW>`;
    headers.forEach((header, headerIndex) => {
      const value = row[headerIndex] || '';
      xml += `
            <${header}>${value}</${header}>`;
    });
    xml += `
        </ROW>`;
  });

  xml += `
    </${customerName}>
</TICKETS>`;

  return xml;
}