# DAG Generator - Airflow CSV to XML Converter

## Overview

This is a full-stack web application that helps users generate Apache Airflow DAG (Directed Acyclic Graph) scripts for converting CSV files to XML format. The application provides an intuitive step-by-step interface for uploading CSV files, configuring DAG parameters, generating Python scripts, and previewing XML output.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system
- **State Management**: React hooks with TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **File Upload**: Multer middleware for CSV file handling
- **Session Management**: PostgreSQL-based sessions with connect-pg-simple

### Project Structure
- `client/` - React frontend application
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript schemas and types
- `attached_assets/` - Static assets and example files

## Key Components

### File Upload System
- Drag-and-drop CSV file upload with validation
- File size limits (10MB) and type checking
- CSV parsing and preview functionality
- Temporary file storage with cleanup

### DAG Configuration Engine
- Dynamic form generation for DAG parameters
- Real-time validation of DAG IDs for uniqueness
- Customizable scheduling intervals and paths
- Integration with Airflow best practices

### Code Generation
- Python script generation using template system
- Airflow DAG structure with proper imports
- CSV to XML conversion logic with ElementTree
- Configurable paths and customer naming conventions

### Database Schema
- `users` table for authentication (username/password)
- `dag_configurations` table for storing DAG settings
- Timestamps and unique constraints for data integrity

## Data Flow

1. **File Upload**: User uploads CSV file → Server validates and parses → Returns preview data
2. **Configuration**: User sets DAG parameters → Client validates → Server checks uniqueness
3. **Generation**: User triggers script generation → Server creates Python code → Returns formatted DAG
4. **XML Preview**: System generates sample XML from CSV data → Shows expected output format

## External Dependencies

### Frontend Dependencies
- **UI Components**: Radix UI primitives for accessibility
- **Form Handling**: React Hook Form + Hookform Resolvers
- **Data Fetching**: TanStack React Query
- **Styling**: Tailwind CSS + Class Variance Authority
- **Icons**: Lucide React
- **Date Handling**: date-fns

### Backend Dependencies
- **Database**: Drizzle ORM + Neon Database serverless driver
- **Validation**: Zod for schema validation
- **File Processing**: Multer for uploads
- **Session Storage**: connect-pg-simple for PostgreSQL sessions

### Development Tools
- **Build**: Vite + esbuild for production builds
- **TypeScript**: Full type safety across frontend/backend
- **Replit Integration**: Development banners and cartographer plugin

## Deployment Strategy

### Development
- Vite dev server with HMR (Hot Module Replacement)
- Express server with TypeScript compilation via tsx
- Database migrations with Drizzle Kit
- Replit-specific development enhancements

### Production
- Frontend: Vite build → static files served by Express
- Backend: esbuild bundle → single Node.js executable
- Database: Neon serverless PostgreSQL (always-on)
- Environment: DATABASE_URL required for database connection

### Build Commands
- `npm run dev` - Development server with hot reload
- `npm run build` - Production build (frontend + backend)
- `npm run start` - Production server
- `npm run db:push` - Database schema deployment

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Recent Changes:
- June 30, 2025: Fixed DAG file saving functionality - Windows paths now converted to local directories with user guidance
- June 30, 2025: Removed Airflow connection status from sidebar and configuration page per user request
- June 30, 2025: Updated DAG ID validation to allow uppercase letters, numbers, and underscores
- June 30, 2025: Enhanced error handling and user feedback for file operations
- June 30, 2025: Fixed DAG generation validation issues - resolved schema mismatch between frontend/backend
- June 30, 2025: Initial setup