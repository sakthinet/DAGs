from airflow import DAG
from airflow.decorators import task
from datetime import datetime
import csv
import xml.etree.ElementTree as ET

with DAG(
    dag_id="mycustomdag",
    start_date=datetime(2024, 1, 1),
    catchup=False,
) as dag:
    
    @task
    def convert_csv_to_xml():
        print("Converting CSV to XML")
        return "Success"
    
    convert_csv_to_xml()
